import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { db, getSetting, initDatabase, setSetting, UPLOADS_DIR } from './src/server/db.ts';
import {
  ALL_PERMISSIONS,
  type AuthedRequest,
  hashPassword,
  parseCookieToken,
  requireAdmin,
  signSessionToken,
  verifyPassword,
  verifySessionToken,
} from './src/server/auth.ts';
import { generateAiBusinessReport } from './src/server/aiAdvisor.ts';
import type { CustomServiceRequest, OrderLineItem, OrderStatus, ServiceItem } from './src/types.ts';

initDatabase();

const app = express();
app.set('trust proxy', 1);
const PORT = 3000;

app.use(express.json({ limit: '15mb' }));

function setAdminSessionCookie(req: express.Request, res: express.Response, token: string) {
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.cookie('go_admin_session', token, {
    httpOnly: true,
    sameSite: isHttps ? 'none' : 'lax',
    secure: isHttps,
    maxAge: 1000 * 60 * 60 * 12,
    path: '/',
  });
}

function getCustomCategoriesConfig() {
  return {
    printing: {
      enabled: getSetting('custom_printing_enabled') !== '0',
      label_ar:
        getSetting('custom_printing_label') ||
        'طلب خدمة طباعة أخرى حسب الطلب (تحدد الإدارة السعر وترسله لك)',
    },
    admin: {
      enabled: getSetting('custom_admin_enabled') !== '0',
      label_ar:
        getSetting('custom_admin_label') ||
        'طلب خدمة إدارية أخرى حسب الطلب (تحدد الإدارة السعر وترسله لك)',
    },
    design: {
      enabled: getSetting('custom_design_enabled') !== '0',
      label_ar:
        getSetting('custom_design_label') ||
        'طلب خدمة تصميم أو إشهار أخرى حسب الطلب (تحدد الإدارة السعر وترسله لك)',
    },
  };
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).replace(/[^a-zA-Z0-9.]/g, '');
    cb(null, `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 20 * 1024 * 1024, // 20 MB per file
    files: 10,
  },
});

function generateTrackingCode(): string {
  const year = new Date().getFullYear();
  const suffix = crypto.randomInt(1000, 9999);
  const alpha = crypto.randomBytes(1).toString('hex').toUpperCase();
  return `GO-${year}-${suffix}${alpha}`;
}

function hydrateOrder(row: any) {
  const files = db
    .prepare('SELECT id, order_id, original_name, stored_name, mime_type, size_bytes, uploaded_by, created_at FROM order_files WHERE order_id = ? ORDER BY id ASC')
    .all(row.id);
  const messages = db
    .prepare(`
      SELECT m.id, m.order_id, m.sender, m.message_text, m.attachment_file_id, m.created_at,
             f.original_name as attachment_name, f.mime_type as attachment_mime
      FROM order_messages m
      LEFT JOIN order_files f ON m.attachment_file_id = f.id
      WHERE m.order_id = ?
      ORDER BY m.id ASC
    `)
    .all(row.id);
  const review = db.prepare('SELECT id FROM reviews WHERE order_id = ?').get(row.id);

  return {
    ...row,
    items: JSON.parse(row.items_json || '[]'),
    custom_requests: JSON.parse(row.custom_requests_json || '[]'),
    files,
    messages,
    has_review: Boolean(review),
  };
}

async function dispatchAdminEmailNotification(trackingCode: string, customerName: string, totalPrice: number, customPending: boolean) {
  const adminEmail = getSetting('admin_email');
  if (!adminEmail) return 'skipped';

  const webhookUrl = process.env.EMAIL_WEBHOOK_URL;
  const resendKey = process.env.RESEND_API_KEY;

  const subject = `طلب جديد في Graphicore Office — ${trackingCode}`;
  const bodyText = `وصل طلب جديد من العميل: ${customerName}\nرمز التتبع: ${trackingCode}\nالمبلغ المبدئي: ${totalPrice} د.ج${customPending ? ' (يوجد خدمة مخصصة بانتظار التسعير)' : ''}`;

  try {
    if (resendKey) {
      const resp = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: process.env.RESEND_FROM_EMAIL || 'orders@graphicore.local',
          to: [adminEmail],
          subject,
          text: bodyText,
        }),
      });
      return resp.ok ? 'sent_resend' : 'failed_resend';
    }
    if (webhookUrl) {
      const resp = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: adminEmail, subject, text: bodyText, trackingCode }),
      });
      return resp.ok ? 'sent_webhook' : 'failed_webhook';
    }
    return 'queued_in_panel';
  } catch {
    return 'queued_in_panel';
  }
}

// ============================================================================
// PUBLIC ROUTES (Customer-safe only — zero admin/financial/AI exposure)
// ============================================================================

app.get('/api/public/config', (_req, res) => {
  res.json({
    googleMapsApiKey: process.env.VITE_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY || '',
    officeName: getSetting('office_name') || 'Graphicore Office',
    officeLogo: getSetting('office_logo') || '',
    officeAddress: getSetting('office_address') || 'حي أول نوفمبر، مركز الأعمال، الجزائر',
    officeLat: parseFloat(getSetting('office_lat') || '36.7538'),
    officeLng: parseFloat(getSetting('office_lng') || '3.0588'),
    workingHoursMorning: getSetting('working_hours_morning') || '08:00 – 13:30',
    workingHoursEvening: getSetting('working_hours_evening') || '18:30 – 21:30',
    deliveryBaseFee: parseFloat(getSetting('delivery_base_fee') || '200'),
    deliveryEnabled: getSetting('delivery_enabled') !== '0',
    showSatisfactionSummary: getSetting('show_satisfaction_summary') !== '0',
    customCategories: getCustomCategoriesConfig(),
  });
});

app.get('/api/public/logo', (_req, res) => {
  const filename = getSetting('office_logo_file');
  if (!filename) {
    res.status(404).end();
    return;
  }
  const fullPath = path.join(UPLOADS_DIR, path.basename(filename));
  if (!fs.existsSync(fullPath)) {
    res.status(404).end();
    return;
  }
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.sendFile(fullPath);
});

app.get('/api/services', (_req, res) => {
  const rows = db
    .prepare('SELECT * FROM services WHERE active = 1 ORDER BY sort_order ASC, id ASC')
    .all();
  res.json(rows);
});

app.get('/api/reviews/summary', (_req, res) => {
  const stats = db
    .prepare('SELECT COUNT(*) as totalReviews, AVG(rating) as averageRating FROM reviews')
    .get() as { totalReviews: number; averageRating: number | null };
  res.json({
    totalReviews: stats.totalReviews || 0,
    averageRating: stats.averageRating ? Math.round(stats.averageRating * 10) / 10 : null,
  });
});

// Server-side Geocoding proxy (prevents CORS issues per Google Maps CF1)
app.get('/api/maps/geocode', async (req, res) => {
  const apiKey = process.env.GOOGLE_MAPS_API_KEY || process.env.VITE_GOOGLE_MAPS_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: 'Google Maps API key not configured.' });
    return;
  }
  const lat = req.query.lat as string | undefined;
  const lng = req.query.lng as string | undefined;
  const address = req.query.address as string | undefined;

  try {
    const url = new URL('https://maps.googleapis.com/maps/api/geocode/json');
    if (lat && lng) {
      url.searchParams.set('latlng', `${lat},${lng}`);
    } else if (address) {
      url.searchParams.set('address', address);
    } else {
      res.status(400).json({ error: 'Missing lat/lng or address parameter.' });
      return;
    }
    url.searchParams.set('language', 'ar');
    url.searchParams.set('key', apiKey);

    const response = await fetch(url.toString());
    const data = (await response.json()) as any;
    if (response.status === 429 || data?.status === 'OVER_QUERY_LIMIT') {
      res.status(429).json({ error: 'RESOURCE_EXHAUSTED', status: 'RESOURCE_EXHAUSTED' });
      return;
    }
    const first = data?.results?.[0];
    res.json({
      formattedAddress: first?.formatted_address || '',
      location: first?.geometry?.location || null,
      status: data?.status || 'UNKNOWN',
    });
  } catch {
    res.status(500).json({ error: 'Geocoding request failed.' });
  }
});

// Create Order (with up to 10 uploaded files)
app.post('/api/orders', upload.array('files', 10), async (req, res) => {
  try {
    const customerName = String(req.body.customer_name || '').trim();
    const customerPhone = String(req.body.customer_phone || '').replace(/\s+/g, '').trim();
    const notes = String(req.body.notes || '').trim();
    const pickupType = (req.body.pickup_type || 'tomorrow_morning') as 'tomorrow_morning' | 'scheduled' | 'asap';
    const pickupDatetime = req.body.pickup_datetime ? String(req.body.pickup_datetime) : null;
    const deliveryAllowed = getSetting('delivery_enabled') !== '0';
    const deliveryRequested =
      deliveryAllowed && (req.body.delivery_requested === '1' || req.body.delivery_requested === 'true') ? 1 : 0;
    const deliveryLat = deliveryRequested && req.body.delivery_lat ? Number(req.body.delivery_lat) : null;
    const deliveryLng = deliveryRequested && req.body.delivery_lng ? Number(req.body.delivery_lng) : null;
    const deliveryAddress = deliveryRequested ? String(req.body.delivery_address || '').trim() : '';
    const termsAccepted = req.body.terms_accepted === '1' || req.body.terms_accepted === 'true';

    if (!customerName || customerName.length < 2) {
      res.status(400).json({ error: 'يرجى إدخال الاسم الكامل بشكل صحيح.' });
      return;
    }
    const localPhoneOk = /^0\d{9}$/.test(customerPhone);
    const intlPhoneOk = /^\+[1-9]\d{7,14}$/.test(customerPhone);
    if (!localPhoneOk && !intlPhoneOk) {
      res.status(400).json({ error: 'رقم الهاتف غير صالح: يجب إدخال 10 أرقام محلية أو رقم دولي يبدأ بـ +.' });
      return;
    }
    if (!termsAccepted) {
      res.status(400).json({ error: 'الموافقة على شروط الطلب والاستلام والتسديد إلزامية.' });
      return;
    }

    let rawItems: any[] = [];
    let rawCustom: CustomServiceRequest[] = [];
    try {
      rawItems = JSON.parse(req.body.items_json || '[]');
      rawCustom = JSON.parse(req.body.custom_requests_json || '[]');
    } catch {
      res.status(400).json({ error: 'بيانات الخدمات غير صالحة.' });
      return;
    }

    const validCustom = rawCustom.filter((c) => c && String(c.description || '').trim().length > 0);
    if (rawItems.length === 0 && validCustom.length === 0) {
      res.status(400).json({ error: 'يرجى اختيار خدمة واحدة على الأقل أو كتابة طلب مخصص.' });
      return;
    }

    // Recompute authoritative prices from active services in DB
    const computedItems: OrderLineItem[] = [];
    let totalPrice = 0;

    for (const reqItem of rawItems) {
      const service = db.prepare('SELECT * FROM services WHERE id = ? AND active = 1').get(reqItem.serviceId) as ServiceItem | undefined;
      if (!service) continue;
      let qty = Math.max(1, Math.floor(Number(reqItem.quantity) || 1));

      let unitPrice = service.price;
      let setupFee = 0;
      let subtotal = 0;

      // Business Card special logic: 800 DZD design + optional printing >= 100 cards @ 10 DZD/card
      if (service.print_unit_price !== null && service.setup_design_fee > 0) {
        const includePrint = Boolean(reqItem.includeDesignPrint);
        setupFee = service.setup_design_fee;
        if (includePrint) {
          qty = Math.max(service.min_qty || 100, qty);
          unitPrice = service.print_unit_price;
          subtotal = setupFee + qty * unitPrice;
        } else {
          qty = 1;
          unitPrice = 0;
          subtotal = setupFee;
        }
      } else {
        // Wedding invitations & standard items (with optional design setup fee)
        const includeSetup = service.setup_design_fee > 0 ? reqItem.includeDesignSetup !== false : false;
        setupFee = includeSetup ? service.setup_design_fee : 0;
        subtotal = qty * unitPrice + setupFee;
      }

      totalPrice += subtotal;
      computedItems.push({
        serviceId: service.id,
        category: service.category,
        name_ar: service.name_ar,
        name_fr: service.name_fr,
        name_en: service.name_en,
        quantity: qty,
        includeDesignPrint: Boolean(reqItem.includeDesignPrint),
        includeDesignSetup: reqItem.includeDesignSetup !== false,
        unitPrice,
        setupFee,
        subtotal,
      });
    }

    const deliveryFee = deliveryRequested ? parseFloat(getSetting('delivery_base_fee') || '200') : 0;
    totalPrice += deliveryFee;

    const customPriceStatus = validCustom.length > 0 ? 'pending_quote' : 'fixed';

    let trackingCode = generateTrackingCode();
    while (db.prepare('SELECT id FROM orders WHERE tracking_code = ?').get(trackingCode)) {
      trackingCode = generateTrackingCode();
    }

    const insertOrder = db.prepare(`
      INSERT INTO orders (
        tracking_code, customer_name, customer_phone, items_json, custom_requests_json,
        total_price, custom_price_status, notes, pickup_type, pickup_datetime,
        delivery_requested, delivery_lat, delivery_lng, delivery_address, delivery_fee,
        terms_accepted, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'sent')
    `);

    const info = insertOrder.run(
      trackingCode,
      customerName,
      customerPhone,
      JSON.stringify(computedItems),
      JSON.stringify(validCustom.map((c) => ({ ...c, quotedPrice: null }))),
      totalPrice,
      customPriceStatus,
      notes,
      pickupType,
      pickupDatetime,
      deliveryRequested,
      deliveryLat,
      deliveryLng,
      deliveryAddress,
      deliveryFee
    );

    const orderId = Number(info.lastInsertRowid);

    const files = (req.files as Express.Multer.File[]) || [];
    const insertFile = db.prepare(`
      INSERT INTO order_files (order_id, original_name, stored_name, mime_type, size_bytes, uploaded_by)
      VALUES (?, ?, ?, ?, ?, 'customer')
    `);
    for (const f of files) {
      insertFile.run(orderId, f.originalname, f.filename, f.mimetype, f.size);
    }

    // Add initial system/welcome message in order thread
    db.prepare(`
      INSERT INTO order_messages (order_id, sender, message_text)
      VALUES (?, 'admin', ?)
    `).run(
      orderId,
      customPriceStatus === 'pending_quote'
        ? 'تم استلام طلبك بنجاح! سيقوم فريق Graphicore Office بمراجعة الطلب وتحديد سعر الخدمة المخصصة وإرسال العرض لك هنا.'
        : 'تم استلام طلبك بنجاح وهو الآن قيد المراجعة من طرف فريق Graphicore Office.'
    );

    const emailStatus = await dispatchAdminEmailNotification(
      trackingCode,
      customerName,
      totalPrice,
      customPriceStatus === 'pending_quote'
    );

    db.prepare(`
      INSERT INTO admin_notifications (type, title, body, order_id, email_sent_to, email_status)
      VALUES ('new_order', ?, ?, ?, ?, ?)
    `).run(
      `طلب جديد: ${trackingCode}`,
      `العميل ${customerName} (${customerPhone}) — المجموع المبدئي ${totalPrice} د.ج`,
      orderId,
      getSetting('admin_email'),
      emailStatus
    );

    const created = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
    res.status(201).json(hydrateOrder(created));
  } catch (err) {
    console.error('Order creation error:', err);
    res.status(500).json({ error: 'حدث خطأ أثناء تسجيل الطلب، يرجى المحاولة مرة أخرى.' });
  }
});

// Track Order by Tracking Code OR Phone Number (No account needed)
app.get('/api/orders/track', (req, res) => {
  const q = String(req.query.q || '').replace(/\s+/g, '').trim();
  if (!q || q.length < 4) {
    res.status(400).json({ error: 'يرجى إدخال رمز التتبع أو رقم الهاتف.' });
    return;
  }

  const byCode = db
    .prepare('SELECT * FROM orders WHERE UPPER(tracking_code) = UPPER(?)')
    .all(q);
  if (byCode.length > 0) {
    res.json(byCode.map(hydrateOrder));
    return;
  }

  const byPhone = db
    .prepare('SELECT * FROM orders WHERE REPLACE(customer_phone, " ", "") = ? ORDER BY created_at DESC LIMIT 20')
    .all(q);
  res.json(byPhone.map(hydrateOrder));
});

// Download / preview order file (authorized by tracking code OR valid admin session)
app.get('/api/orders/:trackingCode/files/:fileId', (req, res) => {
  const { trackingCode, fileId } = req.params;
  const token = parseCookieToken(req);
  const isAdmin = token ? Boolean(verifySessionToken(token)) : false;

  const order = db.prepare('SELECT id FROM orders WHERE UPPER(tracking_code) = UPPER(?)').get(trackingCode) as
    | { id: number }
    | undefined;
  if (!order && !isAdmin) {
    res.status(404).json({ error: 'Order not found.' });
    return;
  }

  const fileRow = isAdmin
    ? (db.prepare('SELECT * FROM order_files WHERE id = ?').get(fileId) as any)
    : (db.prepare('SELECT * FROM order_files WHERE id = ? AND order_id = ?').get(fileId, order!.id) as any);

  if (!fileRow) {
    res.status(404).json({ error: 'File not found.' });
    return;
  }

  const fullPath = path.join(UPLOADS_DIR, fileRow.stored_name);
  if (!fs.existsSync(fullPath)) {
    res.status(404).json({ error: 'File missing on disk.' });
    return;
  }

  res.setHeader('Content-Type', fileRow.mime_type || 'application/octet-stream');
  res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(fileRow.original_name)}"`);
  fs.createReadStream(fullPath).pipe(res);
});

// Customer sends message (+ optional attachment) in private order thread
app.post('/api/orders/:trackingCode/messages', upload.single('file'), (req, res) => {
  const { trackingCode } = req.params;
  const order = db.prepare('SELECT * FROM orders WHERE UPPER(tracking_code) = UPPER(?)').get(trackingCode) as any;
  if (!order) {
    res.status(404).json({ error: 'الطلب غير موجود.' });
    return;
  }

  const text = String(req.body.message_text || '').trim();
  const uploadedFile = req.file;
  if (!text && !uploadedFile) {
    res.status(400).json({ error: 'يرجى كتابة رسالة أو إرفاق ملف.' });
    return;
  }

  let fileId: number | null = null;
  if (uploadedFile) {
    const fInfo = db
      .prepare('INSERT INTO order_files (order_id, original_name, stored_name, mime_type, size_bytes, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)')
      .run(order.id, uploadedFile.originalname, uploadedFile.filename, uploadedFile.mimetype, uploadedFile.size, 'customer');
    fileId = Number(fInfo.lastInsertRowid);
  }

  db.prepare('INSERT INTO order_messages (order_id, sender, message_text, attachment_file_id) VALUES (?, ?, ?, ?)').run(
    order.id,
    'customer',
    text,
    fileId
  );

  db.prepare(`
    INSERT INTO admin_notifications (type, title, body, order_id, email_status)
    VALUES ('new_message', ?, ?, ?, 'in_app')
  `).run(
    `رسالة جديدة من ${order.customer_name}`,
    `الطلب ${order.tracking_code}: ${text || uploadedFile?.originalname || 'مرفق جديد'}`,
    order.id
  );

  const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(order.id);
  res.json(hydrateOrder(updated));
});

// Customer submits 5-star review (only after ready, once per order)
app.post('/api/orders/:trackingCode/review', (req, res) => {
  const { trackingCode } = req.params;
  const order = db.prepare('SELECT * FROM orders WHERE UPPER(tracking_code) = UPPER(?)').get(trackingCode) as any;
  if (!order) {
    res.status(404).json({ error: 'الطلب غير موجود.' });
    return;
  }
  if (order.status !== 'completed' && order.status !== 'delivered_picked_up') {
    res.status(400).json({ error: 'التقييم متاح فقط بعد إتمام تنفيذ الطلب أو تسليمه.' });
    return;
  }

  const existing = db.prepare('SELECT id FROM reviews WHERE order_id = ?').get(order.id);
  if (existing) {
    res.status(409).json({ error: 'تم تقييم هذا الطلب مسبقاً، شكراً لمشاركتك.' });
    return;
  }

  const rating = Math.min(5, Math.max(1, Math.round(Number(req.body.rating) || 0)));
  const category = ['rating', 'suggestion', 'complaint'].includes(req.body.category) ? req.body.category : 'rating';
  const comment = String(req.body.comment || '').trim().slice(0, 1000);

  if (rating < 1 || rating > 5) {
    res.status(400).json({ error: 'يرجى اختيار تقييم من 1 إلى 5 نجوم.' });
    return;
  }

  db.prepare(`
    INSERT INTO reviews (order_id, tracking_code, customer_name, rating, category, comment)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(order.id, order.tracking_code, order.customer_name, rating, category, comment);

  db.prepare(`
    INSERT INTO admin_notifications (type, title, body, order_id, email_status)
    VALUES ('new_review', ?, ?, ?, 'in_app')
  `).run(
    `تقييم جديد (${rating}/5) للطلب ${order.tracking_code}`,
    comment || 'بدون تعليق إضافي',
    order.id
  );

  res.status(201).json({ success: true });
});

// ============================================================================
// ADMIN AUTHENTICATION ROUTES
// ============================================================================

app.post('/api/admin/login', (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');

  // Strictly block legacy weak default passcode
  if (!password || password === '1234') {
    res.status(401).json({ error: 'كلمة المرور غير صحيحة.' });
    return;
  }

  // Staff login if username provided and not 'admin'
  if (username && username.toLowerCase() !== 'admin') {
    const staff = db
      .prepare('SELECT * FROM staff_users WHERE username = ? AND active = 1')
      .get(username) as any;
    if (!staff || !verifyPassword(password, staff.password_hash)) {
      res.status(401).json({ error: 'بيانات الدخول غير صحيحة.' });
      return;
    }
    const permissions = JSON.parse(staff.permissions_json || '[]') as string[];
    const token = signSessionToken({
      userId: staff.id,
      username: staff.username,
      displayName: staff.display_name,
      role: staff.role,
      permissions,
      exp: Date.now() + 1000 * 60 * 60 * 12,
    });
    setAdminSessionCookie(req, res, token);
    res.json({
      authenticated: true,
      token,
      user: { userId: staff.id, username: staff.username, displayName: staff.display_name, role: staff.role, permissions },
    });
    return;
  }

  // Master Admin password verification
  const storedHash = getSetting('admin_password_hash');
  if (!verifyPassword(password, storedHash)) {
    res.status(401).json({ error: 'كلمة المرور غير صحيحة.' });
    return;
  }

  const token = signSessionToken({
    userId: 'master',
    username: 'admin',
    displayName: 'الإدارة العامة',
    role: 'admin',
    permissions: ALL_PERMISSIONS,
    exp: Date.now() + 1000 * 60 * 60 * 12,
  });

  setAdminSessionCookie(req, res, token);

  res.json({
    authenticated: true,
    token,
    user: { userId: 'master', username: 'admin', displayName: 'الإدارة العامة', role: 'admin', permissions: ALL_PERMISSIONS },
  });
});

app.post('/api/admin/logout', (req, res) => {
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.clearCookie('go_admin_session', { path: '/', sameSite: isHttps ? 'none' : 'lax', secure: isHttps });
  res.json({ success: true });
});

app.get('/api/admin/me', (req: AuthedRequest, res) => {
  const token = parseCookieToken(req);
  const session = token ? verifySessionToken(token) : null;
  if (!session) {
    res.status(401).json({ authenticated: false });
    return;
  }
  res.json({ authenticated: true, token, user: session });
});

// ============================================================================
// ADMIN PROTECTED ROUTES
// ============================================================================

app.get('/api/admin/orders', requireAdmin('orders'), (_req, res) => {
  const rows = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
  res.json(rows.map(hydrateOrder));
});

app.patch('/api/admin/orders/:id', requireAdmin('orders'), (req, res) => {
  const orderId = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!existing) {
    res.status(404).json({ error: 'Order not found.' });
    return;
  }

  const nextStatus = (req.body.status || existing.status) as OrderStatus;
  const validStatuses: OrderStatus[] = ['sent', 'seen', 'in_progress', 'completed', 'delivered_picked_up'];
  if (!validStatuses.includes(nextStatus)) {
    res.status(400).json({ error: 'Invalid status.' });
    return;
  }

  const nextCustomRequests = req.body.custom_requests !== undefined
    ? JSON.stringify(req.body.custom_requests)
    : existing.custom_requests_json;
  const nextTotalPrice = req.body.total_price !== undefined ? Number(req.body.total_price) : existing.total_price;
  const nextCustomStatus = req.body.custom_price_status || existing.custom_price_status;
  const nextDeliveryFee = req.body.delivery_fee !== undefined ? Number(req.body.delivery_fee) : existing.delivery_fee;
  const nextNotes = req.body.notes !== undefined ? String(req.body.notes) : existing.notes;

  db.prepare(`
    UPDATE orders
    SET status = ?, custom_requests_json = ?, total_price = ?, custom_price_status = ?, delivery_fee = ?, notes = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(nextStatus, nextCustomRequests, nextTotalPrice, nextCustomStatus, nextDeliveryFee, nextNotes, orderId);

  // Notify customer in thread if status changed or quote sent
  if (nextStatus !== existing.status) {
    const statusLabels: Record<OrderStatus, string> = {
      sent: 'تم الإرسال',
      seen: 'تمت المعاينة',
      in_progress: 'قيد التنفيذ',
      completed: 'تم التنفيذ',
      delivered_picked_up: 'تم التوصيل والاستلام',
    };
    db.prepare('INSERT INTO order_messages (order_id, sender, message_text) VALUES (?, ?, ?)').run(
      orderId,
      'admin',
      `تم تحديث حالة طلبك إلى: ${statusLabels[nextStatus]}.`
    );
  }

  // Sync accounting income entry when order is completed/delivered or priced
  const isCompletedOrDelivered = nextStatus === 'completed' || nextStatus === 'delivered_picked_up';
  if ((isCompletedOrDelivered || nextStatus === 'seen' || nextCustomStatus === 'quoted') && nextTotalPrice > 0) {
    const existingAcc = db.prepare("SELECT id FROM accounting_entries WHERE order_id = ? AND category = 'orders'").get(orderId) as
      | { id: number }
      | undefined;
    if (existingAcc) {
      db.prepare('UPDATE accounting_entries SET amount = ?, description = ? WHERE id = ?').run(
        nextTotalPrice,
        `طلب ${existing.tracking_code} — ${existing.customer_name}`,
        existingAcc.id
      );
    } else if (isCompletedOrDelivered) {
      db.prepare(`
        INSERT INTO accounting_entries (entry_type, category, description, amount, order_id, entry_date)
        VALUES ('income', 'orders', ?, ?, ?, date('now'))
      `).run(`طلب ${existing.tracking_code} — ${existing.customer_name}`, nextTotalPrice, orderId);
    }
  }

  const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  res.json(hydrateOrder(updated));
});

app.post('/api/admin/orders/:id/messages', requireAdmin('orders'), upload.single('file'), (req, res) => {
  const orderId = Number(req.params.id);
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) {
    res.status(404).json({ error: 'Order not found.' });
    return;
  }

  const text = String(req.body.message_text || '').trim();
  const uploadedFile = req.file;
  if (!text && !uploadedFile) {
    res.status(400).json({ error: 'Message or file required.' });
    return;
  }

  let fileId: number | null = null;
  if (uploadedFile) {
    const fInfo = db
      .prepare('INSERT INTO order_files (order_id, original_name, stored_name, mime_type, size_bytes, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)')
      .run(orderId, uploadedFile.originalname, uploadedFile.filename, uploadedFile.mimetype, uploadedFile.size, 'admin');
    fileId = Number(fInfo.lastInsertRowid);
  }

  db.prepare('INSERT INTO order_messages (order_id, sender, message_text, attachment_file_id) VALUES (?, ?, ?, ?)').run(
    orderId,
    'admin',
    text,
    fileId
  );

  const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  res.json(hydrateOrder(updated));
});

// Admin imports/attaches files directly to an order
app.post('/api/admin/orders/:id/files', requireAdmin('orders'), upload.array('files', 10), (req, res) => {
  const orderId = Number(req.params.id);
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId) as any;
  if (!order) {
    res.status(404).json({ error: 'Order not found.' });
    return;
  }
  const uploadedFiles = (req.files as Express.Multer.File[]) || [];
  if (uploadedFiles.length === 0) {
    res.status(400).json({ error: 'يرجى اختيار ملف واحد على الأقل.' });
    return;
  }
  const insertFile = db.prepare(`
    INSERT INTO order_files (order_id, original_name, stored_name, mime_type, size_bytes, uploaded_by)
    VALUES (?, ?, ?, ?, ?, 'admin')
  `);
  for (const f of uploadedFiles) {
    insertFile.run(orderId, f.originalname, f.filename, f.mimetype, f.size);
  }
  const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  res.json(hydrateOrder(updated));
});

// Permanent Order Delete (deletes files from disk and DB permanently)
app.delete('/api/admin/orders/:id', requireAdmin('orders'), (req, res) => {
  const orderId = Number(req.params.id);
  const files = db.prepare('SELECT stored_name FROM order_files WHERE order_id = ?').all(orderId) as { stored_name: string }[];
  for (const f of files) {
    const full = path.join(UPLOADS_DIR, f.stored_name);
    if (fs.existsSync(full)) {
      try {
        fs.unlinkSync(full);
      } catch {
        // continue
      }
    }
  }
  const result = db.prepare('DELETE FROM orders WHERE id = ?').run(orderId);
  if (result.changes === 0) {
    res.status(404).json({ error: 'Order not found.' });
    return;
  }
  res.json({ success: true, deletedId: orderId });
});

// Admin Services & Pricing CRUD
app.get('/api/admin/services', requireAdmin('pricing'), (_req, res) => {
  res.json(db.prepare('SELECT * FROM services ORDER BY sort_order ASC, id ASC').all());
});

app.post('/api/admin/services', requireAdmin('pricing'), (req, res) => {
  const b = req.body;
  const maxOrder = (db.prepare('SELECT COALESCE(MAX(sort_order), 0) as m FROM services').get() as { m: number }).m;
  const info = db
    .prepare(`
      INSERT INTO services (
        category, name_ar, name_fr, name_en, price, price_max,
        unit_label_ar, unit_label_fr, unit_label_en,
        min_qty, setup_design_fee, print_unit_price,
        pricing_note_ar, pricing_note_fr, pricing_note_en, active, sort_order
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .run(
      b.category || 'printing',
      String(b.name_ar || '').trim(),
      String(b.name_fr || b.name_ar || '').trim(),
      String(b.name_en || b.name_ar || '').trim(),
      Number(b.price) || 0,
      b.price_max ? Number(b.price_max) : null,
      b.unit_label_ar || 'وحدة',
      b.unit_label_fr || 'unité',
      b.unit_label_en || 'unit',
      Math.max(1, Number(b.min_qty) || 1),
      Number(b.setup_design_fee) || 0,
      b.print_unit_price !== null && b.print_unit_price !== undefined && b.print_unit_price !== '' ? Number(b.print_unit_price) : null,
      b.pricing_note_ar || '',
      b.pricing_note_fr || '',
      b.pricing_note_en || '',
      b.active === 0 ? 0 : 1,
      maxOrder + 1
    );
  res.status(201).json(db.prepare('SELECT * FROM services WHERE id = ?').get(info.lastInsertRowid));
});

app.patch('/api/admin/services/:id', requireAdmin('pricing'), (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM services WHERE id = ?').get(id) as any;
  if (!existing) {
    res.status(404).json({ error: 'Service not found.' });
    return;
  }
  const b = req.body;
  db.prepare(`
    UPDATE services SET
      category = ?, name_ar = ?, name_fr = ?, name_en = ?, price = ?, price_max = ?,
      unit_label_ar = ?, unit_label_fr = ?, unit_label_en = ?,
      min_qty = ?, setup_design_fee = ?, print_unit_price = ?,
      pricing_note_ar = ?, pricing_note_fr = ?, pricing_note_en = ?, active = ?
    WHERE id = ?
  `).run(
    b.category ?? existing.category,
    b.name_ar ?? existing.name_ar,
    b.name_fr ?? existing.name_fr,
    b.name_en ?? existing.name_en,
    b.price !== undefined ? Number(b.price) : existing.price,
    b.price_max !== undefined ? (b.price_max ? Number(b.price_max) : null) : existing.price_max,
    b.unit_label_ar ?? existing.unit_label_ar,
    b.unit_label_fr ?? existing.unit_label_fr,
    b.unit_label_en ?? existing.unit_label_en,
    b.min_qty !== undefined ? Math.max(1, Number(b.min_qty)) : existing.min_qty,
    b.setup_design_fee !== undefined ? Number(b.setup_design_fee) : existing.setup_design_fee,
    b.print_unit_price !== undefined ? (b.print_unit_price !== null && b.print_unit_price !== '' ? Number(b.print_unit_price) : null) : existing.print_unit_price,
    b.pricing_note_ar ?? existing.pricing_note_ar,
    b.pricing_note_fr ?? existing.pricing_note_fr,
    b.pricing_note_en ?? existing.pricing_note_en,
    b.active !== undefined ? (b.active ? 1 : 0) : existing.active,
    id
  );
  res.json(db.prepare('SELECT * FROM services WHERE id = ?').get(id));
});

app.delete('/api/admin/services/:id', requireAdmin('pricing'), (req, res) => {
  const id = Number(req.params.id);
  db.prepare('DELETE FROM services WHERE id = ?').run(id);
  res.json({ success: true });
});

app.post('/api/admin/services/import', requireAdmin('pricing'), (req, res) => {
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (items.length === 0) {
    res.status(400).json({ error: 'لا توجد خدمات صالحة للاستيراد.' });
    return;
  }
  let maxOrder = (db.prepare('SELECT COALESCE(MAX(sort_order), 0) as m FROM services').get() as { m: number }).m;
  const ins = db.prepare(`
    INSERT INTO services (
      category, name_ar, name_fr, name_en, price, price_max,
      unit_label_ar, unit_label_fr, unit_label_en,
      min_qty, setup_design_fee, print_unit_price,
      pricing_note_ar, pricing_note_fr, pricing_note_en, active, sort_order
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
  `);
  let importedCount = 0;
  const tx = db.transaction(() => {
    for (const b of items) {
      const nameAr = String(b.name_ar || b.name || '').trim();
      if (!nameAr) continue;
      maxOrder += 1;
      const cat = ['printing', 'admin', 'design'].includes(b.category) ? b.category : 'printing';
      ins.run(
        cat,
        nameAr,
        String(b.name_fr || nameAr).trim(),
        String(b.name_en || nameAr).trim(),
        Number(b.price) || 0,
        b.price_max ? Number(b.price_max) : null,
        String(b.unit_label_ar || 'وحدة'),
        String(b.unit_label_fr || 'unité'),
        String(b.unit_label_en || 'unit'),
        Math.max(1, Number(b.min_qty) || 1),
        Number(b.setup_design_fee) || 0,
        b.print_unit_price !== null && b.print_unit_price !== undefined && b.print_unit_price !== '' ? Number(b.print_unit_price) : null,
        String(b.pricing_note_ar || ''),
        String(b.pricing_note_fr || ''),
        String(b.pricing_note_en || ''),
        maxOrder
      );
      importedCount += 1;
    }
  });
  tx();
  res.status(201).json({ importedCount });
});

app.post('/api/admin/accounting/import', requireAdmin('accounting'), (req, res) => {
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (items.length === 0) {
    res.status(400).json({ error: 'لا توجد قيود مالية صالحة للاستيراد.' });
    return;
  }
  const ins = db.prepare(`
    INSERT INTO accounting_entries (entry_type, category, description, amount, order_id, entry_date)
    VALUES (?, ?, ?, ?, NULL, ?)
  `);
  let importedCount = 0;
  const tx = db.transaction(() => {
    for (const b of items) {
      const desc = String(b.description || '').trim();
      if (!desc) continue;
      const type = b.entry_type === 'expense' || b.type === 'expense' ? 'expense' : 'income';
      const amt = Math.max(0, Number(b.amount) || 0);
      const dt = String(b.entry_date || b.date || new Date().toISOString().slice(0, 10)).slice(0, 10);
      ins.run(type, String(b.category || 'imported'), desc, amt, dt);
      importedCount += 1;
    }
  });
  tx();
  res.status(201).json({ importedCount });
});

// Accounting & Inventory
app.get('/api/admin/accounting', requireAdmin('accounting'), (_req, res) => {
  const entries = db.prepare('SELECT * FROM accounting_entries ORDER BY entry_date DESC, id DESC').all() as any[];
  const inventory = db.prepare('SELECT * FROM inventory_items ORDER BY id ASC').all();

  const sumByPeriod = (sqlCondition: string) => {
    const rows = db
      .prepare(`SELECT entry_type, COALESCE(SUM(amount), 0) as total FROM accounting_entries WHERE ${sqlCondition} GROUP BY entry_type`)
      .all() as { entry_type: 'income' | 'expense'; total: number }[];
    const income = rows.find((r) => r.entry_type === 'income')?.total || 0;
    const expense = rows.find((r) => r.entry_type === 'expense')?.total || 0;
    return { income, expense, profit: income - expense };
  };

  res.json({
    entries,
    inventory,
    totals: {
      daily: sumByPeriod("entry_date = date('now')"),
      weekly: sumByPeriod("entry_date >= date('now', '-6 days')"),
      monthly: sumByPeriod("strftime('%Y-%m', entry_date) = strftime('%Y-%m', 'now')"),
      yearly: sumByPeriod("strftime('%Y', entry_date) = strftime('%Y', 'now')"),
      allTime: sumByPeriod('1=1'),
    },
  });
});

app.post('/api/admin/accounting', requireAdmin('accounting'), (req, res) => {
  const b = req.body;
  const info = db
    .prepare(`
      INSERT INTO accounting_entries (entry_type, category, description, amount, order_id, entry_date)
      VALUES (?, ?, ?, ?, ?, ?)
    `)
    .run(
      b.entry_type === 'expense' ? 'expense' : 'income',
      String(b.category || 'general'),
      String(b.description || '').trim(),
      Math.max(0, Number(b.amount) || 0),
      b.order_id ? Number(b.order_id) : null,
      b.entry_date || new Date().toISOString().slice(0, 10)
    );
  res.status(201).json(db.prepare('SELECT * FROM accounting_entries WHERE id = ?').get(info.lastInsertRowid));
});

app.delete('/api/admin/accounting/:id', requireAdmin('accounting'), (req, res) => {
  db.prepare('DELETE FROM accounting_entries WHERE id = ?').run(Number(req.params.id));
  res.json({ success: true });
});

app.post('/api/admin/inventory', requireAdmin('accounting'), (req, res) => {
  const b = req.body;
  const info = db
    .prepare(`
      INSERT INTO inventory_items (name, category, quantity, unit, unit_cost, min_threshold)
      VALUES (?, ?, ?, ?, ?, ?)
    `)
    .run(
      String(b.name || '').trim(),
      b.category || 'supplies',
      Number(b.quantity) || 0,
      String(b.unit || 'وحدة'),
      Number(b.unit_cost) || 0,
      Number(b.min_threshold) || 5
    );
  res.status(201).json(db.prepare('SELECT * FROM inventory_items WHERE id = ?').get(info.lastInsertRowid));
});

app.patch('/api/admin/inventory/:id', requireAdmin('accounting'), (req, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare('SELECT * FROM inventory_items WHERE id = ?').get(id) as any;
  if (!existing) {
    res.status(404).json({ error: 'Item not found.' });
    return;
  }
  const b = req.body;
  db.prepare(`
    UPDATE inventory_items
    SET name = ?, category = ?, quantity = ?, unit = ?, unit_cost = ?, min_threshold = ?, updated_at = datetime('now')
    WHERE id = ?
  `).run(
    b.name ?? existing.name,
    b.category ?? existing.category,
    b.quantity !== undefined ? Number(b.quantity) : existing.quantity,
    b.unit ?? existing.unit,
    b.unit_cost !== undefined ? Number(b.unit_cost) : existing.unit_cost,
    b.min_threshold !== undefined ? Number(b.min_threshold) : existing.min_threshold,
    id
  );
  res.json(db.prepare('SELECT * FROM inventory_items WHERE id = ?').get(id));
});

app.delete('/api/admin/inventory/:id', requireAdmin('accounting'), (req, res) => {
  db.prepare('DELETE FROM inventory_items WHERE id = ?').run(Number(req.params.id));
  res.json({ success: true });
});

// Reviews (Admin only!)
app.get('/api/admin/reviews', requireAdmin('reviews'), (_req, res) => {
  const reviews = db.prepare('SELECT * FROM reviews ORDER BY created_at DESC').all();
  const stats = db.prepare('SELECT COUNT(*) as total, AVG(rating) as average FROM reviews').get() as any;
  res.json({
    reviews,
    total: stats.total || 0,
    average: stats.average ? Math.round(stats.average * 10) / 10 : 0,
  });
});

// Notifications
app.get('/api/admin/notifications', requireAdmin(), (_req, res) => {
  const list = db.prepare('SELECT * FROM admin_notifications ORDER BY id DESC LIMIT 50').all();
  const unread = (db.prepare('SELECT COUNT(*) as c FROM admin_notifications WHERE is_read = 0').get() as { c: number }).c;
  res.json({ notifications: list, unreadCount: unread });
});

app.post('/api/admin/notifications/read-all', requireAdmin(), (_req, res) => {
  db.prepare('UPDATE admin_notifications SET is_read = 1').run();
  res.json({ success: true });
});

// Settings & Office Location & Print Lock
app.get('/api/admin/settings', requireAdmin(), (_req, res) => {
  res.json({
    officeName: getSetting('office_name') || 'Graphicore Office',
    officeLogo: getSetting('office_logo') || '',
    officeAddress: getSetting('office_address'),
    officeLat: parseFloat(getSetting('office_lat') || '36.7538'),
    officeLng: parseFloat(getSetting('office_lng') || '3.0588'),
    adminEmail: getSetting('admin_email'),
    workingHoursMorning: getSetting('working_hours_morning'),
    workingHoursEvening: getSetting('working_hours_evening'),
    deliveryBaseFee: parseFloat(getSetting('delivery_base_fee') || '200'),
    deliveryEnabled: getSetting('delivery_enabled') !== '0',
    showSatisfactionSummary: getSetting('show_satisfaction_summary') !== '0',
    customCategories: getCustomCategoriesConfig(),
    printLockEnabled: getSetting('print_lock_enabled') === '1',
    hasPrintPin: Boolean(getSetting('print_lock_pin_hash')),
  });
});

app.put('/api/admin/settings', requireAdmin('settings'), (req, res) => {
  const b = req.body;
  if (b.officeName !== undefined) setSetting('office_name', String(b.officeName).trim() || 'Graphicore Office');
  if (b.officeLogo !== undefined && b.officeLogo === '') {
    const oldFile = getSetting('office_logo_file');
    if (oldFile) {
      const p = path.join(UPLOADS_DIR, path.basename(oldFile));
      if (fs.existsSync(p)) {
        try {
          fs.unlinkSync(p);
        } catch {
          // ignore
        }
      }
    }
    setSetting('office_logo', '');
    setSetting('office_logo_file', '');
  }
  if (b.officeAddress !== undefined) setSetting('office_address', String(b.officeAddress));
  if (b.officeLat !== undefined) setSetting('office_lat', String(b.officeLat));
  if (b.officeLng !== undefined) setSetting('office_lng', String(b.officeLng));
  if (b.adminEmail !== undefined) setSetting('admin_email', String(b.adminEmail));
  if (b.workingHoursMorning !== undefined) setSetting('working_hours_morning', String(b.workingHoursMorning));
  if (b.workingHoursEvening !== undefined) setSetting('working_hours_evening', String(b.workingHoursEvening));
  if (b.deliveryBaseFee !== undefined) setSetting('delivery_base_fee', String(Math.max(0, Number(b.deliveryBaseFee) || 0)));
  if (b.deliveryEnabled !== undefined) setSetting('delivery_enabled', b.deliveryEnabled ? '1' : '0');
  if (b.showSatisfactionSummary !== undefined) setSetting('show_satisfaction_summary', b.showSatisfactionSummary ? '1' : '0');
  if (b.customCategories) {
    if (b.customCategories.printing) {
      setSetting('custom_printing_enabled', b.customCategories.printing.enabled ? '1' : '0');
      if (b.customCategories.printing.label_ar !== undefined) {
        setSetting('custom_printing_label', String(b.customCategories.printing.label_ar));
      }
    }
    if (b.customCategories.admin) {
      setSetting('custom_admin_enabled', b.customCategories.admin.enabled ? '1' : '0');
      if (b.customCategories.admin.label_ar !== undefined) {
        setSetting('custom_admin_label', String(b.customCategories.admin.label_ar));
      }
    }
    if (b.customCategories.design) {
      setSetting('custom_design_enabled', b.customCategories.design.enabled ? '1' : '0');
      if (b.customCategories.design.label_ar !== undefined) {
        setSetting('custom_design_label', String(b.customCategories.design.label_ar));
      }
    }
  }
  if (b.printLockEnabled !== undefined) setSetting('print_lock_enabled', b.printLockEnabled ? '1' : '0');
  if (b.printLockPin && String(b.printLockPin).trim().length >= 4 && String(b.printLockPin) !== '1234') {
    setSetting('print_lock_pin_hash', hashPassword(String(b.printLockPin).trim()));
  }
  res.json({ success: true });
});

// Update custom categories directly from Services & Pricing tab (requires 'pricing' permission)
app.put('/api/admin/custom-categories', requireAdmin('pricing'), (req, res) => {
  const b = req.body || {};
  for (const cat of ['printing', 'admin', 'design'] as const) {
    if (b[cat]) {
      setSetting(`custom_${cat}_enabled`, b[cat].enabled ? '1' : '0');
      if (b[cat].label_ar !== undefined) {
        setSetting(`custom_${cat}_label`, String(b[cat].label_ar));
      }
    }
  }
  res.json({ customCategories: getCustomCategoriesConfig() });
});

// Admin-only File Import Vault (documents, templates, imported assets)
app.get('/api/admin/vault-files', requireAdmin(), (_req, res) => {
  res.json(db.prepare('SELECT * FROM admin_vault_files ORDER BY id DESC').all());
});

app.post('/api/admin/vault-files', requireAdmin(), upload.array('files', 10), (req, res) => {
  const files = (req.files as Express.Multer.File[]) || [];
  if (files.length === 0) {
    res.status(400).json({ error: 'يرجى اختيار ملف واحد على الأقل للاستيراد.' });
    return;
  }
  const category = String(req.body?.category || 'general');
  const notes = String(req.body?.notes || '');
  const ins = db.prepare(`
    INSERT INTO admin_vault_files (original_name, stored_name, mime_type, size_bytes, category, notes)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const inserted: any[] = [];
  for (const f of files) {
    const info = ins.run(f.originalname, f.filename, f.mimetype, f.size, category, notes);
    inserted.push(db.prepare('SELECT * FROM admin_vault_files WHERE id = ?').get(info.lastInsertRowid));
  }
  res.status(201).json(inserted);
});

app.get('/api/admin/vault-files/:id', requireAdmin(), (req, res) => {
  const row = db.prepare('SELECT * FROM admin_vault_files WHERE id = ?').get(Number(req.params.id)) as any;
  if (!row) {
    res.status(404).json({ error: 'File not found.' });
    return;
  }
  const fullPath = path.join(UPLOADS_DIR, path.basename(row.stored_name));
  if (!fs.existsSync(fullPath)) {
    res.status(404).json({ error: 'File missing on disk.' });
    return;
  }
  res.setHeader('Content-Type', row.mime_type || 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(row.original_name)}"`);
  fs.createReadStream(fullPath).pipe(res);
});

app.delete('/api/admin/vault-files/:id', requireAdmin(), (req, res) => {
  const id = Number(req.params.id);
  const row = db.prepare('SELECT * FROM admin_vault_files WHERE id = ?').get(id) as any;
  if (row) {
    const fullPath = path.join(UPLOADS_DIR, path.basename(row.stored_name));
    if (fs.existsSync(fullPath)) {
      try {
        fs.unlinkSync(fullPath);
      } catch {
        // ignore
      }
    }
    db.prepare('DELETE FROM admin_vault_files WHERE id = ?').run(id);
  }
  res.json({ success: true });
});

app.post('/api/admin/logo', requireAdmin('settings'), upload.single('logo'), (req, res) => {
  const file = req.file;
  if (!file) {
    res.status(400).json({ error: 'يرجى اختيار ملف صورة للشعار.' });
    return;
  }
  if (!file.mimetype.startsWith('image/')) {
    try {
      fs.unlinkSync(path.join(UPLOADS_DIR, file.filename));
    } catch {
      // ignore
    }
    res.status(400).json({ error: 'يجب أن يكون الشعار بصيغة صورة (PNG, JPG, SVG, WebP).' });
    return;
  }
  const prev = getSetting('office_logo_file');
  if (prev && prev !== file.filename) {
    const oldPath = path.join(UPLOADS_DIR, path.basename(prev));
    if (fs.existsSync(oldPath)) {
      try {
        fs.unlinkSync(oldPath);
      } catch {
        // ignore
      }
    }
  }
  const logoUrl = `/api/public/logo?v=${Date.now()}`;
  setSetting('office_logo_file', file.filename);
  setSetting('office_logo', logoUrl);
  res.json({ officeLogo: logoUrl });
});

app.delete('/api/admin/logo', requireAdmin('settings'), (_req, res) => {
  const prev = getSetting('office_logo_file');
  if (prev) {
    const oldPath = path.join(UPLOADS_DIR, path.basename(prev));
    if (fs.existsSync(oldPath)) {
      try {
        fs.unlinkSync(oldPath);
      } catch {
        // ignore
      }
    }
  }
  setSetting('office_logo_file', '');
  setSetting('office_logo', '');
  res.json({ success: true, officeLogo: '' });
});

app.post('/api/admin/print-unlock', requireAdmin('printing'), (req, res) => {
  const lockEnabled = getSetting('print_lock_enabled') === '1';
  if (!lockEnabled) {
    res.json({ unlocked: true });
    return;
  }
  const pinHash = getSetting('print_lock_pin_hash');
  const pin = String(req.body.pin || '');
  if (pinHash) {
    if (!verifyPassword(pin, pinHash)) {
      res.status(403).json({ error: 'رمز قفل الطباعة غير صحيح.' });
      return;
    }
    res.json({ unlocked: true });
    return;
  }
  // Fallback: verify against master admin password if print lock is enabled without separate PIN
  const masterHash = getSetting('admin_password_hash');
  if (!verifyPassword(pin, masterHash)) {
    res.status(403).json({ error: 'رمز قفل الطباعة غير صحيح.' });
    return;
  }
  res.json({ unlocked: true });
});

// Staff Management & Security
app.get('/api/admin/staff', requireAdmin('staff'), (_req, res) => {
  const rows = db.prepare('SELECT id, username, display_name, role, permissions_json, active, created_at FROM staff_users ORDER BY id ASC').all() as any[];
  res.json(rows.map((r) => ({ ...r, permissions: JSON.parse(r.permissions_json || '[]') })));
});

app.post('/api/admin/staff', requireAdmin('staff'), (req, res) => {
  const b = req.body;
  const username = String(b.username || '').trim();
  const displayName = String(b.display_name || '').trim();
  const password = String(b.password || '');
  const role = ['admin', 'manager', 'operator', 'delivery'].includes(b.role) ? b.role : 'operator';
  const permissions = Array.isArray(b.permissions) ? b.permissions : [];

  if (!username || !displayName || password.length < 6 || password === '1234') {
    res.status(400).json({ error: 'يرجى إدخال اسم مستخدم وكلمة مرور قوية (6 أحرف على الأقل).' });
    return;
  }
  try {
    const info = db
      .prepare('INSERT INTO staff_users (username, display_name, role, permissions_json, password_hash) VALUES (?, ?, ?, ?, ?)')
      .run(username, displayName, role, JSON.stringify(permissions), hashPassword(password));
    const created = db.prepare('SELECT id, username, display_name, role, permissions_json, active, created_at FROM staff_users WHERE id = ?').get(info.lastInsertRowid) as any;
    res.status(201).json({ ...created, permissions: JSON.parse(created.permissions_json || '[]') });
  } catch {
    res.status(409).json({ error: 'اسم المستخدم موجود مسبقاً.' });
  }
});

app.delete('/api/admin/staff/:id', requireAdmin('staff'), (req, res) => {
  db.prepare('DELETE FROM staff_users WHERE id = ?').run(Number(req.params.id));
  res.json({ success: true });
});

app.post('/api/admin/change-password', requireAdmin('staff'), (req, res) => {
  const currentPassword = String(req.body.currentPassword || '');
  const newPassword = String(req.body.newPassword || '');
  if (newPassword.length < 8 || newPassword === '1234') {
    res.status(400).json({ error: 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل.' });
    return;
  }
  const stored = getSetting('admin_password_hash');
  if (!verifyPassword(currentPassword, stored)) {
    res.status(403).json({ error: 'كلمة المرور الحالية غير صحيحة.' });
    return;
  }
  setSetting('admin_password_hash', hashPassword(newPassword));
  res.json({ success: true });
});

// Database Backup & Restore
app.get('/api/admin/backup', requireAdmin('settings'), (_req, res) => {
  const backup = {
    exportedAt: new Date().toISOString(),
    version: 1,
    services: db.prepare('SELECT * FROM services').all(),
    orders: db.prepare('SELECT * FROM orders').all(),
    order_files: db.prepare('SELECT * FROM order_files').all(),
    order_messages: db.prepare('SELECT * FROM order_messages').all(),
    reviews: db.prepare('SELECT * FROM reviews').all(),
    accounting_entries: db.prepare('SELECT * FROM accounting_entries').all(),
    inventory_items: db.prepare('SELECT * FROM inventory_items').all(),
    settings: db.prepare("SELECT key, value FROM settings WHERE key NOT IN ('admin_password_hash', 'session_secret', 'print_lock_pin_hash')").all(),
  };
  res.setHeader('Content-Disposition', `attachment; filename="graphicore-backup-${new Date().toISOString().slice(0, 10)}.json"`);
  res.json(backup);
});

app.post('/api/admin/restore', requireAdmin('settings'), (req, res) => {
  const backup = req.body;
  if (!backup || !Array.isArray(backup.services) || !Array.isArray(backup.orders)) {
    res.status(400).json({ error: 'ملف النسخة الاحتياطية غير صالح.' });
    return;
  }
  const tx = db.transaction(() => {
    if (Array.isArray(backup.settings)) {
      const upSet = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
      for (const s of backup.settings) {
        if (s.key && !['admin_password_hash', 'session_secret', 'print_lock_pin_hash'].includes(s.key)) {
          upSet.run(s.key, String(s.value));
        }
      }
    }
    if (Array.isArray(backup.services)) {
      db.prepare('DELETE FROM services').run();
      const ins = db.prepare(`
        INSERT INTO services (id, category, name_ar, name_fr, name_en, price, price_max, unit_label_ar, unit_label_fr, unit_label_en, min_qty, setup_design_fee, print_unit_price, pricing_note_ar, pricing_note_fr, pricing_note_en, active, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const s of backup.services) {
        ins.run(s.id, s.category, s.name_ar, s.name_fr, s.name_en, s.price, s.price_max, s.unit_label_ar, s.unit_label_fr, s.unit_label_en, s.min_qty, s.setup_design_fee, s.print_unit_price, s.pricing_note_ar, s.pricing_note_fr, s.pricing_note_en, s.active, s.sort_order);
      }
    }
    if (Array.isArray(backup.inventory_items)) {
      db.prepare('DELETE FROM inventory_items').run();
      const insInv = db.prepare('INSERT INTO inventory_items (id, name, category, quantity, unit, unit_cost, min_threshold, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
      for (const i of backup.inventory_items) {
        insInv.run(i.id, i.name, i.category, i.quantity, i.unit, i.unit_cost, i.min_threshold, i.updated_at);
      }
    }
    if (Array.isArray(backup.orders)) {
      db.prepare('DELETE FROM orders').run();
      const insOrd = db.prepare(`
        INSERT INTO orders (id, tracking_code, customer_name, customer_phone, items_json, custom_requests_json, total_price, custom_price_status, notes, pickup_type, pickup_datetime, delivery_requested, delivery_lat, delivery_lng, delivery_address, delivery_fee, terms_accepted, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const o of backup.orders) {
        insOrd.run(o.id, o.tracking_code, o.customer_name, o.customer_phone, o.items_json, o.custom_requests_json, o.total_price, o.custom_price_status, o.notes, o.pickup_type, o.pickup_datetime, o.delivery_requested, o.delivery_lat, o.delivery_lng, o.delivery_address, o.delivery_fee, o.terms_accepted, o.status, o.created_at, o.updated_at);
      }
    }
    if (Array.isArray(backup.accounting_entries)) {
      db.prepare('DELETE FROM accounting_entries').run();
      const insAcc = db.prepare('INSERT INTO accounting_entries (id, entry_type, category, description, amount, order_id, entry_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
      for (const a of backup.accounting_entries) {
        insAcc.run(a.id, a.entry_type, a.category, a.description, a.amount, a.order_id, a.entry_date, a.created_at);
      }
    }
    if (Array.isArray(backup.reviews)) {
      db.prepare('DELETE FROM reviews').run();
      const insRev = db.prepare('INSERT INTO reviews (id, order_id, tracking_code, customer_name, rating, category, comment, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
      for (const r of backup.reviews) {
        insRev.run(r.id, r.order_id, r.tracking_code, r.customer_name, r.rating, r.category, r.comment, r.created_at);
      }
    }
  });
  tx();
  res.json({ success: true });
});

// AI Business Advisor (Strictly Admin Only!)
app.post('/api/admin/ai-advisor', requireAdmin('ai_advisor'), async (req, res) => {
  try {
    const lang = (req.body?.language === 'fr' || req.body?.language === 'en' ? req.body.language : 'ar') as 'ar' | 'fr' | 'en';
    const report = await generateAiBusinessReport(lang);
    res.json(report);
  } catch (err: any) {
    console.error('AI Advisor error:', err);
    res.status(500).json({ error: err?.message || 'فشل تشغيل مستشار الأعمال الذكي.' });
  }
});

// JSON error middleware for /api/* (e.g. multer file size/count errors)
app.use('/api', (err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('API Error:', err);
  if (err && err.code === 'LIMIT_FILE_SIZE') {
    res.status(413).json({ error: 'حجم أحد الملفات المرفوعة يتجاوز الحد المسموح (20 ميجابايت).' });
    return;
  }
  if (err && (err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE')) {
    res.status(400).json({ error: 'تم تجاوز الحد الأقصى لعدد الملفات المسموح به (10 ملفات).' });
    return;
  }
  res.status(err?.status || 500).json({ error: err?.message || 'حدث خطأ في الخادم.' });
});

// ============================================================================
// VITE / STATIC SERVING
// ============================================================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Graphicore Office server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
