import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Eye,
  FileText,
  MessageSquare,
  Paperclip,
  Search,
  Send,
  Star,
  Volume2,
  VolumeX,
  Wrench,
  PackageCheck,
} from 'lucide-react';
import type { Language, Order, OrderStatus } from '../types';
import { TRANSLATIONS } from '../i18n';
import { isSoundEnabled, playNotificationChime, setSoundEnabled } from '../utils/sound';

const STEPS: OrderStatus[] = ['sent', 'seen', 'in_progress', 'completed', 'delivered_picked_up'];

export const OrderTrackerSection: React.FC<{
  lang: Language;
  initialQuery?: string;
}> = ({ lang, initialQuery = '' }) => {
  const t = TRANSLATIONS[lang];
  const [query, setQuery] = useState(initialQuery);
  const [orders, setOrders] = useState<Order[]>([]);
  const [searched, setSearched] = useState(false);
  const [loading, setLoading] = useState(false);
  const [soundOn, setSoundOn] = useState(isSoundEnabled());

  // Per-order messaging & review inputs
  const [messageInputs, setMessageInputs] = useState<Record<string, string>>({});
  const [messageFiles, setMessageFiles] = useState<Record<string, File | null>>({});
  const [sendingMsg, setSendingMsg] = useState<string | null>(null);

  const [reviewRating, setReviewRating] = useState<Record<string, number>>({});
  const [reviewCategory, setReviewCategory] = useState<Record<string, 'rating' | 'suggestion' | 'complaint'>>({});
  const [reviewComment, setReviewComment] = useState<Record<string, string>>({});
  const [reviewNotice, setReviewNotice] = useState<Record<string, string>>({});

  const fetchOrders = async (searchVal: string, silent = false) => {
    const clean = searchVal.trim();
    if (!clean) return;
    if (!silent) setLoading(true);
    try {
      const resp = await fetch(`/api/orders/track?q=${encodeURIComponent(clean)}`);
      if (resp.ok) {
        const data = (await resp.json()) as Order[];
        if (silent && orders.length > 0 && data.length > 0) {
          const prevFirst = orders[0];
          const nextFirst = data[0];
          if (
            prevFirst.status !== nextFirst.status ||
            (prevFirst.messages?.length || 0) < (nextFirst.messages?.length || 0)
          ) {
            playNotificationChime('status');
          }
        }
        setOrders(data);
      } else {
        setOrders([]);
      }
      setSearched(true);
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      fetchOrders(initialQuery);
    }
  }, [initialQuery]);

  // Poll active tracked order every 10 seconds for live status / admin replies
  useEffect(() => {
    if (!searched || !query.trim() || orders.length === 0) return;
    const timer = setInterval(() => {
      fetchOrders(query, true);
    }, 10000);
    return () => clearInterval(timer);
  }, [searched, query, orders]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchOrders(query);
  };

  const handleSendMessage = async (trackingCode: string) => {
    const text = (messageInputs[trackingCode] || '').trim();
    const file = messageFiles[trackingCode];
    if (!text && !file) return;

    setSendingMsg(trackingCode);
    try {
      const fd = new FormData();
      fd.append('message_text', text);
      if (file) fd.append('file', file);
      const resp = await fetch(`/api/orders/${encodeURIComponent(trackingCode)}/messages`, {
        method: 'POST',
        body: fd,
      });
      if (resp.ok) {
        const updated = (await resp.json()) as Order;
        setOrders((prev) => prev.map((o) => (o.tracking_code === trackingCode ? updated : o)));
        setMessageInputs((p) => ({ ...p, [trackingCode]: '' }));
        setMessageFiles((p) => ({ ...p, [trackingCode]: null }));
      }
    } finally {
      setSendingMsg(null);
    }
  };

  const handleSubmitReview = async (order: Order) => {
    const rating = reviewRating[order.tracking_code] || 5;
    const category = reviewCategory[order.tracking_code] || 'rating';
    const comment = reviewComment[order.tracking_code] || '';
    const resp = await fetch(`/api/orders/${encodeURIComponent(order.tracking_code)}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating, category, comment }),
    });
    const data = await resp.json();
    if (resp.ok) {
      setOrders((prev) =>
        prev.map((o) => (o.tracking_code === order.tracking_code ? { ...o, has_review: true } : o))
      );
      setReviewNotice((p) => ({ ...p, [order.tracking_code]: t.reviewSubmitted }));
    } else {
      setReviewNotice((p) => ({ ...p, [order.tracking_code]: data.error || 'Error' }));
    }
  };

  const stepIcon = (status: OrderStatus) => {
    switch (status) {
      case 'sent':
        return <Send className="h-4 w-4" />;
      case 'seen':
        return <Eye className="h-4 w-4" />;
      case 'in_progress':
        return <Wrench className="h-4 w-4" />;
      case 'completed':
        return <CheckCircle2 className="h-4 w-4" />;
      case 'delivered_picked_up':
        return <PackageCheck className="h-4 w-4" />;
    }
  };

  return (
    <section id="track-section" className="space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">{t.trackTitle}</h2>
            <p className="mt-1 text-sm text-slate-600">{t.trackSubtitle}</p>
          </div>

          <button
            type="button"
            onClick={() => {
              const next = !soundOn;
              setSoundOn(next);
              setSoundEnabled(next);
              if (next) playNotificationChime('status');
            }}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            {soundOn ? <Volume2 className="h-4 w-4 text-blue-700" /> : <VolumeX className="h-4 w-4 text-slate-400" />}
            <span>{soundOn ? t.soundOn : t.soundOff}</span>
          </button>
        </div>

        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="h-4 w-4 text-slate-400 absolute top-3.5 start-3.5" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.trackPlaceholder}
              className="w-full rounded-xl border border-slate-200 bg-slate-50 ps-10 pe-4 py-3 text-sm font-mono-nums focus:border-blue-600 focus:bg-white focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="rounded-xl bg-blue-700 px-6 py-3 text-sm font-bold text-white hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {loading ? '...' : t.trackBtn}
          </button>
        </form>

        {searched && orders.length === 0 && (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-600">
            {t.noOrdersFound}
          </div>
        )}

        {orders.map((order) => {
          const currentIdx = STEPS.indexOf(order.status);
          const ratingVal = reviewRating[order.tracking_code] || 5;

          return (
            <div key={order.id} className="rounded-2xl border border-slate-200 bg-white p-6 space-y-6">
              {/* Header */}
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <div className="text-xs text-slate-500">
                    {order.customer_name} · <span className="font-mono-nums">{order.customer_phone}</span>
                  </div>
                  <div className="text-xl font-extrabold text-blue-800 font-mono-nums mt-0.5">
                    {order.tracking_code}
                  </div>
                </div>
                <div className="text-end">
                  <div className="text-xs text-slate-500">
                    {new Date(order.created_at).toLocaleDateString(lang === 'ar' ? 'ar-DZ' : lang === 'fr' ? 'fr-FR' : 'en-US')}
                  </div>
                  <div className="text-lg font-bold text-slate-900 font-mono-nums">
                    {order.total_price} {t.currency}
                    {order.custom_price_status === 'pending_quote' && (
                      <span className="ms-2 text-xs font-semibold text-amber-700">
                        ({lang === 'ar' ? 'بانتظار تسعير الخدمة المخصصة' : 'Devis en cours'})
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* 5-Stage Stepper */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                {STEPS.map((st, idx) => {
                  const active = idx <= currentIdx;
                  const isCurrent = idx === currentIdx;
                  return (
                    <div
                      key={st}
                      className={`rounded-xl border p-3 flex items-center gap-2.5 ${
                        isCurrent
                          ? 'border-blue-700 bg-blue-50 text-blue-900'
                          : active
                            ? 'border-emerald-200 bg-emerald-50/50 text-emerald-900'
                            : 'border-slate-200 bg-slate-50 text-slate-400'
                      }`}
                    >
                      <span className="shrink-0">{stepIcon(st)}</span>
                      <span className="text-xs font-bold">{t.statusLabels[st]}</span>
                    </div>
                  );
                })}
              </div>

              {/* Files & Items */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-2">
                  <div className="text-xs font-bold text-slate-700">{t.orderSummaryTitle}</div>
                  {order.items.map((it, i) => (
                    <div key={i} className="flex justify-between text-xs text-slate-700">
                      <span>
                        {lang === 'fr' ? it.name_fr : lang === 'en' ? it.name_en : it.name_ar} × {it.quantity}
                      </span>
                      <span className="font-mono-nums font-semibold">
                        {it.subtotal} {t.currency}
                      </span>
                    </div>
                  ))}
                  {order.custom_requests.map((cr, i) => (
                    <div key={`c-${i}`} className="flex justify-between text-xs text-blue-800">
                      <span>
                        {cr.description} × {cr.quantity}
                      </span>
                      <span className="font-mono-nums font-semibold">
                        {cr.quotedPrice ? `${cr.quotedPrice} ${t.currency}` : 'قيد التسعير'}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-2">
                  <div className="text-xs font-bold text-slate-700">
                    {lang === 'ar' ? 'الملفات المرفقة' : lang === 'fr' ? 'Fichiers joints' : 'Attached Files'}
                  </div>
                  {!order.files || order.files.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      {lang === 'ar' ? 'لا توجد ملفات مرفقة.' : 'No attached files.'}
                    </p>
                  ) : (
                    order.files.map((f) => (
                      <a
                        key={f.id}
                        href={`/api/orders/${encodeURIComponent(order.tracking_code)}/files/${f.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-xs font-medium text-blue-700 hover:underline"
                      >
                        <FileText className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">{f.original_name}</span>
                      </a>
                    ))
                  )}
                </div>
              </div>

              {/* Private Order Messaging Workspace */}
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-4">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <MessageSquare className="h-4 w-4 text-blue-700" />
                  <span>{t.messagesTitle}</span>
                </div>

                <div className="space-y-2.5 max-h-[260px] overflow-y-auto pe-1">
                  {(order.messages || []).map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender === 'customer' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[82%] rounded-xl px-3.5 py-2.5 text-xs space-y-1.5 ${
                          msg.sender === 'customer'
                            ? 'bg-blue-700 text-white'
                            : 'bg-white border border-slate-200 text-slate-800'
                        }`}
                      >
                        {msg.message_text && <p className="leading-relaxed">{msg.message_text}</p>}
                        {msg.attachment_file_id && (
                          <a
                            href={`/api/orders/${encodeURIComponent(order.tracking_code)}/files/${msg.attachment_file_id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`inline-flex items-center gap-1.5 underline ${
                              msg.sender === 'customer' ? 'text-blue-100' : 'text-blue-700'
                            }`}
                          >
                            <Paperclip className="h-3 w-3" />
                            <span>{msg.attachment_name || 'Attachment'}</span>
                          </a>
                        )}
                        <div
                          className={`text-[10px] font-mono-nums ${
                            msg.sender === 'customer' ? 'text-blue-200' : 'text-slate-400'
                          }`}
                        >
                          {msg.sender === 'admin' ? 'Graphicore Office' : order.customer_name} ·{' '}
                          {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <input
                    type="text"
                    value={messageInputs[order.tracking_code] || ''}
                    onChange={(e) =>
                      setMessageInputs((p) => ({ ...p, [order.tracking_code]: e.target.value }))
                    }
                    placeholder={t.messagePlaceholder}
                    className="flex-1 min-w-[180px] rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs focus:border-blue-600 focus:outline-none"
                  />
                  <label className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer">
                    <Paperclip className="h-3.5 w-3.5" />
                    <span>{messageFiles[order.tracking_code]?.name.slice(0, 12) || t.attachFile}</span>
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) =>
                        setMessageFiles((p) => ({
                          ...p,
                          [order.tracking_code]: e.target.files?.[0] || null,
                        }))
                      }
                    />
                  </label>
                  <button
                    type="button"
                    disabled={sendingMsg === order.tracking_code}
                    onClick={() => handleSendMessage(order.tracking_code)}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>{t.sendMessage}</span>
                  </button>
                </div>
              </div>

              {/* 5-Star Review after completion (one-time per order) */}
              <div id="reviews-section" className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                <h4 className="text-sm font-bold text-slate-900">{t.reviewSectionTitle}</h4>
                {order.has_review ? (
                  <p className="text-xs font-semibold text-emerald-700">
                    {reviewNotice[order.tracking_code] || t.reviewSubmitted}
                  </p>
                ) : order.status !== 'completed' && order.status !== 'delivered_picked_up' ? (
                  <p className="text-xs text-slate-500">{t.reviewLockedInfo}</p>
                ) : (
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-1.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() =>
                              setReviewRating((p) => ({ ...p, [order.tracking_code]: star }))
                            }
                            className="p-1 cursor-pointer"
                          >
                            <Star
                              className={`h-6 w-6 ${
                                star <= ratingVal
                                  ? 'fill-amber-400 text-amber-500'
                                  : 'text-slate-300'
                              }`}
                            />
                          </button>
                        ))}
                      </div>

                      <div className="flex gap-1.5">
                        {(
                          [
                            ['rating', t.reviewTypeRating],
                            ['suggestion', t.reviewTypeSuggestion],
                            ['complaint', t.reviewTypeComplaint],
                          ] as const
                        ).map(([cat, lbl]) => (
                          <button
                            key={cat}
                            type="button"
                            onClick={() =>
                              setReviewCategory((p) => ({ ...p, [order.tracking_code]: cat }))
                            }
                            className={`rounded-lg px-2.5 py-1 text-xs font-semibold cursor-pointer ${
                              (reviewCategory[order.tracking_code] || 'rating') === cat
                                ? 'bg-blue-700 text-white'
                                : 'border border-slate-200 bg-slate-50 text-slate-700'
                            }`}
                          >
                            {lbl}
                          </button>
                        ))}
                      </div>
                    </div>

                    <textarea
                      rows={2}
                      value={reviewComment[order.tracking_code] || ''}
                      onChange={(e) =>
                        setReviewComment((p) => ({ ...p, [order.tracking_code]: e.target.value }))
                      }
                      placeholder={
                        lang === 'fr'
                          ? 'Commentaire ou suggestion (optionnel)...'
                          : lang === 'en'
                            ? 'Optional comment or suggestion...'
                            : 'أضف تعليقك أو اقتراحك (اختياري)...'
                      }
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => handleSubmitReview(order)}
                      className="rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                    >
                      {t.submitReview}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
