import React, { useEffect, useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import {
  Bell,
  Brain,
  Check,
  CheckCircle2,
  Database,
  DollarSign,
  Download,
  FileText,
  FolderOpen,
  Lock,
  LogOut,
  MapPin,
  MessageSquare,
  Package,
  Paperclip,
  Plus,
  Printer,
  RefreshCw,
  Send,
  Settings,
  Shield,
  ShoppingBag,
  Sparkles,
  Star,
  Trash2,
  Truck,
  Upload,
  Users,
  Volume2,
  VolumeX,
  AlertTriangle,
  X,
} from 'lucide-react';
import type {
  AccountingEntry,
  AdminNotification,
  AdminVaultFile,
  AiAdvisorReport,
  CustomCategoryConfig,
  InventoryItem,
  Language,
  Order,
  OrderStatus,
  PublicConfig,
  Review,
  ServiceCategory,
  ServiceItem,
  StaffUser,
} from '../types';
import { printHtmlDocument, ReceiptPrintPreview } from './ReceiptPrintPreview';
import { AdminDeliveryMap, AdminOfficeLocationPicker } from './MapsWidget';
import { isSoundEnabled, playNotificationChime, setSoundEnabled } from '../utils/sound';

type AdminTab =
  | 'orders'
  | 'delivery'
  | 'services'
  | 'accounting'
  | 'printing'
  | 'ai'
  | 'reviews'
  | 'settings';

interface AdminUser {
  userId: number | 'master';
  username: string;
  displayName: string;
  role: 'admin' | 'manager' | 'operator' | 'delivery';
  permissions: string[];
}

const TOKEN_STORAGE_KEY = 'go_admin_token';

function parseCsvRows(text: string): Record<string, string>[] {
  const clean = text.replace(/^\uFEFF/, '').trim();
  if (!clean) return [];
  const lines = clean.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) return [];
  const sep = lines[0].includes(';') && !lines[0].includes(',') ? ';' : ',';
  const splitLine = (line: string): string[] => {
    const out: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === sep && !inQuotes) {
        out.push(cur.trim());
        cur = '';
      } else {
        cur += ch;
      }
    }
    out.push(cur.trim());
    return out;
  };
  const headers = splitLine(lines[0]).map((h) => h.trim().toLowerCase());
  return lines.slice(1).map((line) => {
    const cols = splitLine(line);
    const obj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      obj[h] = cols[idx] ?? '';
    });
    return obj;
  });
}

export const AdminDashboard: React.FC<{
  lang: Language;
  config: PublicConfig;
  onExit: () => void;
  onDataUpdated: () => void;
}> = ({ lang, config, onExit, onDataUpdated }) => {
  const [authToken, setAuthToken] = useState<string>(() => {
    try {
      return sessionStorage.getItem(TOKEN_STORAGE_KEY) || '';
    } catch {
      return '';
    }
  });
  const [user, setUser] = useState<AdminUser | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [staffLoginMode, setStaffLoginMode] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [soundOn, setSoundOn] = useState(isSoundEnabled());

  // Core data states
  const [orders, setOrders] = useState<Order[]>([]);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [accounting, setAccounting] = useState<{
    entries: AccountingEntry[];
    inventory: InventoryItem[];
    totals: any;
  }>({ entries: [], inventory: [], totals: null });
  const [reviewsData, setReviewsData] = useState<{ reviews: Review[]; total: number; average: number }>({
    reviews: [],
    total: 0,
    average: 0,
  });
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [staffList, setStaffList] = useState<StaffUser[]>([]);
  const [adminSettings, setAdminSettings] = useState<any>(null);
  const [vaultFiles, setVaultFiles] = useState<AdminVaultFile[]>([]);

  // Orders interaction states
  const [orderFilterStatus, setOrderFilterStatus] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [adminReplyText, setAdminReplyText] = useState('');
  const [adminReplyFile, setAdminReplyFile] = useState<File | null>(null);
  const [orderFileImporting, setOrderFileImporting] = useState(false);
  const [quotePrices, setQuotePrices] = useState<Record<number, string>>({});
  const [deleteConfirmOrder, setDeleteConfirmOrder] = useState<Order | null>(null);
  const [printOrderTargetId, setPrintOrderTargetId] = useState<number | null>(null);

  // Delivery selected order
  const [selectedDeliveryOrder, setSelectedDeliveryOrder] = useState<Order | null>(null);

  // Service form state (supports all default pricing fields + custom categories)
  const emptyNewService = {
    category: 'printing' as ServiceCategory,
    name_ar: '',
    name_fr: '',
    name_en: '',
    price: '',
    price_max: '',
    unit_label_ar: 'صفحة',
    min_qty: '1',
    setup_design_fee: '0',
    print_unit_price: '',
    pricing_note_ar: '',
  };
  const [newService, setNewService] = useState(emptyNewService);
  const [editingService, setEditingService] = useState<ServiceItem | null>(null);
  const [servicesMsg, setServicesMsg] = useState<string | null>(null);
  const [customCategories, setCustomCategories] = useState<Record<ServiceCategory, CustomCategoryConfig>>({
    printing: { enabled: true, label_ar: 'خدمة أخرى حسب الطلب (طباعة)' },
    admin: { enabled: true, label_ar: 'خدمة إدارية أخرى حسب الطلب' },
    design: { enabled: true, label_ar: 'خدمة تصميم أو إشهار أخرى حسب الطلب' },
  });

  // Accounting & inventory forms
  const [accFilter, setAccFilter] = useState<'all' | 'income' | 'expense'>('all');
  const [accSearch, setAccSearch] = useState('');
  const [accMsg, setAccMsg] = useState<string | null>(null);
  const [newEntry, setNewEntry] = useState({
    entry_type: 'expense' as 'income' | 'expense',
    category: 'supplies',
    description: '',
    amount: '',
    entry_date: new Date().toISOString().slice(0, 10),
  });
  const [newInv, setNewInv] = useState({
    name: '',
    category: 'paper' as InventoryItem['category'],
    quantity: '',
    unit: 'رزمة',
    unit_cost: '',
    min_threshold: '5',
  });

  // AI Advisor
  const [aiReport, setAiReport] = useState<AiAdvisorReport | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Settings, Vault & Staff forms
  const [newStaff, setNewStaff] = useState({
    username: '',
    display_name: '',
    role: 'operator' as StaffUser['role'],
    password: '',
    permissions: ['orders', 'printing'] as string[],
  });
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '' });
  const [settingsMsg, setSettingsMsg] = useState<string | null>(null);
  const [vaultCategory, setVaultCategory] = useState('templates');
  const [vaultNotes, setVaultNotes] = useState('');
  const [vaultUploading, setVaultUploading] = useState(false);

  const saveAuthToken = (token: string) => {
    setAuthToken(token);
    try {
      if (token) sessionStorage.setItem(TOKEN_STORAGE_KEY, token);
      else sessionStorage.removeItem(TOKEN_STORAGE_KEY);
    } catch {
      // ignore storage restrictions
    }
  };

  const adminFetch = async (
    url: string,
    init: RequestInit = {},
    tokenOverride?: string
  ): Promise<Response> => {
    const activeToken = tokenOverride !== undefined ? tokenOverride : authToken;
    const headers = new Headers(init.headers || {});
    if (activeToken && !headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${activeToken}`);
    }
    const resp = await fetch(url, {
      ...init,
      headers,
      credentials: 'include',
    });
    if (resp.status === 401 && user) {
      saveAuthToken('');
      setUser(null);
      setLoginError('انتهت صلاحية الجلسة، يرجى تسجيل الدخول مجدداً.');
    }
    return resp;
  };

  const hasPerm = (perm: string) =>
    user?.role === 'admin' || user?.permissions.includes(perm) || false;

  const loadAllAdminData = async (currentUser: AdminUser, silent = false, tokenOverride?: string) => {
    const perms =
      currentUser.role === 'admin'
        ? ['orders', 'pricing', 'accounting', 'ai_advisor', 'printing', 'delivery', 'reviews', 'settings', 'staff']
        : currentUser.permissions;

    const reqs: Promise<void>[] = [];

    if (perms.includes('orders') || perms.includes('printing') || perms.includes('delivery')) {
      reqs.push(
        adminFetch('/api/admin/orders', {}, tokenOverride)
          .then((r) => (r.ok ? r.json() : []))
          .then((data: Order[]) => {
            if (silent && orders.length > 0 && data.length > orders.length) {
              playNotificationChime('order');
            }
            setOrders(data);
            setSelectedOrder((prev) => (prev ? data.find((x) => x.id === prev.id) || null : data[0] || null));
          })
      );
    }
    if (perms.includes('pricing')) {
      reqs.push(
        adminFetch('/api/admin/services', {}, tokenOverride)
          .then((r) => (r.ok ? r.json() : []))
          .then(setServices)
      );
    }
    if (perms.includes('accounting')) {
      reqs.push(
        adminFetch('/api/admin/accounting', {}, tokenOverride)
          .then((r) => (r.ok ? r.json() : { entries: [], inventory: [], totals: null }))
          .then(setAccounting)
      );
    }
    if (perms.includes('reviews')) {
      reqs.push(
        adminFetch('/api/admin/reviews', {}, tokenOverride)
          .then((r) => (r.ok ? r.json() : { reviews: [], total: 0, average: 0 }))
          .then(setReviewsData)
      );
    }
    if (perms.includes('staff')) {
      reqs.push(
        adminFetch('/api/admin/staff', {}, tokenOverride)
          .then((r) => (r.ok ? r.json() : []))
          .then(setStaffList)
      );
    }

    reqs.push(
      adminFetch('/api/admin/notifications', {}, tokenOverride)
        .then((r) => (r.ok ? r.json() : { notifications: [], unreadCount: 0 }))
        .then((d) => {
          setNotifications(d.notifications || []);
          setUnreadCount(d.unreadCount || 0);
        })
    );
    reqs.push(
      adminFetch('/api/admin/settings', {}, tokenOverride)
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (d) {
            setAdminSettings(d);
            if (d.customCategories) {
              setCustomCategories(d.customCategories);
            }
          }
        })
    );
    reqs.push(
      adminFetch('/api/admin/vault-files', {}, tokenOverride)
        .then((r) => (r.ok ? r.json() : []))
        .then(setVaultFiles)
    );

    await Promise.all(reqs);
  };

  useEffect(() => {
    const headers: Record<string, string> = {};
    if (authToken) headers.Authorization = `Bearer ${authToken}`;
    fetch('/api/admin/me', { headers, credentials: 'include' })
      .then((r) => (r.ok ? r.json() : { authenticated: false }))
      .then((d) => {
        if (d.authenticated && d.user) {
          if (d.token) saveAuthToken(d.token);
          setUser(d.user);
          loadAllAdminData(d.user, false, d.token || authToken);
        } else {
          saveAuthToken('');
        }
      })
      .finally(() => setCheckingAuth(false));
  }, []);

  // Poll new orders & notifications every 12 seconds when signed in
  useEffect(() => {
    if (!user) return;
    const timer = setInterval(() => {
      loadAllAdminData(user, true);
    }, 12000);
    return () => clearInterval(timer);
  }, [user, orders.length, authToken]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoggingIn(true);
    try {
      const resp = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          username: staffLoginMode ? username : 'admin',
          password,
        }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setLoginError(data.error || 'بيانات الدخول غير صحيحة.');
        return;
      }
      const nextToken = data.token || '';
      saveAuthToken(nextToken);
      setUser(data.user);
      setPassword('');
      await loadAllAdminData(data.user, false, nextToken);
    } catch {
      setLoginError('تعذر الاتصال بالخادم.');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await adminFetch('/api/admin/logout', { method: 'POST' });
    } catch {
      // ignore logout error
    }
    saveAuthToken('');
    setUser(null);
    onExit();
  };

  const updateOrderStatus = async (order: Order, status: OrderStatus) => {
    const resp = await adminFetch(`/api/admin/orders/${order.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (resp.ok) {
      const updated = (await resp.json()) as Order;
      setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      setSelectedOrder(updated);
      if (user) loadAllAdminData(user);
    }
  };

  const saveCustomQuotes = async (order: Order) => {
    const updatedCustom = order.custom_requests.map((cr, idx) => ({
      ...cr,
      quotedPrice: quotePrices[idx] !== undefined ? Number(quotePrices[idx]) || 0 : cr.quotedPrice || 0,
    }));
    const itemsSum = order.items.reduce((s, it) => s + Number(it.subtotal || 0), 0);
    const customSum = updatedCustom.reduce((s, cr) => s + Number(cr.quotedPrice || 0), 0);
    const newTotal = itemsSum + customSum + Number(order.delivery_fee || 0);

    const resp = await adminFetch(`/api/admin/orders/${order.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        custom_requests: updatedCustom,
        total_price: newTotal,
        custom_price_status: 'quoted',
        status: order.status === 'sent' ? 'seen' : order.status,
      }),
    });
    if (resp.ok) {
      const updated = (await resp.json()) as Order;
      setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      setSelectedOrder(updated);
      await adminFetch(`/api/admin/orders/${order.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message_text: `تم تحديد تسعير الخدمة المخصصة. السعر الإجمالي المحدث للطلب هو ${newTotal} د.ج.`,
        }),
      });
      if (user) loadAllAdminData(user);
    }
  };

  const sendAdminMessage = async (orderId: number) => {
    if (!adminReplyText.trim() && !adminReplyFile) return;
    const fd = new FormData();
    fd.append('message_text', adminReplyText.trim());
    if (adminReplyFile) fd.append('file', adminReplyFile);
    const resp = await adminFetch(`/api/admin/orders/${orderId}/messages`, {
      method: 'POST',
      body: fd,
    });
    if (resp.ok) {
      const updated = (await resp.json()) as Order;
      setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
      setSelectedOrder(updated);
      setAdminReplyText('');
      setAdminReplyFile(null);
    }
  };

  const importFilesToOrder = async (orderId: number, fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setOrderFileImporting(true);
    try {
      const fd = new FormData();
      Array.from(fileList)
        .slice(0, 10)
        .forEach((f) => fd.append('files', f));
      const resp = await adminFetch(`/api/admin/orders/${orderId}/files`, {
        method: 'POST',
        body: fd,
      });
      if (resp.ok) {
        const updated = (await resp.json()) as Order;
        setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
        setSelectedOrder(updated);
      }
    } finally {
      setOrderFileImporting(false);
    }
  };

  const confirmPermanentDeleteOrder = async () => {
    if (!deleteConfirmOrder) return;
    const id = deleteConfirmOrder.id;
    const resp = await adminFetch(`/api/admin/orders/${id}`, { method: 'DELETE' });
    if (resp.ok) {
      setOrders((prev) => prev.filter((o) => o.id !== id));
      if (selectedOrder?.id === id) setSelectedOrder(null);
      setDeleteConfirmOrder(null);
      if (user) loadAllAdminData(user);
    }
  };

  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      if (orderFilterStatus !== 'all' && o.status !== orderFilterStatus) return false;
      if (orderSearch.trim()) {
        const q = orderSearch.trim().toLowerCase();
        return (
          o.tracking_code.toLowerCase().includes(q) ||
          o.customer_name.toLowerCase().includes(q) ||
          o.customer_phone.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [orders, orderFilterStatus, orderSearch]);

  const deliveryOrders = useMemo(
    () => orders.filter((o) => o.delivery_requested === 1),
    [orders]
  );

  const filteredAccounting = useMemo(() => {
    return accounting.entries.filter((e) => {
      if (accFilter !== 'all' && e.entry_type !== accFilter) return false;
      if (accSearch.trim()) {
        const q = accSearch.trim().toLowerCase();
        return e.description.toLowerCase().includes(q) || e.category.toLowerCase().includes(q);
      }
      return true;
    });
  }, [accounting.entries, accFilter, accSearch]);

  const exportAccountingCsv = () => {
    const header = ['Date', 'Type', 'Category', 'Description', 'Amount (DZD)'];
    const rows = filteredAccounting.map((e) => [
      e.entry_date,
      e.entry_type,
      e.category,
      `"${e.description.replace(/"/g, '""')}"`,
      String(e.amount),
    ]);
    const csv = '\uFEFF' + [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `graphicore-accounting-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const runAiAdvisor = async () => {
    setAiLoading(true);
    setAiError(null);
    try {
      const resp = await adminFetch('/api/admin/ai-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language: lang }),
      });
      const data = await resp.json();
      if (!resp.ok) {
        setAiError(data.error || 'تعذر تشغيل المستشار الذكي.');
      } else {
        setAiReport(data);
      }
    } catch {
      setAiError('تعذر الاتصال بخدمة التحليل.');
    } finally {
      setAiLoading(false);
    }
  };

  if (checkingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 text-sm text-slate-600">
        جاري التحقق من الجلسة...
      </div>
    );
  }

  // Login Gate
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-700 text-white">
                <Lock className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900">دخول لوحة الإدارة</h1>
                <p className="text-xs text-slate-500">Graphicore Office — فريق العمل</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onExit}
              className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex rounded-xl bg-slate-100 p-1 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setStaffLoginMode(false)}
              className={`flex-1 rounded-lg py-2 cursor-pointer ${
                !staffLoginMode ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              الإدارة العامة
            </button>
            <button
              type="button"
              onClick={() => setStaffLoginMode(true)}
              className={`flex-1 rounded-lg py-2 cursor-pointer ${
                staffLoginMode ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              حساب موظف
            </button>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {staffLoginMode && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  اسم المستخدم
                </label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                كلمة المرور المشفرة
              </label>
              <input
                type="password"
                required
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm"
              />
            </div>

            {loginError && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-semibold text-rose-800">
                {loginError}
              </div>
            )}

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full rounded-xl bg-blue-700 py-3 text-sm font-bold text-white hover:bg-blue-800 transition-colors cursor-pointer"
            >
              {loggingIn ? 'جاري التحقق...' : 'دخول آمن'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  const navItems: { id: AdminTab; label: string; icon: React.FC<{ className?: string }>; perm: string }[] = [
    { id: 'orders', label: 'الطلبات والمراسلات', icon: ShoppingBag, perm: 'orders' },
    { id: 'delivery', label: 'التوصيل والخرائط', icon: Truck, perm: 'delivery' },
    { id: 'services', label: 'الخدمات والأسعار', icon: FileText, perm: 'pricing' },
    { id: 'accounting', label: 'المالية والمحاسبة', icon: DollarSign, perm: 'accounting' },
    { id: 'printing', label: 'طباعة الوصولات', icon: Printer, perm: 'printing' },
    { id: 'ai', label: 'مستشار الأعمال الذكي', icon: Brain, perm: 'ai_advisor' },
    { id: 'reviews', label: 'التقييمات والرضا', icon: Star, perm: 'reviews' },
    { id: 'settings', label: 'الإعدادات والفريق', icon: Settings, perm: 'settings' },
  ];

  const statusLabels: Record<OrderStatus, string> = {
    sent: 'تم الإرسال',
    seen: 'تمت المعاينة',
    in_progress: 'قيد التنفيذ',
    completed: 'تم التنفيذ',
    delivered_picked_up: 'تم التوصيل والاستلام',
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row">
      {/* Sidebar */}
      <aside className="no-print w-full lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-e border-slate-200 bg-white p-4 flex flex-col justify-between gap-6">
        <div className="space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <div className="text-base font-extrabold text-slate-900">Graphicore Admin</div>
              <div className="text-xs text-slate-500">
                {user.displayName} · {user.role}
              </div>
            </div>
            <button
              type="button"
              onClick={onExit}
              className="rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
            >
              واجهة العميل
            </button>
          </div>

          <nav className="flex lg:flex-col gap-1 overflow-x-auto pb-1 lg:pb-0">
            {navItems
              .filter((item) => hasPerm(item.perm) || (item.id === 'settings' && hasPerm('staff')))
              .map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                      active
                        ? 'bg-blue-700 text-white'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
          </nav>
        </div>

        <div className="hidden lg:flex flex-col gap-2 border-t border-slate-100 pt-4">
          <button
            type="button"
            onClick={() => {
              const next = !soundOn;
              setSoundOn(next);
              setSoundEnabled(next);
            }}
            className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            {soundOn ? <Volume2 className="h-4 w-4 text-blue-700" /> : <VolumeX className="h-4 w-4 text-slate-400" />}
            <span>{soundOn ? 'صوت الإشعارات: يعمل' : 'صوت الإشعارات: صامت'}</span>
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-100 cursor-pointer"
          >
            <LogOut className="h-4 w-4" />
            <span>تسجيل الخروج</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-8 space-y-6 max-w-7xl">
        {/* Top Admin Bar */}
        <div className="no-print flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div className="text-sm font-semibold text-slate-600">
            الإدارة / <span className="font-bold text-slate-900">{navItems.find((n) => n.id === activeTab)?.label}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={async () => {
                await adminFetch('/api/admin/notifications/read-all', { method: 'POST' });
                setUnreadCount(0);
              }}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <Bell className="h-4 w-4 text-blue-700" />
              <span>الإشعارات</span>
              {unreadCount > 0 && (
                <span className="font-mono-nums font-bold text-blue-700">({unreadCount})</span>
              )}
            </button>
            <button
              type="button"
              onClick={() => user && loadAllAdminData(user)}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>تحديث</span>
            </button>
          </div>
        </div>

        {/* Notifications Strip (when unread > 0) */}
        {unreadCount > 0 && notifications.length > 0 && (
          <div className="no-print rounded-xl border border-blue-200 bg-blue-50 p-4 space-y-2">
            <div className="text-xs font-bold text-blue-900">أحدث التنبيهات وإشعارات البريد الإلكتروني:</div>
            {notifications.slice(0, 3).map((n) => (
              <div key={n.id} className="flex flex-wrap items-center justify-between gap-2 text-xs text-blue-800">
                <span>
                  <strong>{n.title}</strong> — {n.body}
                </span>
                <span className="font-mono-nums text-[11px] text-blue-600">
                  {n.email_sent_to ? `إشعار بريد (${n.email_sent_to}: ${n.email_status})` : n.email_status}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* TAB 1: ORDERS & MESSAGING */}
        {activeTab === 'orders' && (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
            <div className="xl:col-span-5 space-y-4">
              <div className="rounded-2xl border border-slate-200 bg-white p-4 space-y-3">
                <input
                  type="text"
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  placeholder="بحث برمز التتبع أو اسم العميل أو الهاتف..."
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs"
                />
                <div className="flex flex-wrap gap-1.5">
                  {(['all', 'sent', 'seen', 'in_progress', 'completed', 'delivered_picked_up'] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setOrderFilterStatus(st)}
                      className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold cursor-pointer ${
                        orderFilterStatus === st
                          ? 'bg-blue-700 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {st === 'all' ? 'الكل' : statusLabels[st]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2.5 max-h-[640px] overflow-y-auto">
                {filteredOrders.length === 0 ? (
                  <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-xs text-slate-500">
                    لا توجد طلبات مطابقة حالياً.
                  </div>
                ) : (
                  filteredOrders.map((o) => (
                    <div
                      key={o.id}
                      onClick={() => {
                        setSelectedOrder(o);
                        const qMap: Record<number, string> = {};
                        o.custom_requests.forEach((cr, idx) => {
                          qMap[idx] = cr.quotedPrice ? String(cr.quotedPrice) : '';
                        });
                        setQuotePrices(qMap);
                      }}
                      className={`rounded-xl border p-4 cursor-pointer transition-colors ${
                        selectedOrder?.id === o.id
                          ? 'border-blue-700 bg-blue-50/40'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono-nums text-sm font-extrabold text-blue-800">
                          {o.tracking_code}
                        </span>
                        <span className="text-xs font-bold text-slate-700">
                          {statusLabels[o.status]}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center justify-between text-xs text-slate-600">
                        <span>
                          {o.customer_name} · <span className="font-mono-nums">{o.customer_phone}</span>
                        </span>
                        <span className="font-mono-nums font-bold text-slate-900">
                          {o.total_price} د.ج
                        </span>
                      </div>
                      {o.custom_price_status === 'pending_quote' && (
                        <div className="mt-1.5 text-[11px] font-bold text-amber-700">
                          بانتظار تسعير الخدمة المخصصة
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="xl:col-span-7">
              {!selectedOrder ? (
                <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-sm text-slate-500">
                  اختر طلباً من القائمة لعرض تفاصيله ومراسلة العميل.
                </div>
              ) : (
                <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-6">
                  <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
                    <div>
                      <div className="text-xl font-extrabold text-blue-900 font-mono-nums">
                        {selectedOrder.tracking_code}
                      </div>
                      <div className="text-sm font-bold text-slate-900 mt-1">
                        {selectedOrder.customer_name} ·{' '}
                        <span className="font-mono-nums text-blue-700">{selectedOrder.customer_phone}</span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        الاستلام:{' '}
                        {selectedOrder.pickup_type === 'tomorrow_morning'
                          ? 'غداً صباحاً'
                          : selectedOrder.pickup_type === 'scheduled'
                            ? selectedOrder.pickup_datetime
                            : 'في أقرب وقت'}{' '}
                        {selectedOrder.delivery_requested ? `· توصيل (${selectedOrder.delivery_address})` : ''}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setPrintOrderTargetId(selectedOrder.id);
                          setActiveTab('printing');
                        }}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-bold text-blue-800 hover:bg-blue-100 cursor-pointer"
                      >
                        <Printer className="h-3.5 w-3.5" />
                        <span>إضافة لطباعة الوصل</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleteConfirmOrder(selectedOrder)}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-100 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>حذف نهائي</span>
                      </button>
                    </div>
                  </div>

                  {/* Status Switcher */}
                  <div>
                    <div className="text-xs font-bold text-slate-700 mb-2">تحديث مرحلة الطلب:</div>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {(['sent', 'seen', 'in_progress', 'completed', 'delivered_picked_up'] as OrderStatus[]).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => updateOrderStatus(selectedOrder, st)}
                          className={`rounded-xl py-2 px-2.5 text-[11px] font-bold cursor-pointer ${
                            selectedOrder.status === st
                              ? 'bg-blue-700 text-white'
                              : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {statusLabels[st]}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Services & Custom Quoting */}
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                    <div className="flex justify-between text-xs font-bold text-slate-800">
                      <span>تفاصيل الخدمات</span>
                      <span className="font-mono-nums text-blue-900">
                        المجموع الحالي: {selectedOrder.total_price} د.ج
                      </span>
                    </div>
                    {selectedOrder.items.map((it, i) => (
                      <div key={i} className="flex justify-between text-xs text-slate-700">
                        <span>
                          {it.name_ar} × {it.quantity}
                        </span>
                        <span className="font-mono-nums font-semibold">{it.subtotal} د.ج</span>
                      </div>
                    ))}
                    {selectedOrder.notes && (
                      <div className="text-xs text-slate-600 pt-2 border-t border-slate-200">
                        <strong>ملاحظات العميل:</strong> {selectedOrder.notes}
                      </div>
                    )}

                    {selectedOrder.custom_requests.length > 0 && (
                      <div className="pt-3 border-t border-slate-200 space-y-2.5">
                        <div className="text-xs font-bold text-amber-800">تسعير الخدمات المخصصة:</div>
                        {selectedOrder.custom_requests.map((cr, idx) => (
                          <div key={idx} className="flex flex-wrap items-center justify-between gap-2 text-xs">
                            <span className="text-slate-800 flex-1">
                              {cr.description} (الكمية: {cr.quantity})
                            </span>
                            <input
                              type="number"
                              min={0}
                              placeholder="السعر د.ج"
                              value={quotePrices[idx] ?? (cr.quotedPrice || '')}
                              onChange={(e) =>
                                setQuotePrices((p) => ({ ...p, [idx]: e.target.value }))
                              }
                              className="w-28 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono-nums"
                            />
                          </div>
                        ))}
                        <button
                          type="button"
                          onClick={() => saveCustomQuotes(selectedOrder)}
                          className="rounded-lg bg-amber-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-amber-700 cursor-pointer"
                        >
                          حفظ السعر وإشعار العميل
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Files & Admin Direct File Import */}
                  <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs font-bold text-slate-700">
                        الملفات المرفقة ({selectedOrder.files?.length || 0}):
                      </div>
                      <label className="inline-flex items-center gap-1.5 rounded-xl bg-blue-700 px-3 py-1.5 text-[11px] font-bold text-white hover:bg-blue-800 cursor-pointer">
                        <Upload className="h-3.5 w-3.5" />
                        <span>{orderFileImporting ? 'جاري الاستيراد...' : 'استيراد / إرفاق ملفات للطلب (إدارة)'}</span>
                        <input
                          type="file"
                          multiple
                          className="hidden"
                          disabled={orderFileImporting}
                          onChange={(e) => {
                            importFilesToOrder(selectedOrder.id, e.target.files);
                            e.target.value = '';
                          }}
                        />
                      </label>
                    </div>
                    {selectedOrder.files && selectedOrder.files.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {selectedOrder.files.map((f) => (
                          <a
                            key={f.id}
                            href={`/api/orders/${encodeURIComponent(selectedOrder.tracking_code)}/files/${f.id}${
                              authToken ? `?token=${encodeURIComponent(authToken)}` : ''
                            }`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-50"
                          >
                            <Download className="h-3.5 w-3.5" />
                            <span>{f.original_name}</span>
                            <span className="text-[10px] text-slate-400">
                              ({f.uploaded_by === 'admin' ? 'إدارة' : 'عميل'})
                            </span>
                          </a>
                        ))}
                      </div>
                    ) : (
                      <div className="text-[11px] text-slate-500">لا توجد ملفات مرفقة لهذا الطلب بعد.</div>
                    )}
                  </div>

                  {/* Messaging Thread */}
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                      <MessageSquare className="h-4 w-4 text-blue-700" />
                      <span>مراسلة العميل</span>
                    </div>
                    <div className="space-y-2 max-h-52 overflow-y-auto">
                      {(selectedOrder.messages || []).map((m) => (
                        <div
                          key={m.id}
                          className={`flex ${m.sender === 'admin' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[82%] rounded-xl px-3 py-2 text-xs space-y-1 ${
                              m.sender === 'admin'
                                ? 'bg-blue-700 text-white'
                                : 'bg-white border border-slate-200 text-slate-800'
                            }`}
                          >
                            {m.message_text && <p>{m.message_text}</p>}
                            {m.attachment_file_id && (
                              <a
                                href={`/api/orders/${encodeURIComponent(selectedOrder.tracking_code)}/files/${m.attachment_file_id}${
                                  authToken ? `?token=${encodeURIComponent(authToken)}` : ''
                                }`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 underline"
                              >
                                <Paperclip className="h-3 w-3" />
                                <span>{m.attachment_name || 'ملف'}</span>
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <input
                        type="text"
                        value={adminReplyText}
                        onChange={(e) => setAdminReplyText(e.target.value)}
                        placeholder="رد الإدارة على العميل..."
                        className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs"
                      />
                      <label className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 cursor-pointer">
                        <Paperclip className="h-3.5 w-3.5" />
                        <span>{adminReplyFile?.name.slice(0, 12) || 'إرفاق'}</span>
                        <input
                          type="file"
                          className="hidden"
                          onChange={(e) => setAdminReplyFile(e.target.files?.[0] || null)}
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => sendAdminMessage(selectedOrder.id)}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                      >
                        <Send className="h-3.5 w-3.5" />
                        <span>إرسال</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: DELIVERY & MAPS */}
        {activeTab === 'delivery' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-3">
              <div className="rounded-2xl border border-slate-200 bg-white p-4">
                <h3 className="text-base font-bold text-slate-900">
                  طلبات التوصيل ({deliveryOrders.length})
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  اختر طلباً لعرض موقعه ومسار التوصيل من المكتب للمكلف بالتوصيل.
                </p>
              </div>
              {deliveryOrders.length === 0 ? (
                <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-xs text-slate-500">
                  لا توجد طلبات توصيل حالياً.
                </div>
              ) : (
                deliveryOrders.map((o) => (
                  <div
                    key={o.id}
                    onClick={() => setSelectedDeliveryOrder(o)}
                    className={`rounded-xl border p-4 cursor-pointer space-y-1 ${
                      selectedDeliveryOrder?.id === o.id
                        ? 'border-blue-700 bg-blue-50/40'
                        : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex justify-between text-xs font-bold">
                      <span>{o.customer_name}</span>
                      <span className="font-mono-nums text-blue-800">{o.tracking_code}</span>
                    </div>
                    <div className="text-xs font-mono-nums text-slate-600">{o.customer_phone}</div>
                    <div className="text-xs text-slate-600">{o.delivery_address || 'موقع محدد على الخريطة'}</div>
                    <div className="flex justify-between items-center pt-1 text-[11px]">
                      <span className="font-semibold text-blue-700">{statusLabels[o.status]}</span>
                      <span className="font-mono-nums font-bold">{o.total_price} د.ج</span>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-5">
              <AdminDeliveryMap
                apiKey={config.googleMapsApiKey}
                officePos={{
                  lat: adminSettings?.officeLat ?? config.officeLat,
                  lng: adminSettings?.officeLng ?? config.officeLng,
                }}
                deliveryOrders={deliveryOrders}
                selectedOrder={selectedDeliveryOrder}
                onSelectOrder={setSelectedDeliveryOrder}
              />
            </div>
          </div>
        )}

        {/* TAB 3: SERVICES & PRICING */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-base font-bold text-slate-900">
                  {editingService
                    ? `تعديل خدمة: ${editingService.name_ar}`
                    : `إضافة خدمة جديدة (الخدمات الحالية: ${services.length})`}
                </h3>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const blob = new Blob([JSON.stringify(services, null, 2)], {
                        type: 'application/json;charset=utf-8',
                      });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `graphicore-services-${new Date().toISOString().slice(0, 10)}.json`;
                      a.click();
                      URL.revokeObjectURL(url);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>تصدير الخدمات (JSON)</span>
                  </button>
                  <label className="inline-flex items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-bold text-blue-800 hover:bg-blue-100 cursor-pointer">
                    <Upload className="h-3.5 w-3.5" />
                    <span>استيراد خدمات (JSON / CSV)</span>
                    <input
                      type="file"
                      accept=".json,.csv"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        e.target.value = '';
                        if (!file) return;
                        try {
                          const txt = await file.text();
                          let items: any[] = [];
                          if (file.name.toLowerCase().endsWith('.json')) {
                            const parsed = JSON.parse(txt);
                            items = Array.isArray(parsed) ? parsed : parsed.items || [];
                          } else {
                            items = parseCsvRows(txt);
                          }
                          const resp = await adminFetch('/api/admin/services/import', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ items }),
                          });
                          const d = await resp.json();
                          if (resp.ok) {
                            setServicesMsg(`تم استيراد ${d.importedCount} خدمة بنجاح.`);
                            if (user) loadAllAdminData(user);
                            onDataUpdated();
                          } else {
                            setServicesMsg(d.error || 'تعذر استيراد ملف الخدمات.');
                          }
                        } catch {
                          setServicesMsg('تنسيق ملف الخدمات غير صالح.');
                        }
                      }}
                    />
                  </label>
                </div>
              </div>

              {servicesMsg && (
                <div className="rounded-xl border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-bold text-blue-900">
                  {servicesMsg}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                <select
                  value={editingService ? editingService.category : newService.category}
                  onChange={(e) => {
                    const val = e.target.value as ServiceCategory;
                    editingService
                      ? setEditingService({ ...editingService, category: val })
                      : setNewService({ ...newService, category: val });
                  }}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold"
                >
                  <option value="printing">خدمات الطباعة</option>
                  <option value="admin">الخدمات الإدارية والمكتبية</option>
                  <option value="design">الخدمات الإشهارية والتصميم</option>
                </select>

                <input
                  type="text"
                  placeholder="اسم الخدمة بالعربية *"
                  value={editingService ? editingService.name_ar : newService.name_ar}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, name_ar: e.target.value })
                      : setNewService({ ...newService, name_ar: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="number"
                  placeholder="السعر الأساسي (د.ج) *"
                  value={editingService ? editingService.price : newService.price}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, price: Number(e.target.value) })
                      : setNewService({ ...newService, price: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <input
                  type="number"
                  placeholder="أقصى سعر (اختياري لمجال السعر)"
                  value={editingService ? editingService.price_max ?? '' : newService.price_max}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({
                          ...editingService,
                          price_max: e.target.value ? Number(e.target.value) : null,
                        })
                      : setNewService({ ...newService, price_max: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <input
                  type="text"
                  placeholder="الاسم بالفرنسية"
                  value={editingService ? editingService.name_fr : newService.name_fr}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, name_fr: e.target.value })
                      : setNewService({ ...newService, name_fr: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  placeholder="الاسم بالإنجليزية"
                  value={editingService ? editingService.name_en : newService.name_en}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, name_en: e.target.value })
                      : setNewService({ ...newService, name_en: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  placeholder="وحدة القياس (صفحة، بطاقة...)"
                  value={editingService ? editingService.unit_label_ar : newService.unit_label_ar}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, unit_label_ar: e.target.value })
                      : setNewService({ ...newService, unit_label_ar: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="number"
                  min={1}
                  placeholder="الحد الأدنى للكمية"
                  value={editingService ? editingService.min_qty : newService.min_qty}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, min_qty: Math.max(1, Number(e.target.value) || 1) })
                      : setNewService({ ...newService, min_qty: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <input
                  type="number"
                  min={0}
                  placeholder="رسوم تصميم/تجهيز إضافية د.ج"
                  value={editingService ? editingService.setup_design_fee : newService.setup_design_fee}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, setup_design_fee: Number(e.target.value) || 0 })
                      : setNewService({ ...newService, setup_design_fee: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <input
                  type="number"
                  min={0}
                  placeholder="سعر طباعة الوحدة (بطاقات...)"
                  value={editingService ? editingService.print_unit_price ?? '' : newService.print_unit_price}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({
                          ...editingService,
                          print_unit_price: e.target.value !== '' ? Number(e.target.value) : null,
                        })
                      : setNewService({ ...newService, print_unit_price: e.target.value })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <input
                  type="text"
                  placeholder="ملاحظة التسعير الظاهرة للعميل"
                  value={editingService ? editingService.pricing_note_ar : newService.pricing_note_ar}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, pricing_note_ar: e.target.value })
                      : setNewService({ ...newService, pricing_note_ar: e.target.value })
                  }
                  className="sm:col-span-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    if (editingService) {
                      const resp = await adminFetch(`/api/admin/services/${editingService.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(editingService),
                      });
                      if (resp.ok) {
                        setServicesMsg(`تم تحديث الخدمة: ${editingService.name_ar}`);
                        setEditingService(null);
                      }
                    } else {
                      if (!newService.name_ar.trim()) return;
                      const resp = await adminFetch('/api/admin/services', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(newService),
                      });
                      if (resp.ok) {
                        setServicesMsg(`تمت إضافة الخدمة: ${newService.name_ar}`);
                        setNewService(emptyNewService);
                      }
                    }
                    if (user) loadAllAdminData(user);
                    onDataUpdated();
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-blue-700 px-5 py-2.5 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  <span>{editingService ? 'حفظ التعديلات' : 'إضافة الخدمة'}</span>
                </button>
                {editingService && (
                  <button
                    type="button"
                    onClick={() => setEditingService(null)}
                    className="rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-semibold text-slate-700 cursor-pointer"
                  >
                    إلغاء
                  </button>
                )}
              </div>
            </div>

            {/* Custom "Other Service" Options in All 3 Sections (Default Platform Options) */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    الخدمات الأخرى حسب الطلب (الافتراضية في الأقسام الثلاثة)
                  </h3>
                  <p className="text-xs text-slate-500">
                    تظهر هذه الخيارات للعملاء أسفل كل قسم لتحديد خدمة غير مسعّرة مسبقاً، ويمكنك تفعيلها أو تعديل تسميتها من هنا.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    const resp = await adminFetch('/api/admin/custom-categories', {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(customCategories),
                    });
                    if (resp.ok) {
                      setServicesMsg('تم حفظ إعدادات «الخدمات الأخرى حسب الطلب» بنجاح.');
                      onDataUpdated();
                    }
                  }}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                >
                  <Check className="h-4 w-4" />
                  <span>حفظ إعدادات الخدمات الأخرى</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {(
                  [
                    ['printing', 'قسم الطباعة'],
                    ['admin', 'قسم الخدمات الإدارية والمكتبية'],
                    ['design', 'قسم الخدمات الإشهارية والتصميم'],
                  ] as const
                ).map(([catKey, title]) => {
                  const cfg = customCategories[catKey] || { enabled: true, label_ar: '' };
                  return (
                    <div
                      key={catKey}
                      className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-slate-900">{title}</span>
                        <label className="inline-flex items-center gap-1.5 text-[11px] font-bold text-blue-800 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={Boolean(cfg.enabled)}
                            onChange={(e) =>
                              setCustomCategories((prev) => ({
                                ...prev,
                                [catKey]: { ...cfg, enabled: e.target.checked },
                              }))
                            }
                            className="h-4 w-4 rounded text-blue-700"
                          />
                          <span>{cfg.enabled ? 'مفعّلة' : 'موقفة'}</span>
                        </label>
                      </div>
                      <input
                        type="text"
                        value={cfg.label_ar}
                        onChange={(e) =>
                          setCustomCategories((prev) => ({
                            ...prev,
                            [catKey]: { ...cfg, label_ar: e.target.value },
                          }))
                        }
                        placeholder="عنوان خيار الخدمة الأخرى..."
                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs"
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white overflow-x-auto">
              <table className="w-full text-xs text-start">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="p-3 text-start">القسم</th>
                    <th className="p-3 text-start">الخدمة والملاحظات</th>
                    <th className="p-3 text-end">السعر</th>
                    <th className="p-3 text-center">الحالة</th>
                    <th className="p-3 text-end">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {services.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-500">
                        لا توجد خدمات محمّلة حالياً — اضغط «تحديث» بالأعلى لإعادة التحميل.
                      </td>
                    </tr>
                  ) : (
                    services.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50">
                        <td className="p-3 text-slate-500 whitespace-nowrap">
                          {s.category === 'printing' ? 'الطباعة' : s.category === 'admin' ? 'إدارية' : 'تصميم'}
                        </td>
                        <td className="p-3">
                          <div className="font-semibold text-slate-900">{s.name_ar}</div>
                          {s.pricing_note_ar && (
                            <div className="text-[11px] text-slate-500">{s.pricing_note_ar}</div>
                          )}
                        </td>
                        <td className="p-3 text-end font-mono-nums font-bold text-blue-800 whitespace-nowrap">
                          {s.price_max ? `${s.price}–${s.price_max}` : s.price} د.ج / {s.unit_label_ar}
                        </td>
                        <td className="p-3 text-center">
                          <button
                            type="button"
                            onClick={async () => {
                              await adminFetch(`/api/admin/services/${s.id}`, {
                                method: 'PATCH',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ active: s.active ? 0 : 1 }),
                              });
                              if (user) loadAllAdminData(user);
                              onDataUpdated();
                            }}
                            className={`rounded-lg px-2.5 py-1 text-[11px] font-bold cursor-pointer ${
                              s.active ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                            }`}
                          >
                            {s.active ? 'مفعّلة' : 'موقفة'}
                          </button>
                        </td>
                        <td className="p-3 text-end space-x-2 space-x-reverse whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => setEditingService(s)}
                            className="text-blue-700 font-semibold hover:underline cursor-pointer"
                          >
                            تعديل
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await adminFetch(`/api/admin/services/${s.id}`, { method: 'DELETE' });
                              if (user) loadAllAdminData(user);
                              onDataUpdated();
                            }}
                            className="text-rose-600 font-semibold hover:underline cursor-pointer"
                          >
                            حذف
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: FINANCIAL & DAILY ACCOUNTING */}
        {activeTab === 'accounting' && (
          <div className="space-y-6">
            {accounting.totals && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {(
                  [
                    ['الإجمالي اليومي', accounting.totals.daily],
                    ['الإجمالي الأسبوعي', accounting.totals.weekly],
                    ['الإجمالي الشهري', accounting.totals.monthly],
                    ['الإجمالي السنوي', accounting.totals.yearly],
                  ] as const
                ).map(([title, data]) => (
                  <div key={title} className="rounded-2xl border border-slate-200 bg-white p-5 space-y-2">
                    <div className="text-xs font-bold text-slate-500">{title}</div>
                    <div className="text-xl font-extrabold text-slate-900 font-mono-nums">
                      {data.profit} د.ج <span className="text-[11px] font-normal text-slate-500">صافي الربح</span>
                    </div>
                    <div className="flex justify-between text-[11px] font-mono-nums pt-1 border-t border-slate-100">
                      <span className="text-emerald-700">مداخيل: {data.income} د.ج</span>
                      <span className="text-rose-700">مصاريف: {data.expense} د.ج</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Add Manual Entry */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-base font-bold text-slate-900">تسجيل قيد مالي (مدخول / مصروف)</h3>
                <div className="flex flex-wrap gap-2">
                  <label className="inline-flex items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-bold text-blue-800 hover:bg-blue-100 cursor-pointer">
                    <Upload className="h-3.5 w-3.5" />
                    <span>استيراد قيود (CSV / JSON)</span>
                    <input
                      type="file"
                      accept=".json,.csv"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        e.target.value = '';
                        if (!file) return;
                        try {
                          const txt = await file.text();
                          let items: any[] = [];
                          if (file.name.toLowerCase().endsWith('.json')) {
                            const parsed = JSON.parse(txt);
                            items = Array.isArray(parsed) ? parsed : parsed.items || [];
                          } else {
                            items = parseCsvRows(txt);
                          }
                          const resp = await adminFetch('/api/admin/accounting/import', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ items }),
                          });
                          const d = await resp.json();
                          if (resp.ok) {
                            setAccMsg(`تم استيراد ${d.importedCount} قيداً مالياً بنجاح.`);
                            if (user) loadAllAdminData(user);
                          } else {
                            setAccMsg(d.error || 'تعذر استيراد القيود المالية.');
                          }
                        } catch {
                          setAccMsg('تنسيق الملف غير صالح.');
                        }
                      }}
                    />
                  </label>
                  <button
                    type="button"
                    onClick={exportAccountingCsv}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>تصدير CSV</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const rowsHtml = filteredAccounting
                        .map(
                          (entry) => `
                            <tr>
                              <td>${entry.entry_date}</td>
                              <td>${entry.entry_type === 'income' ? 'مدخول' : 'مصروف'}</td>
                              <td>${entry.category}</td>
                              <td>${entry.description.replace(/</g, '&lt;')}</td>
                              <td style="text-align:left; font-weight:700;">${entry.amount} د.ج</td>
                            </tr>`
                        )
                        .join('');
                      const tAll = accounting.totals?.allTime || { income: 0, expense: 0, profit: 0 };
                      printHtmlDocument(`<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <title>التقرير المالي — ${adminSettings?.officeName || config.officeName}</title>
  <style>
    @page { size: A4 portrait; margin: 12mm; }
    body { font-family: Tahoma, Arial, sans-serif; color: #0f172a; margin: 0; }
    h2 { margin: 0 0 4px; color: #1e3a8a; }
    .meta { font-size: 12px; color: #475569; margin-bottom: 14px; }
    .summary { display: flex; gap: 16px; margin-bottom: 16px; font-size: 12px; }
    .box { border: 1px solid #cbd5e1; border-radius: 6px; padding: 8px 12px; }
    table { width: 100%; border-collapse: collapse; font-size: 11.5px; }
    th, td { border-bottom: 1px solid #e2e8f0; padding: 7px 6px; text-align: right; }
    th { background: #f8fafc; color: #334155; }
  </style>
</head>
<body>
  <h2>التقرير المالي والمحاسبي — ${adminSettings?.officeName || config.officeName}</h2>
  <div class="meta">تاريخ الطباعة: ${new Date().toLocaleString('ar-DZ')} · ${adminSettings?.officeAddress || config.officeAddress}</div>
  <div class="summary">
    <div class="box">إجمالي المداخيل: <strong>${tAll.income} د.ج</strong></div>
    <div class="box">إجمالي المصاريف: <strong>${tAll.expense} د.ج</strong></div>
    <div class="box">صافي الربح: <strong>${tAll.profit} د.ج</strong></div>
  </div>
  <table>
    <thead>
      <tr>
        <th>التاريخ</th>
        <th>النوع</th>
        <th>التصنيف</th>
        <th>البيان</th>
        <th style="text-align:left;">المبلغ</th>
      </tr>
    </thead>
    <tbody>
      ${rowsHtml || '<tr><td colspan="5" style="text-align:center;">لا توجد قيود مسجلة</td></tr>'}
    </tbody>
  </table>
</body>
</html>`);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
                  >
                    <Printer className="h-3.5 w-3.5" />
                    <span>طباعة التقرير</span>
                  </button>
                </div>
              </div>

              {accMsg && (
                <div className="rounded-xl border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-bold text-blue-900">
                  {accMsg}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
                <select
                  value={newEntry.entry_type}
                  onChange={(e) =>
                    setNewEntry({ ...newEntry, entry_type: e.target.value as 'income' | 'expense' })
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold"
                >
                  <option value="income">مدخول (+)</option>
                  <option value="expense">مصروف (-)</option>
                </select>
                <input
                  type="text"
                  placeholder="التصنيف (حبر، ورق، كهرباء، خدمة...)"
                  value={newEntry.category}
                  onChange={(e) => setNewEntry({ ...newEntry, category: e.target.value })}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="text"
                  placeholder="الوصف *"
                  value={newEntry.description}
                  onChange={(e) => setNewEntry({ ...newEntry, description: e.target.value })}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="number"
                  placeholder="المبلغ د.ج *"
                  value={newEntry.amount}
                  onChange={(e) => setNewEntry({ ...newEntry, amount: e.target.value })}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <button
                  type="button"
                  onClick={async () => {
                    if (!newEntry.description.trim() || !newEntry.amount) return;
                    await adminFetch('/api/admin/accounting', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(newEntry),
                    });
                    setNewEntry({ ...newEntry, description: '', amount: '' });
                    if (user) loadAllAdminData(user);
                  }}
                  className="rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                >
                  إضافة القيد
                </button>
              </div>
            </div>

            {/* Accounting Ledger */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <input
                  type="text"
                  value={accSearch}
                  onChange={(e) => setAccSearch(e.target.value)}
                  placeholder="بحث في السجل المالي..."
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs w-64"
                />
                <div className="flex gap-1.5">
                  {(['all', 'income', 'expense'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setAccFilter(t)}
                      className={`rounded-lg px-3 py-1.5 text-xs font-bold cursor-pointer ${
                        accFilter === t ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {t === 'all' ? 'الكل' : t === 'income' ? 'المداخيل' : 'المصاريف'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <tr>
                      <th className="p-3 text-start">التاريخ</th>
                      <th className="p-3 text-start">النوع</th>
                      <th className="p-3 text-start">التصنيف</th>
                      <th className="p-3 text-start">البيان</th>
                      <th className="p-3 text-end">المبلغ</th>
                      <th className="p-3 text-end">حذف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredAccounting.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-6 text-center text-slate-500">
                          لا توجد قيود مسجلة بعد.
                        </td>
                      </tr>
                    ) : (
                      filteredAccounting.map((entry) => (
                        <tr key={entry.id}>
                          <td className="p-3 font-mono-nums text-slate-600">{entry.entry_date}</td>
                          <td className="p-3 font-bold">
                            <span className={entry.entry_type === 'income' ? 'text-emerald-700' : 'text-rose-700'}>
                              {entry.entry_type === 'income' ? 'مدخول' : 'مصروف'}
                            </span>
                          </td>
                          <td className="p-3 text-slate-600">{entry.category}</td>
                          <td className="p-3 font-semibold text-slate-900">{entry.description}</td>
                          <td className="p-3 text-end font-mono-nums font-bold">
                            {entry.amount} د.ج
                          </td>
                          <td className="p-3 text-end">
                            <button
                              type="button"
                              onClick={async () => {
                                await adminFetch(`/api/admin/accounting/${entry.id}`, { method: 'DELETE' });
                                if (user) loadAllAdminData(user);
                              }}
                              className="text-rose-600 hover:underline cursor-pointer"
                            >
                              حذف
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Materials & Inventory Stock */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <div className="flex items-center gap-2">
                <Package className="h-5 w-5 text-blue-700" />
                <h3 className="text-base font-bold text-slate-900">تكاليف المواد والمخزون (ورق، أحبار، بطاقات)</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-6 gap-2.5">
                <input
                  type="text"
                  placeholder="اسم المادة *"
                  value={newInv.name}
                  onChange={(e) => setNewInv({ ...newInv, name: e.target.value })}
                  className="sm:col-span-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="number"
                  placeholder="الكمية"
                  value={newInv.quantity}
                  onChange={(e) => setNewInv({ ...newInv, quantity: e.target.value })}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <input
                  type="text"
                  placeholder="الوحدة"
                  value={newInv.unit}
                  onChange={(e) => setNewInv({ ...newInv, unit: e.target.value })}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <input
                  type="number"
                  placeholder="التكلفة د.ج"
                  value={newInv.unit_cost}
                  onChange={(e) => setNewInv({ ...newInv, unit_cost: e.target.value })}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                />
                <button
                  type="button"
                  onClick={async () => {
                    if (!newInv.name.trim()) return;
                    await adminFetch('/api/admin/inventory', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify(newInv),
                    });
                    setNewInv({ name: '', category: 'paper', quantity: '', unit: 'رزمة', unit_cost: '', min_threshold: '5' });
                    if (user) loadAllAdminData(user);
                  }}
                  className="rounded-xl bg-blue-700 px-3 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                >
                  إضافة للمخزون
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {accounting.inventory.map((item) => {
                  const low = item.quantity <= item.min_threshold;
                  return (
                    <div
                      key={item.id}
                      className={`rounded-xl border p-4 space-y-2 ${
                        low ? 'border-amber-300 bg-amber-50/50' : 'border-slate-200 bg-slate-50/50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-900">{item.name}</span>
                        {low && <span className="text-[11px] font-bold text-amber-800">مخزون منخفض</span>}
                      </div>
                      <div className="flex items-center justify-between text-xs font-mono-nums text-slate-600">
                        <span>
                          الكمية: <strong>{item.quantity}</strong> {item.unit}
                        </span>
                        <span>التكلفة: {item.unit_cost} د.ج</span>
                      </div>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={async () => {
                            await adminFetch(`/api/admin/inventory/${item.id}`, {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ quantity: Math.max(0, item.quantity - 1) }),
                            });
                            if (user) loadAllAdminData(user);
                          }}
                          className="rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-bold cursor-pointer"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await adminFetch(`/api/admin/inventory/${item.id}`, {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ quantity: item.quantity + 1 }),
                            });
                            if (user) loadAllAdminData(user);
                          }}
                          className="rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-bold cursor-pointer"
                        >
                          +1
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: RECEIPT PRINT PREVIEW (ADMIN ONLY) */}
        {activeTab === 'printing' && (
          <ReceiptPrintPreview
            orders={orders}
            officeName={adminSettings?.officeName || config.officeName}
            officeLogo={adminSettings?.officeLogo ?? config.officeLogo}
            officeAddress={adminSettings?.officeAddress || config.officeAddress}
            printLockEnabled={Boolean(adminSettings?.printLockEnabled)}
            authToken={authToken}
            preselectedOrderId={printOrderTargetId}
          />
        )}

        {/* TAB 6: AI BUSINESS ADVISOR (ADMIN ONLY) */}
        {activeTab === 'ai' && (
          <div className="space-y-6">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-900">
                  مستشار الأعمال الذكي — سري وخاص بالإدارة فقط
                </h3>
                <p className="text-xs text-slate-600">
                  يحلل الطلبات والمخزون والمداخيل، ويتنبأ بوصول العميل القادم قبل حضوره لتجهيز المكتب مسبقاً.
                </p>
              </div>
              <button
                type="button"
                onClick={runAiAdvisor}
                disabled={aiLoading}
                className="inline-flex items-center gap-2 rounded-xl bg-blue-700 px-5 py-3 text-xs font-bold text-white hover:bg-blue-800 disabled:opacity-60 cursor-pointer"
              >
                <Brain className="h-4 w-4" />
                <span>{aiLoading ? 'جاري التحليل والتنبؤ...' : 'تشغيل التحليل والتنبؤ الآن'}</span>
              </button>
            </div>

            {aiError && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-xs font-bold text-rose-800">
                {aiError}
              </div>
            )}

            {aiReport && (
              <div className="space-y-6">
                {aiReport.aiWarning && (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 p-3.5 text-xs font-semibold text-amber-900">
                    {aiReport.aiWarning}
                  </div>
                )}

                {/* Confidence & Proactive Banner */}
                <div
                  className={`rounded-2xl border p-5 space-y-2 ${
                    aiReport.sufficientData
                      ? 'border-blue-200 bg-blue-50/50'
                      : 'border-sky-200 bg-sky-50/60'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-sm font-extrabold text-slate-900">
                      {aiReport.sufficientData
                        ? 'تقرير الأداء التجاري المعتمد على البيانات الفعلية'
                        : 'تحليل وتنبؤ استباقي قبل توافد الطلبات'}
                    </span>
                    <span className="text-xs font-bold text-slate-700 font-mono-nums">
                      مستوى الثقة:{' '}
                      {aiReport.confidenceLevel === 'high'
                        ? 'عالية'
                        : aiReport.confidenceLevel === 'medium'
                          ? 'متوسطة'
                          : 'استباقية (بداية التشغيل)'}{' '}
                      · ({aiReport.dataPointsUsed.ordersCount} طلب / {aiReport.dataPointsUsed.daysCovered} يوم)
                    </span>
                  </div>
                  <p className="text-xs text-slate-700">
                    {aiReport.insufficientMessage || aiReport.confidenceReason}
                  </p>
                </div>

                {/* Proactive Pre-Arrival Incoming Customer Prediction Card */}
                {aiReport.incomingCustomerPrediction && (
                  <div className="rounded-2xl border border-blue-200 bg-gradient-to-br from-blue-50 to-white p-6 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-700 text-white">
                          <Sparkles className="h-5 w-5" />
                        </div>
                        <div>
                          <h4 className="text-sm font-extrabold text-blue-950">
                            التنبؤ الاستباقي بالعميل القادم قبل وصوله (تنبيه الإدارة)
                          </h4>
                          <p className="text-xs text-blue-800">
                            {aiReport.incomingCustomerPrediction.expectedArrivalNote}
                          </p>
                        </div>
                      </div>
                      <div className="rounded-xl border border-blue-200 bg-white px-4 py-2 text-center">
                        <div className="text-[11px] text-slate-500">العملاء المتوقع قدومهم قريباً</div>
                        <div className="text-lg font-extrabold text-blue-800 font-mono-nums">
                          {aiReport.incomingCustomerPrediction.expectedNextCustomers}+ عميل
                        </div>
                      </div>
                    </div>

                    <div className="rounded-xl border border-blue-100 bg-white p-3.5 text-xs text-slate-700">
                      <strong className="text-blue-900">الخدمات المرجحة للعميل القادم: </strong>
                      {aiReport.incomingCustomerPrediction.likelyServiceNote}
                    </div>

                    {aiReport.incomingCustomerPrediction.readinessChecklist.length > 0 && (
                      <div className="space-y-1.5">
                        <div className="text-xs font-bold text-slate-800">قائمة جاهزية المكتب قبل وصول العميل:</div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {aiReport.incomingCustomerPrediction.readinessChecklist.map((item, idx) => (
                            <div
                              key={idx}
                              className="flex items-start gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-700"
                            >
                              <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{item}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* KPI Strip */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="rounded-2xl border border-slate-200 bg-white p-5">
                    <div className="text-xs text-slate-500">مؤشر نجاح المشروع</div>
                    <div className="mt-1 text-2xl font-extrabold text-blue-800 font-mono-nums">
                      {aiReport.businessSuccessScore !== null
                        ? `${aiReport.businessSuccessScore} / 100`
                        : 'بيانات غير كافية'}
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-5">
                    <div className="text-xs text-slate-500">الإيرادات / صافي الربح</div>
                    <div className="mt-1 text-xl font-extrabold text-slate-900 font-mono-nums">
                      {aiReport.metricsSummary.totalRevenue} / {aiReport.metricsSummary.netProfit} د.ج
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-5">
                    <div className="text-xs text-slate-500">توقع الطلبات / الإيراد (7 أيام)</div>
                    <div className="mt-1 text-xl font-extrabold text-slate-900 font-mono-nums">
                      {aiReport.forecasts.expectedOrdersNextWeek !== null
                        ? `${aiReport.forecasts.expectedOrdersNextWeek} طلب · ${aiReport.forecasts.expectedRevenueNextWeek} د.ج`
                        : 'غير متاح (نقص بيانات)'}
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-5">
                    <div className="text-xs text-slate-500">نسبة العملاء المتكررين / التقييم</div>
                    <div className="mt-1 text-xl font-extrabold text-slate-900 font-mono-nums">
                      {aiReport.metricsSummary.repeatCustomerRate}% ·{' '}
                      {aiReport.metricsSummary.avgRating ? `${aiReport.metricsSummary.avgRating}/5` : '—'}
                    </div>
                  </div>
                </div>

                {/* Interactive Charts (when real series exists) */}
                {aiReport.dailyTrend.length > 0 && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                      <h4 className="text-sm font-bold text-slate-900">تطور المداخيل والمصاريف اليومية</h4>
                      <div className="h-[240px] w-full" dir="ltr">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={aiReport.dailyTrend}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                            <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                            <YAxis tick={{ fontSize: 11 }} />
                            <Tooltip />
                            <Area type="monotone" dataKey="revenue" stroke="#1D4ED8" fill="#DBEAFE" name="المداخيل" />
                            <Area type="monotone" dataKey="expenses" stroke="#DC2626" fill="#FEE2E2" name="المصاريف" />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                      <h4 className="text-sm font-bold text-slate-900">الخدمات الأكثر طلباً وإيراداً</h4>
                      <div className="h-[240px] w-full" dir="ltr">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={aiReport.topServices}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                            <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                            <YAxis tick={{ fontSize: 11 }} />
                            <Tooltip />
                            <Bar dataKey="revenue" fill="#1D4ED8" name="الإيراد (د.ج)" radius={[6, 6, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                )}

                {/* Advice & Alerts */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-2">
                    <h4 className="text-xs font-bold text-blue-800">نصائح يومية</h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 list-disc ps-4">
                      {aiReport.advice.daily.map((a, i) => (
                        <li key={i}>{a}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-2">
                    <h4 className="text-xs font-bold text-blue-800">نصائح أسبوعية</h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 list-disc ps-4">
                      {aiReport.advice.weekly.map((a, i) => (
                        <li key={i}>{a}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-2">
                    <h4 className="text-xs font-bold text-blue-800">نصائح شهرية</h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 list-disc ps-4">
                      {aiReport.advice.monthly.map((a, i) => (
                        <li key={i}>{a}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                {aiReport.alerts.length > 0 && (
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                    <h4 className="text-sm font-bold text-slate-900">التنبيهات والفرص التجارية</h4>
                    {aiReport.alerts.map((al, i) => (
                      <div key={i} className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs">
                        <div className="font-bold text-slate-900">{al.title}</div>
                        <div className="text-slate-600 mt-0.5">{al.detail}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 7: REVIEWS (ADMIN ONLY) */}
        {activeTab === 'reviews' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <div className="text-xs text-slate-500">متوسط رضا العملاء</div>
                <div className="mt-1 text-2xl font-extrabold text-blue-800 font-mono-nums">
                  {reviewsData.average} / 5 ★
                </div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <div className="text-xs text-slate-500">إجمالي التقييمات والملاحظات</div>
                <div className="mt-1 text-2xl font-extrabold text-slate-900 font-mono-nums">
                  {reviewsData.total}
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3">
              <h3 className="text-base font-bold text-slate-900">سجل التقييمات والاقتراحات والشكاوى (سري للإدارة)</h3>
              {reviewsData.reviews.length === 0 ? (
                <p className="text-xs text-slate-500 py-4 text-center">لا توجد تقييمات مسجلة حتى الآن.</p>
              ) : (
                reviewsData.reviews.map((r) => (
                  <div key={r.id} className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">
                        {r.customer_name} · <span className="font-mono-nums text-blue-700">{r.tracking_code}</span>
                      </span>
                      <span className="font-mono-nums font-bold text-amber-600">
                        {'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)} ({r.category === 'complaint' ? 'شكوى' : r.category === 'suggestion' ? 'اقتراح' : 'تقييم'})
                      </span>
                    </div>
                    {r.comment && <p className="text-slate-700 leading-relaxed">{r.comment}</p>}
                    <div className="text-[11px] text-slate-400 font-mono-nums">
                      {new Date(r.created_at).toLocaleString('ar-DZ')}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 8: SETTINGS, OFFICE LOCATION, STAFF & BACKUP */}
        {activeTab === 'settings' && adminSettings && (
          <div className="space-y-6">
            {/* Office Location, Brand, Delivery & Display Settings */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-blue-700" />
                <h3 className="text-base font-bold text-slate-900">إعدادات الموقع، الشعار، التوصيل، وقفل الطباعة</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">اسم الموقع / المكتب (يظهر في المنصة والوصولات)</label>
                  <input
                    type="text"
                    value={adminSettings.officeName}
                    onChange={(e) => setAdminSettings({ ...adminSettings, officeName: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">العنوان النصي (مثال: حي أول نوفمبر، مركز الأعمال، الجزائر)</label>
                  <input
                    type="text"
                    value={adminSettings.officeAddress}
                    onChange={(e) => setAdminSettings({ ...adminSettings, officeAddress: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">بريد إشعارات الإدارة</label>
                  <input
                    type="email"
                    value={adminSettings.adminEmail}
                    onChange={(e) => setAdminSettings({ ...adminSettings, adminEmail: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">سعر التوصيل (د.ج)</label>
                  <input
                    type="number"
                    min={0}
                    value={adminSettings.deliveryBaseFee}
                    onChange={(e) => setAdminSettings({ ...adminSettings, deliveryBaseFee: Number(e.target.value) })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ساعات العمل صباحاً</label>
                  <input
                    type="text"
                    value={adminSettings.workingHoursMorning}
                    onChange={(e) => setAdminSettings({ ...adminSettings, workingHoursMorning: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ساعات العمل مساءً</label>
                  <input
                    type="text"
                    value={adminSettings.workingHoursEvening}
                    onChange={(e) => setAdminSettings({ ...adminSettings, workingHoursEvening: e.target.value })}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono-nums"
                  />
                </div>
              </div>

              {/* Site Logo Management */}
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                <div className="text-xs font-bold text-slate-900">شعار الموقع (اللوغو)</div>
                <div className="flex flex-wrap items-center gap-4">
                  {adminSettings.officeLogo ? (
                    <img
                      src={adminSettings.officeLogo}
                      alt={adminSettings.officeName}
                      className="h-14 w-14 rounded-xl border border-slate-200 bg-white object-contain p-1"
                    />
                  ) : (
                    <div className="flex h-14 w-14 items-center justify-center rounded-xl border border-dashed border-slate-300 bg-white text-[10px] text-slate-400">
                      بدون شعار
                    </div>
                  )}
                  <div className="flex flex-wrap items-center gap-2">
                    <label className="inline-flex items-center gap-1.5 rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer">
                      <Upload className="h-3.5 w-3.5" />
                      <span>رفع شعار جديد</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          e.target.value = '';
                          if (!file) return;
                          const fd = new FormData();
                          fd.append('logo', file);
                          const resp = await adminFetch('/api/admin/logo', {
                            method: 'POST',
                            body: fd,
                          });
                          if (resp.ok) {
                            const d = await resp.json();
                            setAdminSettings({ ...adminSettings, officeLogo: d.officeLogo });
                            setSettingsMsg('تم تحديث شعار الموقع بنجاح.');
                            onDataUpdated();
                          }
                        }}
                      />
                    </label>
                    {adminSettings.officeLogo && (
                      <button
                        type="button"
                        onClick={async () => {
                          const resp = await adminFetch('/api/admin/logo', { method: 'DELETE' });
                          if (resp.ok) {
                            setAdminSettings({ ...adminSettings, officeLogo: '' });
                            setSettingsMsg('تمت إزالة شعار الموقع.');
                            onDataUpdated();
                          }
                        }}
                        className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700 hover:bg-rose-100 cursor-pointer"
                      >
                        حذف الشعار
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Public Feature Toggles (Delivery & Customer Satisfaction Display) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-900 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(adminSettings.deliveryEnabled)}
                    onChange={(e) => setAdminSettings({ ...adminSettings, deliveryEnabled: e.target.checked })}
                    className="h-4 w-4 rounded text-blue-700"
                  />
                  <span>تفعيل خيار «توصيل الطلب إلى موقعي» للعملاء</span>
                </label>

                <label className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-slate-50 p-4 text-xs font-bold text-slate-900 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(adminSettings.showSatisfactionSummary)}
                    onChange={(e) =>
                      setAdminSettings({ ...adminSettings, showSatisfactionSummary: e.target.checked })
                    }
                    className="h-4 w-4 rounded text-blue-700"
                  />
                  <span>إظهار قسم «متوسط رضا العملاء» في واجهة العملاء</span>
                </label>
              </div>

              {/* Print Lock Configuration */}
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
                <label className="flex items-center gap-2.5 text-xs font-bold text-slate-900 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={Boolean(adminSettings.printLockEnabled)}
                    onChange={(e) => setAdminSettings({ ...adminSettings, printLockEnabled: e.target.checked })}
                    className="h-4 w-4 rounded text-blue-700"
                  />
                  <span>تفعيل قفل نظام الطباعة برمز حماية</span>
                </label>
                {adminSettings.printLockEnabled && (
                  <input
                    type="password"
                    placeholder="تعيين/تحديث رمز قفل الطباعة (اتركه فارغاً للإبقاء على الحالي)"
                    value={adminSettings.printLockPin || ''}
                    onChange={(e) => setAdminSettings({ ...adminSettings, printLockPin: e.target.value })}
                    className="w-full sm:w-80 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs"
                  />
                )}
              </div>

              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-700">
                  حدد موقع المكتب المحفوظ على خريطة Google ({adminSettings.officeLat}, {adminSettings.officeLng}):
                </div>
                <AdminOfficeLocationPicker
                  apiKey={config.googleMapsApiKey}
                  position={{ lat: Number(adminSettings.officeLat), lng: Number(adminSettings.officeLng) }}
                  onChange={(pos, addr) =>
                    setAdminSettings({
                      ...adminSettings,
                      officeLat: pos.lat,
                      officeLng: pos.lng,
                      officeAddress: addr || adminSettings.officeAddress,
                    })
                  }
                />
              </div>

              {settingsMsg && <div className="text-xs font-bold text-emerald-700">{settingsMsg}</div>}

              <button
                type="button"
                onClick={async () => {
                  const resp = await adminFetch('/api/admin/settings', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(adminSettings),
                  });
                  if (resp.ok) {
                    setSettingsMsg('تم حفظ الإعدادات وموقع المكتب بنجاح.');
                    onDataUpdated();
                  }
                }}
                className="inline-flex items-center gap-2 rounded-xl bg-blue-700 px-5 py-2.5 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
              >
                <Check className="h-4 w-4" />
                <span>حفظ الإعدادات</span>
              </button>
            </div>

            {/* Admin-Only File Import Vault */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <FolderOpen className="h-5 w-5 text-blue-700" />
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      استيراد وأرشيف الملفات (خاص بالإدارة فقط)
                    </h3>
                    <p className="text-xs text-slate-500">
                      استيراد وحفظ النماذج الجاهزة، الوثائق، عقود العمل، وملفات التصميم الخاصة بالإدارة بسرية تامة.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-center">
                <select
                  value={vaultCategory}
                  onChange={(e) => setVaultCategory(e.target.value)}
                  className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold"
                >
                  <option value="templates">قوالب ونماذج جاهزة</option>
                  <option value="documents">وثائق ومستندات إدارية</option>
                  <option value="designs">ملفات تصميم وإشهار</option>
                  <option value="general">ملفات عامة</option>
                </select>
                <input
                  type="text"
                  placeholder="ملاحظة عن الملفات المستوردة (اختياري)"
                  value={vaultNotes}
                  onChange={(e) => setVaultNotes(e.target.value)}
                  className="sm:col-span-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                />
                <label className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer">
                  <Upload className="h-3.5 w-3.5" />
                  <span>{vaultUploading ? 'جاري الاستيراد...' : 'استيراد ملفات (حتى 10)'}</span>
                  <input
                    type="file"
                    multiple
                    disabled={vaultUploading}
                    className="hidden"
                    onChange={async (e) => {
                      const files = e.target.files;
                      e.target.value = '';
                      if (!files || files.length === 0) return;
                      setVaultUploading(true);
                      try {
                        const fd = new FormData();
                        fd.append('category', vaultCategory);
                        fd.append('notes', vaultNotes);
                        Array.from(files)
                          .slice(0, 10)
                          .forEach((f) => fd.append('files', f));
                        const resp = await adminFetch('/api/admin/vault-files', {
                          method: 'POST',
                          body: fd,
                        });
                        if (resp.ok) {
                          setVaultNotes('');
                          setSettingsMsg('تم استيراد الملفات إلى أرشيف الإدارة بنجاح.');
                          if (user) loadAllAdminData(user);
                        }
                      } finally {
                        setVaultUploading(false);
                      }
                    }}
                  />
                </label>
              </div>

              {vaultFiles.length === 0 ? (
                <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-500">
                  لا توجد ملفات مستوردة في أرشيف الإدارة بعد.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {vaultFiles.map((vf) => (
                    <div
                      key={vf.id}
                      className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs"
                    >
                      <div className="min-w-0">
                        <div className="font-bold text-slate-900 truncate">{vf.original_name}</div>
                        <div className="text-[11px] text-slate-500 font-mono-nums">
                          {vf.category} · {(vf.size_bytes / 1024).toFixed(0)} KB
                          {vf.notes ? ` · ${vf.notes}` : ''}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <a
                          href={`/api/admin/vault-files/${vf.id}${
                            authToken ? `?token=${encodeURIComponent(authToken)}` : ''
                          }`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1 text-[11px] font-bold text-blue-800 hover:bg-blue-100"
                        >
                          <Download className="h-3 w-3" />
                          <span>تنزيل</span>
                        </a>
                        <button
                          type="button"
                          onClick={async () => {
                            await adminFetch(`/api/admin/vault-files/${vf.id}`, { method: 'DELETE' });
                            if (user) loadAllAdminData(user);
                          }}
                          className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50 cursor-pointer"
                          title="حذف"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Staff Permissions & Password Security */}
            {hasPerm('staff') && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-700" />
                    <h3 className="text-base font-bold text-slate-900">صلاحيات فريق العمل</h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <input
                      type="text"
                      placeholder="اسم المستخدم"
                      value={newStaff.username}
                      onChange={(e) => setNewStaff({ ...newStaff, username: e.target.value })}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                    />
                    <input
                      type="text"
                      placeholder="الاسم الظاهر"
                      value={newStaff.display_name}
                      onChange={(e) => setNewStaff({ ...newStaff, display_name: e.target.value })}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                    />
                    <select
                      value={newStaff.role}
                      onChange={(e) => setNewStaff({ ...newStaff, role: e.target.value as StaffUser['role'] })}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                    >
                      <option value="operator">موظف تشغيل وطباعة</option>
                      <option value="delivery">مكلف بالتوصيل</option>
                      <option value="manager">مدير قسم</option>
                    </select>
                    <input
                      type="password"
                      placeholder="كلمة مرور (6+ أحرف)"
                      value={newStaff.password}
                      onChange={(e) => setNewStaff({ ...newStaff, password: e.target.value })}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                    />
                  </div>

                  <div className="flex flex-wrap gap-2 text-[11px]">
                    {[
                      ['orders', 'الطلبات'],
                      ['delivery', 'التوصيل'],
                      ['printing', 'الطباعة'],
                      ['pricing', 'الأسعار'],
                      ['accounting', 'المالية'],
                      ['ai_advisor', 'المستشار الذكي'],
                      ['reviews', 'التقييمات'],
                    ].map(([p, lbl]) => {
                      const active = newStaff.permissions.includes(p);
                      return (
                        <button
                          key={p}
                          type="button"
                          onClick={() =>
                            setNewStaff({
                              ...newStaff,
                              permissions: active
                                ? newStaff.permissions.filter((x) => x !== p)
                                : [...newStaff.permissions, p],
                            })
                          }
                          className={`rounded-lg px-2.5 py-1 font-bold cursor-pointer ${
                            active ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {lbl}
                        </button>
                      );
                    })}
                  </div>

                  <button
                    type="button"
                    onClick={async () => {
                      const resp = await adminFetch('/api/admin/staff', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(newStaff),
                      });
                      if (resp.ok) {
                        setNewStaff({ username: '', display_name: '', role: 'operator', password: '', permissions: ['orders'] });
                        if (user) loadAllAdminData(user);
                      }
                    }}
                    className="rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                  >
                    إضافة عضو فريق
                  </button>

                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    {staffList.map((st) => (
                      <div key={st.id} className="flex items-center justify-between text-xs rounded-lg bg-slate-50 p-2.5">
                        <div>
                          <span className="font-bold">{st.display_name}</span> ({st.username}) · {st.role}
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await adminFetch(`/api/admin/staff/${st.id}`, { method: 'DELETE' });
                            if (user) loadAllAdminData(user);
                          }}
                          className="text-rose-600 font-semibold cursor-pointer"
                        >
                          إزالة
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Security & Backup */}
                <div className="space-y-6">
                  <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
                    <div className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-blue-700" />
                      <h3 className="text-base font-bold text-slate-900">تغيير كلمة مرور الإدارة</h3>
                    </div>
                    <input
                      type="password"
                      placeholder="كلمة المرور الحالية"
                      value={pwForm.currentPassword}
                      onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                    />
                    <input
                      type="password"
                      placeholder="كلمة المرور الجديدة (8 أحرف على الأقل)"
                      value={pwForm.newPassword}
                      onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        const resp = await adminFetch('/api/admin/change-password', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify(pwForm),
                        });
                        if (resp.ok) {
                          setPwForm({ currentPassword: '', newPassword: '' });
                          setSettingsMsg('تم تحديث كلمة مرور الإدارة بنجاح.');
                        }
                      }}
                      className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 cursor-pointer"
                    >
                      تحديث كلمة المرور
                    </button>
                  </div>

                  <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3">
                    <div className="flex items-center gap-2">
                      <Database className="h-5 w-5 text-blue-700" />
                      <h3 className="text-base font-bold text-slate-900">النسخ الاحتياطي واستعادة البيانات</h3>
                    </div>
                    <p className="text-xs text-slate-600">
                      قم بتنزيل نسخة احتياطية كاملة لضمان عدم فقدان أي طلبات أو حسابات عند تحديث التطبيق.
                    </p>
                    <div className="flex flex-wrap gap-3">
                      <button
                        type="button"
                        onClick={async () => {
                          const resp = await adminFetch('/api/admin/backup');
                          if (!resp.ok) {
                            setSettingsMsg('تعذر تحميل النسخة الاحتياطية.');
                            return;
                          }
                          const blob = await resp.blob();
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `graphicore-backup-${new Date().toISOString().slice(0, 10)}.json`;
                          a.click();
                          URL.revokeObjectURL(url);
                        }}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>تحميل نسخة احتياطية (JSON)</span>
                      </button>
                      <label className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer">
                        <Upload className="h-3.5 w-3.5" />
                        <span>استعادة من ملف</span>
                        <input
                          type="file"
                          accept=".json"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            const txt = await file.text();
                            const json = JSON.parse(txt);
                            const resp = await adminFetch('/api/admin/restore', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify(json),
                            });
                            if (resp.ok && user) {
                              setSettingsMsg('تمت استعادة النسخة الاحتياطية بنجاح.');
                              loadAllAdminData(user);
                              onDataUpdated();
                            }
                          }}
                        />
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Permanent Order Deletion Confirmation Modal */}
      {deleteConfirmOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 space-y-5 shadow-xl">
            <div className="flex items-center gap-3 text-rose-700">
              <AlertTriangle className="h-6 w-6 shrink-0" />
              <h3 className="text-base font-bold text-slate-900">تأكيد الحذف النهائي للطلب</h3>
            </div>
            <p className="text-xs leading-relaxed text-slate-600">
              هل أنت متأكد من حذف الطلب{' '}
              <strong className="font-mono-nums text-slate-900">{deleteConfirmOrder.tracking_code}</strong>{' '}
              للعميل <strong>{deleteConfirmOrder.customer_name}</strong>؟ سيتم حذف جميع ملفاته ومراسلاته نهائياً ولن يعود إلى النظام.
            </p>
            <div className="flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmOrder(null)}
                className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={confirmPermanentDeleteOrder}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-700 cursor-pointer"
              >
                تأكيد الحذف النهائي
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
