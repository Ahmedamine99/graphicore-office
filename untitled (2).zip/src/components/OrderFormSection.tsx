import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Copy,
  FileText,
  MapPin,
  Minus,
  Plus,
  Printer,
  Briefcase,
  Palette,
  Trash2,
  Upload,
  AlertCircle,
} from 'lucide-react';
import type {
  CustomServiceRequest,
  Language,
  Order,
  PublicConfig,
  ServiceCategory,
  ServiceItem,
} from '../types';
import { getPricingNote, getServiceName, getUnitLabel, TRANSLATIONS } from '../i18n';
import { DeliveryLocationPicker } from './MapsWidget';
import { playNotificationChime } from '../utils/sound';

interface SelectionState {
  selected: boolean;
  quantity: number;
  includeDesignPrint: boolean;
  includeDesignSetup: boolean;
}

export const OrderFormSection: React.FC<{
  lang: Language;
  services: ServiceItem[];
  config: PublicConfig;
  onOrderCreated: (order: Order) => void;
  onOpenDirections: () => void;
  onJumpToTrack: (trackingCode: string) => void;
}> = ({ lang, services, config, onOrderCreated, onOpenDirections, onJumpToTrack }) => {
  const t = TRANSLATIONS[lang];

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [selections, setSelections] = useState<Record<number, SelectionState>>({});
  const [customRequests, setCustomRequests] = useState<
    Record<ServiceCategory, { enabled: boolean; description: string; quantity: number }>
  >({
    printing: { enabled: false, description: '', quantity: 1 },
    admin: { enabled: false, description: '', quantity: 1 },
    design: { enabled: false, description: '', quantity: 1 },
  });
  const [files, setFiles] = useState<File[]>([]);
  const [notes, setNotes] = useState('');
  const [pickupType, setPickupType] = useState<'tomorrow_morning' | 'scheduled' | 'asap'>('tomorrow_morning');
  const [pickupDatetime, setPickupDatetime] = useState('');
  const [deliveryRequested, setDeliveryRequested] = useState(false);
  const [deliveryPos, setDeliveryPos] = useState<{ lat: number; lng: number } | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [copied, setCopied] = useState(false);

  const grouped = useMemo(() => {
    const byCat: Record<ServiceCategory, ServiceItem[]> = {
      printing: [],
      admin: [],
      design: [],
    };
    for (const s of services) {
      if (byCat[s.category]) byCat[s.category].push(s);
    }
    return byCat;
  }, [services]);

  const toggleService = (service: ServiceItem) => {
    setSelections((prev) => {
      const current = prev[service.id];
      if (current?.selected) {
        const next = { ...prev };
        delete next[service.id];
        return next;
      }
      return {
        ...prev,
        [service.id]: {
          selected: true,
          quantity: service.print_unit_price !== null ? 1 : Math.max(1, service.min_qty || 1),
          includeDesignPrint: false,
          includeDesignSetup: true,
        },
      };
    });
  };

  const updateSelection = (serviceId: number, patch: Partial<SelectionState>) => {
    setSelections((prev) => {
      const current = prev[serviceId];
      if (!current) return prev;
      return { ...prev, [serviceId]: { ...current, ...patch } };
    });
  };

  const calcServiceSubtotal = (s: ServiceItem, sel: SelectionState): number => {
    if (s.print_unit_price !== null && s.setup_design_fee > 0) {
      if (sel.includeDesignPrint) {
        const qty = Math.max(s.min_qty || 100, sel.quantity);
        return s.setup_design_fee + qty * s.print_unit_price;
      }
      return s.setup_design_fee;
    }
    const setup = s.setup_design_fee > 0 && sel.includeDesignSetup ? s.setup_design_fee : 0;
    return sel.quantity * s.price + setup;
  };

  const selectedItemsList = useMemo(() => {
    return services
      .filter((s) => selections[s.id]?.selected)
      .map((s) => {
        const sel = selections[s.id];
        return {
          service: s,
          sel,
          subtotal: calcServiceSubtotal(s, sel),
        };
      });
  }, [services, selections]);

  const activeCustomList: CustomServiceRequest[] = useMemo(() => {
    return (['printing', 'admin', 'design'] as ServiceCategory[])
      .filter((cat) => customRequests[cat].enabled && customRequests[cat].description.trim().length > 0)
      .map((cat) => ({
        category: cat,
        description: customRequests[cat].description.trim(),
        quantity: Math.max(1, customRequests[cat].quantity),
      }));
  }, [customRequests]);

  const estimatedTotal = useMemo(() => {
    const itemsTotal = selectedItemsList.reduce((sum, x) => sum + x.subtotal, 0);
    const delFee = config.deliveryEnabled && deliveryRequested ? config.deliveryBaseFee : 0;
    return itemsTotal + delFee;
  }, [selectedItemsList, deliveryRequested, config.deliveryEnabled, config.deliveryBaseFee]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const chosen = Array.from(e.target.files || []);
    if (chosen.length === 0) return;
    setFiles((prev) => [...prev, ...chosen].slice(0, 10));
    e.target.value = '';
  };

  const removeFile = (idx: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanPhone = customerPhone.replace(/\s+/g, '').trim();
    if (customerName.trim().length < 2) {
      setErrorMsg(lang === 'fr' ? 'Veuillez saisir votre nom complet.' : lang === 'en' ? 'Please enter your full name.' : 'يرجى إدخال الاسم الكامل.');
      return;
    }
    if (!/^0\d{9}$/.test(cleanPhone) && !/^\+[1-9]\d{7,14}$/.test(cleanPhone)) {
      setErrorMsg(t.phoneHelp);
      return;
    }
    if (selectedItemsList.length === 0 && activeCustomList.length === 0) {
      setErrorMsg(
        lang === 'fr'
          ? 'Veuillez sélectionner au moins un service ou décrire une demande personnalisée.'
          : lang === 'en'
            ? 'Please select at least one service or add a custom request.'
            : 'يرجى اختيار خدمة واحدة على الأقل أو إضافة طلب خدمة حسب الطلب.'
      );
      return;
    }
    if (!termsAccepted) {
      setErrorMsg(
        lang === 'fr'
          ? 'Vous devez accepter les conditions avant d’envoyer.'
          : lang === 'en'
            ? 'Please accept the terms before submitting.'
            : 'الموافقة على شروط الطلب والاستلام والتسديد إلزامية قبل الإرسال.'
      );
      return;
    }

    setSubmitting(true);
    let createdOrder: Order | null = null;
    try {
      const formData = new FormData();
      formData.append('customer_name', customerName.trim());
      formData.append('customer_phone', cleanPhone);
      formData.append(
        'items_json',
        JSON.stringify(
          selectedItemsList.map((x) => ({
            serviceId: x.service.id,
            quantity:
              x.service.print_unit_price !== null && x.sel.includeDesignPrint
                ? Math.max(x.service.min_qty || 100, x.sel.quantity)
                : x.sel.quantity,
            includeDesignPrint: x.sel.includeDesignPrint,
            includeDesignSetup: x.sel.includeDesignSetup,
          }))
        )
      );
      formData.append('custom_requests_json', JSON.stringify(activeCustomList));
      formData.append('notes', notes);
      formData.append('pickup_type', pickupType);
      if (pickupType === 'scheduled' && pickupDatetime) {
        formData.append('pickup_datetime', pickupDatetime);
      }
      const sendDelivery = config.deliveryEnabled && deliveryRequested;
      formData.append('delivery_requested', sendDelivery ? '1' : '0');
      if (sendDelivery && deliveryPos) {
        formData.append('delivery_lat', String(deliveryPos.lat));
        formData.append('delivery_lng', String(deliveryPos.lng));
      }
      formData.append('delivery_address', sendDelivery ? deliveryAddress : '');
      formData.append('terms_accepted', '1');
      for (const f of files.slice(0, 10)) {
        formData.append('files', f);
      }

      const resp = await fetch('/api/orders', {
        method: 'POST',
        body: formData,
      });
      const rawText = await resp.text();
      let data: any = null;
      try {
        data = rawText ? JSON.parse(rawText) : null;
      } catch {
        data = null;
      }

      if (!resp.ok) {
        setErrorMsg(
          data?.error ||
            (lang === 'fr'
              ? `Erreur serveur (${resp.status}).`
              : lang === 'en'
                ? `Server error (${resp.status}).`
                : `تعذر تسجيل الطلب (رمز الحالة ${resp.status}). يرجى المحاولة مجدداً.`)
        );
        return;
      }
      if (!data || !data.tracking_code) {
        setErrorMsg(
          lang === 'fr'
            ? 'Réponse invalide du serveur.'
            : lang === 'en'
              ? 'Invalid response from server.'
              : 'استجابة غير متوقعة من الخادم، يرجى تحديث الصفحة والمحاولة.'
        );
        return;
      }
      createdOrder = data as Order;
    } catch {
      setErrorMsg(
        lang === 'fr'
          ? 'Erreur de connexion au serveur.'
          : lang === 'en'
            ? 'Network error while submitting order.'
            : 'تعذر الاتصال بالخادم، يرجى التحقق من الإنترنت والمحاولة مجدداً.'
      );
      return;
    } finally {
      setSubmitting(false);
    }

    if (createdOrder) {
      setConfirmedOrder(createdOrder);
      try {
        playNotificationChime('order');
      } catch {
        // ignore audio errors
      }
      try {
        onOrderCreated(createdOrder);
      } catch {
        // ignore parent callback errors
      }
    }
  };

  const resetForm = () => {
    setConfirmedOrder(null);
    setSelections({});
    setCustomRequests({
      printing: { enabled: false, description: '', quantity: 1 },
      admin: { enabled: false, description: '', quantity: 1 },
      design: { enabled: false, description: '', quantity: 1 },
    });
    setFiles([]);
    setNotes('');
    setTermsAccepted(false);
    setErrorMsg(null);
  };

  const renderCategoryBlock = (
    cat: ServiceCategory,
    title: string,
    IconComponent: React.FC<{ className?: string }>
  ) => {
    const list = grouped[cat];
    const custom = customRequests[cat];
    const customCatCfg = config.customCategories?.[cat];
    const customBoxEnabled = customCatCfg ? customCatCfg.enabled : true;
    const customToggleLabel =
      lang === 'ar' && customCatCfg?.label_ar?.trim()
        ? customCatCfg.label_ar.trim()
        : t.customServiceToggle;

    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-700">
            <IconComponent className="h-5 w-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">{title}</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {list.map((service) => {
            const sel = selections[service.id];
            const isSelected = Boolean(sel?.selected);
            const isBusinessCard = service.print_unit_price !== null && service.setup_design_fee > 0;
            const hasSetupFee = !isBusinessCard && service.setup_design_fee > 0;
            const note = getPricingNote(service, lang);

            return (
              <div
                key={service.id}
                className={`rounded-xl border p-4 transition-colors ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/40'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => toggleService(service)}
                    className="flex items-start gap-3 text-start flex-1 cursor-pointer"
                  >
                    <span
                      className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border ${
                        isSelected
                          ? 'border-blue-700 bg-blue-700 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {isSelected && <CheckCircle2 className="h-3.5 w-3.5" />}
                    </span>
                    <div className="space-y-1">
                      <div className="text-sm font-semibold text-slate-900">
                        {getServiceName(service, lang)}
                      </div>
                      {note && <div className="text-xs text-slate-500">{note}</div>}
                    </div>
                  </button>

                  <div className="text-end shrink-0 font-mono-nums">
                    <span className="text-sm font-bold text-blue-800">
                      {service.price_max
                        ? `${service.price}–${service.price_max}`
                        : service.price}{' '}
                      {t.currency}
                    </span>
                    <div className="text-[11px] text-slate-500">/ {getUnitLabel(service, lang)}</div>
                  </div>
                </div>

                {isSelected && sel && (
                  <div className="mt-3 pt-3 border-t border-blue-100 space-y-2.5">
                    {isBusinessCard && (
                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            updateSelection(service.id, { includeDesignPrint: false, quantity: 1 })
                          }
                          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                            !sel.includeDesignPrint
                              ? 'bg-blue-700 text-white'
                              : 'bg-white border border-slate-200 text-slate-700'
                          }`}
                        >
                          {t.designOnlyOption}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            updateSelection(service.id, {
                              includeDesignPrint: true,
                              quantity: Math.max(service.min_qty || 100, sel.quantity < 100 ? 100 : sel.quantity),
                            })
                          }
                          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                            sel.includeDesignPrint
                              ? 'bg-blue-700 text-white'
                              : 'bg-white border border-slate-200 text-slate-700'
                          }`}
                        >
                          {t.designAndPrintOption}
                        </button>
                      </div>
                    )}

                    {hasSetupFee && (
                      <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={sel.includeDesignSetup}
                          onChange={(e) =>
                            updateSelection(service.id, { includeDesignSetup: e.target.checked })
                          }
                          className="h-4 w-4 rounded border-slate-300 text-blue-700"
                        />
                        <span>
                          {t.includeWeddingDesign} (+{service.setup_design_fee} {t.currency})
                        </span>
                      </label>
                    )}

                    {(!isBusinessCard || sel.includeDesignPrint) && (
                      <div className="flex items-center justify-between gap-3">
                        <span className="text-xs font-medium text-slate-600">{t.customQty}:</span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              const minQ = isBusinessCard && sel.includeDesignPrint ? service.min_qty || 100 : 1;
                              const step = isBusinessCard ? 50 : 1;
                              updateSelection(service.id, {
                                quantity: Math.max(minQ, sel.quantity - step),
                              });
                            }}
                            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <input
                            type="number"
                            min={isBusinessCard && sel.includeDesignPrint ? service.min_qty || 100 : 1}
                            value={sel.quantity}
                            onChange={(e) => {
                              const minQ = isBusinessCard && sel.includeDesignPrint ? service.min_qty || 100 : 1;
                              updateSelection(service.id, {
                                quantity: Math.max(minQ, Number(e.target.value) || minQ),
                              });
                            }}
                            className="w-20 rounded-lg border border-slate-200 bg-white px-2 py-1 text-center text-sm font-semibold font-mono-nums"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const step = isBusinessCard ? 50 : 1;
                              updateSelection(service.id, { quantity: sel.quantity + step });
                            }}
                            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 cursor-pointer"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-xs font-bold text-blue-900 font-mono-nums">
                      <span>{lang === 'ar' ? 'المجموع الفرعي:' : lang === 'fr' ? 'Sous-total :' : 'Subtotal:'}</span>
                      <span>
                        {calcServiceSubtotal(service, sel)} {t.currency}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Custom unpriced service request per category */}
        {customBoxEnabled && (
          <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/70 p-4 space-y-3">
            <label className="flex items-center gap-2.5 text-sm font-semibold text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={custom.enabled}
                onChange={(e) =>
                  setCustomRequests((prev) => ({
                    ...prev,
                    [cat]: { ...prev[cat], enabled: e.target.checked },
                  }))
                }
                className="h-4 w-4 rounded border-slate-300 text-blue-700"
              />
              <span>{customToggleLabel}</span>
            </label>

            {custom.enabled && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-1">
                <textarea
                  rows={2}
                  value={custom.description}
                  onChange={(e) =>
                    setCustomRequests((prev) => ({
                      ...prev,
                      [cat]: { ...prev[cat], description: e.target.value },
                    }))
                  }
                  placeholder={t.customServicePlaceholder}
                  className="md:col-span-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-600 focus:outline-none"
                />
                <div>
                  <label className="block text-xs text-slate-600 mb-1">{t.customQty}</label>
                  <input
                    type="number"
                    min={1}
                    value={custom.quantity}
                    onChange={(e) =>
                      setCustomRequests((prev) => ({
                        ...prev,
                        [cat]: { ...prev[cat], quantity: Math.max(1, Number(e.target.value) || 1) },
                      }))
                    }
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-mono-nums"
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-10">
      {/* Hero Section */}
      <section className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center space-y-6">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
              <span>{config.officeName}</span>
              <span aria-hidden="true">·</span>
              <span>
                {t.morningHours}: {config.workingHoursMorning}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {t.eveningHours}: {config.workingHoursEvening}
              </span>
            </div>

            <h1
              className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-900 leading-snug"
              style={{ textWrap: 'balance' }}
            >
              {t.heroTitle}
            </h1>

            <p className="text-base text-slate-600 leading-relaxed max-w-2xl">{t.heroSubtitle}</p>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <a
                href="#order-form"
                className="inline-flex items-center justify-center rounded-xl bg-blue-700 px-6 py-3 text-sm font-bold text-white hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0"
              >
                {t.startOrderCta}
              </a>
              <button
                type="button"
                onClick={onOpenDirections}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-800 hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <MapPin className="h-4 w-4 text-blue-700" />
                <span>{t.ourLocationBtn}</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 relative min-h-[240px] bg-gradient-to-br from-blue-900 to-sky-700">
            <img
              src="/src/assets/images/hero_print_studio_men_1794773926685.jpg"
              alt={config.officeName || 'Graphicore Office'}
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).style.display = 'none';
              }}
            />
          </div>
        </div>
      </section>

      {/* Order Confirmation State OR Full Order Form */}
      {confirmedOrder ? (
        <section
          id="order-form"
          className="rounded-2xl border border-blue-200 bg-white p-8 max-w-2xl mx-auto text-center space-y-6"
        >
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-slate-900">{t.orderConfirmedTitle}</h2>
            <p className="text-sm text-slate-600">{config.officeAddress}</p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50 p-5 space-y-2">
            <div className="text-xs font-medium text-slate-500">{t.trackingCodeLabel}</div>
            <div className="text-2xl sm:text-3xl font-extrabold tracking-wider text-blue-800 font-mono-nums">
              {confirmedOrder.tracking_code}
            </div>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(confirmedOrder.tracking_code);
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <Copy className="h-3.5 w-3.5" />
              <span>{copied ? '✓' : t.copyCode}</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => onJumpToTrack(confirmedOrder.tracking_code)}
              className="rounded-xl bg-blue-700 px-6 py-3 text-sm font-bold text-white hover:bg-blue-800 transition-colors cursor-pointer"
            >
              {t.goToTrack}
            </button>
            <button
              type="button"
              onClick={resetForm}
              className="rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              {t.newOrderBtn}
            </button>
          </div>
        </section>
      ) : (
        <form id="order-form" onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left / Main Form Column */}
          <div className="lg:col-span-8 space-y-6">
            {/* Customer Info */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <h2 className="text-lg font-bold text-slate-900">{t.sectionCustomer}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t.fullName} *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:bg-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    {t.phoneLabel} *
                  </label>
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder={t.phonePlaceholder}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 font-mono-nums focus:border-blue-600 focus:bg-white focus:outline-none"
                  />
                  <p className="mt-1 text-[11px] text-slate-500">{t.phoneHelp}</p>
                </div>
              </div>
            </div>

            {/* Section 1: Printing */}
            {renderCategoryBlock('printing', t.sectionPrinting, Printer)}

            {/* Section 2: Administrative */}
            {renderCategoryBlock('admin', t.sectionAdmin, Briefcase)}

            {/* Section 3: Design */}
            {renderCategoryBlock('design', t.sectionDesign, Palette)}

            {/* Section 4: Upload up to 10 files from Mobile/Desktop */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-900">{t.sectionFiles}</h3>
                <span className="text-xs font-semibold text-slate-500 font-mono-nums">
                  {files.length} / 10
                </span>
              </div>
              <p className="text-xs text-slate-600">{t.filesHint}</p>

              <label className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-blue-200 bg-blue-50/40 p-6 text-center hover:bg-blue-50 transition-colors cursor-pointer">
                <Upload className="h-7 w-7 text-blue-700 mb-2" />
                <span className="text-sm font-bold text-blue-900">{t.selectFilesBtn}</span>
                <input
                  type="file"
                  multiple
                  accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar,.ai,.psd,.cdr"
                  onChange={handleFileChange}
                  disabled={files.length >= 10}
                  className="hidden"
                />
              </label>

              {files.length > 0 && (
                <div className="space-y-2">
                  {files.map((file, idx) => (
                    <div
                      key={`${file.name}-${idx}`}
                      className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <FileText className="h-4 w-4 text-blue-700 shrink-0" />
                        <span className="truncate font-medium text-slate-800">{file.name}</span>
                        <span className="text-slate-400 font-mono-nums shrink-0">
                          ({(file.size / 1024).toFixed(0)} KB)
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(idx)}
                        className="rounded p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Section 5: Schedule, Notes, Delivery Map & Terms */}
            <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
              <div className="flex items-center gap-2.5">
                <Clock className="h-5 w-5 text-blue-700" />
                <h3 className="text-lg font-bold text-slate-900">{t.sectionScheduleDelivery}</h3>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">{t.pickupLabel}</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {(
                    [
                      ['tomorrow_morning', t.pickupTomorrow],
                      ['scheduled', t.pickupLater],
                      ['asap', t.pickupAsap],
                    ] as const
                  ).map(([val, label]) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setPickupType(val)}
                      className={`rounded-xl border px-3 py-2.5 text-xs font-semibold text-start transition-colors cursor-pointer ${
                        pickupType === val
                          ? 'border-blue-700 bg-blue-50 text-blue-900'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>

                {pickupType === 'scheduled' && (
                  <div className="pt-2">
                    <input
                      type="datetime-local"
                      required
                      value={pickupDatetime}
                      onChange={(e) => setPickupDatetime(e.target.value)}
                      className="rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm font-mono-nums"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {t.notesLabel}
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={t.notesPlaceholder}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm focus:border-blue-600 focus:bg-white focus:outline-none"
                />
              </div>

              {config.deliveryEnabled && (
                <div className="border-t border-slate-100 pt-4 space-y-4">
                  <label className="flex items-center gap-3 text-sm font-semibold text-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={deliveryRequested}
                      onChange={(e) => setDeliveryRequested(e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-blue-700"
                    />
                    <span>
                      {t.deliveryToggle} (+{config.deliveryBaseFee} {t.currency})
                    </span>
                  </label>

                  {deliveryRequested && (
                    <div className="space-y-4 pt-1">
                      <DeliveryLocationPicker
                        lang={lang}
                        apiKey={config.googleMapsApiKey}
                        officePos={{ lat: config.officeLat, lng: config.officeLng }}
                        selectedPos={deliveryPos}
                        onChange={(pos, addr) => {
                          setDeliveryPos(pos);
                          if (addr && !deliveryAddress) setDeliveryAddress(addr);
                        }}
                      />
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                          {t.deliveryAddressLabel}
                        </label>
                        <input
                          type="text"
                          value={deliveryAddress}
                          onChange={(e) => setDeliveryAddress(e.target.value)}
                          placeholder={t.deliveryAddressPlaceholder}
                          className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Mandatory Terms */}
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-2">
                <p className="text-xs text-slate-600 leading-relaxed">{t.termsSummary}</p>
                <label className="flex items-center gap-2.5 text-sm font-bold text-slate-900 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={termsAccepted}
                    onChange={(e) => setTermsAccepted(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-blue-700"
                  />
                  <span>
                    {lang === 'ar'
                      ? `أوافق على شروط الطلب والاستلام والتسديد في ${config.officeName}`
                      : lang === 'fr'
                        ? `J’accepte les conditions de commande, retrait et paiement de ${config.officeName}`
                        : `I agree to ${config.officeName} order, pickup, and payment terms`}{' '}
                    *
                  </span>
                </label>
              </div>
            </div>
          </div>

          {/* Right / Sticky Order Summary */}
          <aside className="lg:col-span-4 lg:sticky lg:top-6 rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
            <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
              {t.orderSummaryTitle}
            </h3>

            {selectedItemsList.length === 0 && activeCustomList.length === 0 ? (
              <p className="text-sm text-slate-500 py-4 text-center">
                {lang === 'fr'
                  ? 'Aucun service sélectionné pour le moment.'
                  : lang === 'en'
                    ? 'No services selected yet.'
                    : 'لم تختر أي خدمة بعد. اختر من الأقسام لإظهار التكلفة.'}
              </p>
            ) : (
              <div className="space-y-3 max-h-[320px] overflow-y-auto pe-1">
                {selectedItemsList.map(({ service, sel, subtotal }) => (
                  <div key={service.id} className="flex items-start justify-between gap-2 text-xs">
                    <div className="text-slate-700">
                      <span className="font-semibold">{getServiceName(service, lang)}</span>
                      <span className="text-slate-500 font-mono-nums"> × {sel.quantity}</span>
                    </div>
                    <span className="font-bold text-slate-900 font-mono-nums shrink-0">
                      {subtotal} {t.currency}
                    </span>
                  </div>
                ))}
                {activeCustomList.map((c, i) => (
                  <div key={i} className="flex items-start justify-between gap-2 text-xs text-blue-800">
                    <span>
                      {c.description} × {c.quantity}
                    </span>
                    <span className="font-semibold shrink-0">
                      {lang === 'ar' ? 'تسعير الإدارة' : 'Sur devis'}
                    </span>
                  </div>
                ))}
                {config.deliveryEnabled && deliveryRequested && (
                  <div className="flex items-center justify-between text-xs text-slate-700 pt-2 border-t border-slate-100">
                    <span>{lang === 'ar' ? 'رسوم التوصيل' : 'Delivery'}</span>
                    <span className="font-bold font-mono-nums">
                      {config.deliveryBaseFee} {t.currency}
                    </span>
                  </div>
                )}
              </div>
            )}

            {activeCustomList.length > 0 && (
              <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900">
                {t.customQuoteNotice}
              </div>
            )}

            <div className="border-t border-slate-200 pt-4 flex items-center justify-between">
              <span className="text-sm font-semibold text-slate-700">{t.totalFixed}</span>
              <span className="text-2xl font-extrabold text-blue-800 font-mono-nums">
                {estimatedTotal} {t.currency}
              </span>
            </div>

            {errorMsg && (
              <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs font-semibold text-rose-800">
                <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-xl bg-blue-700 py-3.5 px-4 text-sm font-bold text-white hover:bg-blue-800 disabled:opacity-60 transition-colors cursor-pointer"
            >
              {submitting ? t.submittingBtn : t.submitOrderBtn}
            </button>
          </aside>
        </form>
      )}
    </div>
  );
};
