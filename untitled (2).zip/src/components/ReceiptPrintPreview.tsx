import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Check,
  Download,
  Eye,
  FileCode2,
  FileSpreadsheet,
  Lock,
  Plus,
  Printer,
  Search,
  Trash2,
  Unlock,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import type { Order } from '../types';

type PaperSize = 'A4' | 'A3';
type SplitMode = 'multi_split' | 'single_only';
type SingleLayoutSize = 'compact' | 'full_ticket';
type SlotKey = string; // 'blank' | 'hidden' | `order:${number}` | `manual:${string}`

interface ManualCustomerReceipt {
  id: string;
  customer_name: string;
  customer_phone: string;
  tracking_code: string;
  service_description: string;
  quantity: number;
  total_price: number;
  delivery_requested: boolean;
  created_at: string;
}

interface NormalizedReceipt {
  key: string;
  tracking_code: string;
  created_at: string;
  customer_name: string;
  customer_phone: string;
  rows: { label: string; qty: string; price: string }[];
  delivery_requested: boolean;
  total_price: number;
}

interface ReceiptPrintPreviewProps {
  orders: Order[];
  officeName: string;
  officeLogo?: string;
  officeAddress: string;
  printLockEnabled: boolean;
  authToken?: string;
  preselectedOrderId?: number | null;
}

function escapeHtml(value: string): string {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function printHtmlDocument(html: string): void {
  const existing = document.getElementById('go-hidden-print-frame');
  if (existing) existing.remove();

  const iframe = document.createElement('iframe');
  iframe.id = 'go-hidden-print-frame';
  iframe.setAttribute('aria-hidden', 'true');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.style.opacity = '0';
  iframe.style.pointerEvents = 'none';

  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) {
    iframe.remove();
    window.print();
    return;
  }

  let printed = false;
  const triggerPrint = () => {
    if (printed) return;
    printed = true;
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } finally {
      setTimeout(() => {
        iframe.remove();
      }, 1500);
    }
  };

  iframe.onload = () => {
    setTimeout(triggerPrint, 120);
  };

  doc.open();
  doc.write(html);
  doc.close();

  setTimeout(triggerPrint, 450);
}

function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function loadImageSafe(src?: string): Promise<HTMLImageElement | null> {
  if (!src) return null;
  const resolved =
    src.startsWith('http') || src.startsWith('data:')
      ? src
      : `${window.location.origin}${src}`;
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = resolved;
  });
}

function truncateText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let out = text;
  while (out.length > 1 && ctx.measureText(`${out}...`).width > maxWidth) {
    out = out.slice(0, -1);
  }
  return `${out}...`;
}

function drawReceiptOnCanvas(
  ctx: CanvasRenderingContext2D,
  box: { x: number; y: number; w: number; h: number },
  receipt: NormalizedReceipt | null,
  meta: {
    officeName: string;
    officeAddress: string;
    logoImg: HTMLImageElement | null;
  }
) {
  const { x, y, w, h } = box;
  const pad = Math.round(w * 0.045);

  ctx.save();
  ctx.direction = 'rtl';

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = '#64748b';
  ctx.lineWidth = 2;
  ctx.setLineDash([8, 6]);
  ctx.strokeRect(x + 1, y + 1, w - 2, h - 2);
  ctx.setLineDash([]);

  const innerX = x + pad;
  const innerRight = x + w - pad;
  const innerW = w - pad * 2;
  let curY = y + pad;

  const logoSize = Math.min(44, Math.round(w * 0.08));
  let brandTextRight = innerRight;
  if (meta.logoImg) {
    try {
      ctx.drawImage(meta.logoImg, innerRight - logoSize, curY, logoSize, logoSize);
      brandTextRight = innerRight - logoSize - 10;
    } catch {
      // ignore logo error
    }
  }

  ctx.fillStyle = '#1e3a8a';
  ctx.font = `800 ${Math.max(15, Math.round(w * 0.032))}px Tahoma, Arial, sans-serif`;
  ctx.textAlign = 'right';
  ctx.fillText(
    truncateText(ctx, meta.officeName, innerW * 0.52),
    brandTextRight,
    curY + Math.round(logoSize * 0.45)
  );

  ctx.fillStyle = '#64748b';
  ctx.font = `400 ${Math.max(11, Math.round(w * 0.022))}px Tahoma, Arial, sans-serif`;
  ctx.fillText(
    truncateText(ctx, meta.officeAddress, innerW * 0.55),
    brandTextRight,
    curY + Math.round(logoSize * 0.92)
  );

  ctx.textAlign = 'left';
  ctx.fillStyle = '#0f172a';
  ctx.font = `700 ${Math.max(12, Math.round(w * 0.025))}px Tahoma, Arial, sans-serif`;
  ctx.fillText(
    receipt ? receipt.tracking_code : 'GO-____-_____',
    innerX,
    curY + Math.round(logoSize * 0.45)
  );
  ctx.fillStyle = '#64748b';
  ctx.font = `400 ${Math.max(11, Math.round(w * 0.021))}px Tahoma, Arial, sans-serif`;
  ctx.fillText(
    receipt ? new Date(receipt.created_at).toLocaleDateString('ar-DZ') : '____ / __ / __',
    innerX,
    curY + Math.round(logoSize * 0.92)
  );

  curY += logoSize + 12;
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(innerX, curY);
  ctx.lineTo(innerRight, curY);
  ctx.stroke();

  curY += 12;

  const custH = Math.max(36, Math.round(h * 0.085));
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(innerX, curY, innerW, custH);
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  ctx.strokeRect(innerX, curY, innerW, custH);

  ctx.fillStyle = '#0f172a';
  ctx.font = `700 ${Math.max(12, Math.round(w * 0.024))}px Tahoma, Arial, sans-serif`;
  ctx.textAlign = 'right';
  const custText = `العميل: ${receipt ? receipt.customer_name : '__________________'}`;
  ctx.fillText(
    truncateText(ctx, custText, innerW * 0.55),
    innerRight - 10,
    curY + Math.round(custH * 0.65)
  );
  ctx.textAlign = 'left';
  const phoneText = `الهاتف: ${receipt ? receipt.customer_phone : '______________'}`;
  ctx.fillText(phoneText, innerX + 10, curY + Math.round(custH * 0.65));

  curY += custH + 16;

  const rowFontSize = Math.max(11, Math.round(w * 0.022));
  ctx.fillStyle = '#475569';
  ctx.font = `700 ${rowFontSize}px Tahoma, Arial, sans-serif`;
  ctx.textAlign = 'right';
  ctx.fillText('الخدمة', innerRight, curY);
  ctx.textAlign = 'center';
  ctx.fillText('الكمية', innerX + Math.round(innerW * 0.34), curY);
  ctx.textAlign = 'left';
  ctx.fillText('المبلغ', innerX, curY);

  curY += 8;
  ctx.strokeStyle = '#cbd5e1';
  ctx.beginPath();
  ctx.moveTo(innerX, curY);
  ctx.lineTo(innerRight, curY);
  ctx.stroke();

  curY += 20;

  const footY = y + h - pad - 24;
  const lineH = Math.max(24, Math.round(h * 0.062));

  const rows = receipt
    ? receipt.rows
    : [0, 1, 2, 3].map(() => ({ label: '', qty: '', price: '' }));

  ctx.font = `500 ${rowFontSize}px Tahoma, Arial, sans-serif`;
  for (const row of rows) {
    if (curY + lineH > footY - 10) break;
    ctx.fillStyle = '#0f172a';
    ctx.textAlign = 'right';
    ctx.fillText(truncateText(ctx, row.label, innerW * 0.54), innerRight, curY);
    ctx.textAlign = 'center';
    ctx.fillText(row.qty, innerX + Math.round(innerW * 0.34), curY);
    ctx.textAlign = 'left';
    ctx.font = `700 ${rowFontSize}px Tahoma, Arial, sans-serif`;
    ctx.fillText(row.price, innerX, curY);
    ctx.font = `500 ${rowFontSize}px Tahoma, Arial, sans-serif`;

    ctx.strokeStyle = '#f1f5f9';
    ctx.beginPath();
    ctx.moveTo(innerX, curY + 8);
    ctx.lineTo(innerRight, curY + 8);
    ctx.stroke();

    curY += lineH;
  }

  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(innerX, footY - 12);
  ctx.lineTo(innerRight, footY - 12);
  ctx.stroke();

  ctx.font = `600 ${Math.max(12, Math.round(w * 0.023))}px Tahoma, Arial, sans-serif`;
  ctx.fillStyle = '#475569';
  ctx.textAlign = 'right';
  ctx.fillText(
    receipt?.delivery_requested ? 'توصيل + استلام' : 'استلام من المكتب',
    innerRight,
    footY + 10
  );

  ctx.font = `800 ${Math.max(14, Math.round(w * 0.028))}px Tahoma, Arial, sans-serif`;
  ctx.fillStyle = '#1e3a8a';
  ctx.textAlign = 'left';
  ctx.fillText(
    `المجموع: ${receipt ? `${receipt.total_price} د.ج` : '________ د.ج'}`,
    innerX,
    footY + 10
  );

  ctx.restore();
}

export const ReceiptPrintPreview: React.FC<ReceiptPrintPreviewProps> = ({
  orders,
  officeName,
  officeLogo = '',
  officeAddress,
  printLockEnabled,
  authToken = '',
  preselectedOrderId = null,
}) => {
  const [paperSize, setPaperSize] = useState<PaperSize>('A4');
  const [splitMode, setSplitMode] = useState<SplitMode>('multi_split');
  const [singleLayoutSize, setSingleLayoutSize] = useState<SingleLayoutSize>('compact');

  // Admin-curated customer selection pool & manual walk-in customers
  const [customerSearch, setCustomerSearch] = useState('');
  const [manualCustomers, setManualCustomers] = useState<ManualCustomerReceipt[]>([]);
  const [showManualForm, setShowManualForm] = useState(false);
  const [manualForm, setManualForm] = useState({
    customer_name: '',
    customer_phone: '',
    service_description: '',
    quantity: '1',
    total_price: '',
    delivery_requested: false,
  });

  // Ordered list of customer keys chosen by the admin to distribute onto receipts
  const [chosenQueue, setChosenQueue] = useState<string[]>([]);
  // Explicit per-slot assignments (start empty/blank so admin chooses who goes where)
  const [slotAssignments, setSlotAssignments] = useState<SlotKey[]>(
    Array.from({ length: 8 }, () => 'blank')
  );
  const [singleSlotKey, setSingleSlotKey] = useState<SlotKey>('blank');

  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const [unlocked, setUnlocked] = useState(!printLockEnabled);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);

  useEffect(() => {
    setUnlocked(!printLockEnabled);
  }, [printLockEnabled]);

  useEffect(() => {
    if (!preselectedOrderId) return;
    const key = `order:${preselectedOrderId}`;
    setChosenQueue((prev) => (prev.includes(key) ? prev : [key, ...prev]));
    setSlotAssignments((prev) => {
      if (prev.includes(key)) return prev;
      const next = [...prev];
      const blankIdx = next.indexOf('blank');
      next[blankIdx !== -1 ? blankIdx : 0] = key;
      return next;
    });
    setSingleSlotKey(key);
  }, [preselectedOrderId]);

  const maxSlots = paperSize === 'A4' ? 4 : 8;

  const receiptLookup = useMemo(() => {
    const map = new Map<string, NormalizedReceipt>();
    for (const o of orders) {
      const key = `order:${o.id}`;
      map.set(key, {
        key,
        tracking_code: o.tracking_code,
        created_at: o.created_at,
        customer_name: o.customer_name,
        customer_phone: o.customer_phone || '—',
        delivery_requested: Boolean(o.delivery_requested),
        total_price: o.total_price,
        rows: [
          ...o.items.slice(0, 5).map((it) => ({
            label: it.name_ar,
            qty: String(it.quantity),
            price: `${it.subtotal} د.ج`,
          })),
          ...o.custom_requests.slice(0, 2).map((cr) => ({
            label: cr.description,
            qty: String(cr.quantity),
            price: cr.quotedPrice ? `${cr.quotedPrice} د.ج` : 'حسب الاتفاق',
          })),
        ],
      });
    }
    for (const m of manualCustomers) {
      const key = `manual:${m.id}`;
      map.set(key, {
        key,
        tracking_code: m.tracking_code,
        created_at: m.created_at,
        customer_name: m.customer_name,
        customer_phone: m.customer_phone || '—',
        delivery_requested: m.delivery_requested,
        total_price: m.total_price,
        rows: [
          {
            label: m.service_description || 'خدمة مكتبية / طباعة',
            qty: String(m.quantity),
            price: `${m.total_price} د.ج`,
          },
        ],
      });
    }
    return map;
  }, [orders, manualCustomers]);

  const allSelectableCustomers = useMemo(() => {
    const list = [
      ...manualCustomers.map((m) => ({
        key: `manual:${m.id}`,
        name: m.customer_name,
        phone: m.customer_phone,
        code: m.tracking_code,
        total: m.total_price,
        isManual: true,
      })),
      ...orders.map((o) => ({
        key: `order:${o.id}`,
        name: o.customer_name,
        phone: o.customer_phone,
        code: o.tracking_code,
        total: o.total_price,
        isManual: false,
      })),
    ];
    if (!customerSearch.trim()) return list;
    const q = customerSearch.trim().toLowerCase();
    return list.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        c.code.toLowerCase().includes(q)
    );
  }, [orders, manualCustomers, customerSearch]);

  const activeSlots: { slotIndex: number; receipt: NormalizedReceipt | null; key: SlotKey }[] =
    useMemo(() => {
      if (splitMode === 'single_only') {
        return [
          {
            slotIndex: 0,
            key: singleSlotKey,
            receipt: receiptLookup.get(singleSlotKey) || null,
          },
        ];
      }

      const visible: { slotIndex: number; receipt: NormalizedReceipt | null; key: SlotKey }[] = [];
      for (let i = 0; i < maxSlots; i++) {
        const key = slotAssignments[i] ?? 'blank';
        if (key === 'hidden') continue;
        visible.push({
          slotIndex: i,
          key,
          receipt: receiptLookup.get(key) || null,
        });
      }
      return visible;
    }, [splitMode, singleSlotKey, maxSlots, slotAssignments, receiptLookup]);

  const notify = (msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(null), 3000);
  };

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (authToken) headers.Authorization = `Bearer ${authToken}`;

    const resp = await fetch('/api/admin/print-unlock', {
      method: 'POST',
      headers,
      credentials: 'include',
      body: JSON.stringify({ pin: pinInput }),
    });
    if (resp.ok) {
      setUnlocked(true);
      setPinInput('');
    } else {
      const d = await resp.json();
      setPinError(d.error || 'رمز القفل غير صحيح.');
    }
  };

  const toggleChosenCustomer = (key: string) => {
    setChosenQueue((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const moveChosenCustomer = (index: number, delta: -1 | 1) => {
    setChosenQueue((prev) => {
      const target = index + delta;
      if (target < 0 || target >= prev.length) return prev;
      const next = [...prev];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  };

  const handleAddManualCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualForm.customer_name.trim()) return;
    const id = String(Date.now());
    const code = `M-${String(manualCustomers.length + 1).padStart(3, '0')}`;
    const entry: ManualCustomerReceipt = {
      id,
      customer_name: manualForm.customer_name.trim(),
      customer_phone: manualForm.customer_phone.trim() || '—',
      tracking_code: code,
      service_description: manualForm.service_description.trim() || 'خدمة مكتبية / طباعة',
      quantity: Math.max(1, Number(manualForm.quantity) || 1),
      total_price: Math.max(0, Number(manualForm.total_price) || 0),
      delivery_requested: manualForm.delivery_requested,
      created_at: new Date().toISOString(),
    };
    const key = `manual:${id}`;
    setManualCustomers((prev) => [entry, ...prev]);
    setChosenQueue((prev) => [...prev, key]);
    if (singleSlotKey === 'blank') setSingleSlotKey(key);
    setManualForm({
      customer_name: '',
      customer_phone: '',
      service_description: '',
      quantity: '1',
      total_price: '',
      delivery_requested: false,
    });
    setShowManualForm(false);
    notify(`تمت إضافة العميل «${entry.customer_name}» إلى قائمة الاختيار.`);
  };

  // Distribution actions controlled by admin
  const distributeChosenToSheet = (hideUnusedSlots: boolean) => {
    if (chosenQueue.length === 0) {
      notify('اختر عميلاً واحداً على الأقل من القائمة أولاً لتوزيعه على الورقة.');
      return;
    }
    setSlotAssignments((prev) => {
      const next = [...prev];
      for (let i = 0; i < 8; i++) {
        if (i < maxSlots) {
          if (chosenQueue[i]) {
            next[i] = chosenQueue[i];
          } else {
            next[i] = hideUnusedSlots ? 'hidden' : 'blank';
          }
        } else {
          next[i] = prev[i] ?? 'blank';
        }
      }
      return next;
    });
    if (chosenQueue[0]) setSingleSlotKey(chosenQueue[0]);
    notify(
      hideUnusedSlots
        ? `تم توزيع ${Math.min(chosenQueue.length, maxSlots)} عميل وإخفاء الخانات الفارغة.`
        : `تم توزيع ${Math.min(chosenQueue.length, maxSlots)} عميل على ورقة ${paperSize}.`
    );
  };

  const repeatFirstChosenAcrossSheet = () => {
    const firstKey = chosenQueue[0] || slotAssignments.find((k) => k !== 'blank' && k !== 'hidden');
    if (!firstKey) {
      notify('اختر عميلاً أولاً لتكرار وصله على الورقة.');
      return;
    }
    setSlotAssignments(Array.from({ length: 8 }, () => firstKey));
    notify('تم تكرار وصل العميل المحدد في جميع الخانات.');
  };

  const clearAllSlots = () => {
    setSlotAssignments(Array.from({ length: 8 }, () => 'blank'));
    notify('تم تفريغ جميع خانات الورقة.');
  };

  const assignNextFreeSlot = (key: string) => {
    setChosenQueue((prev) => (prev.includes(key) ? prev : [...prev, key]));
    setSlotAssignments((prev) => {
      const next = [...prev];
      const idx = next.slice(0, maxSlots).findIndex((v) => v === 'blank' || v === 'hidden');
      if (idx !== -1) {
        next[idx] = key;
        notify(`تمت إضافة العميل إلى الخانة #${idx + 1} على الورقة.`);
      } else {
        notify(`جميع خانات ${paperSize} (${maxSlots}) ممتلئة — يمكنك تبديل أي خانة من الأسفل.`);
      }
      return next;
    });
  };

  const swapSlots = (idxA: number, idxB: number) => {
    if (idxA < 0 || idxB < 0 || idxA >= maxSlots || idxB >= maxSlots) return;
    setSlotAssignments((prev) => {
      const next = [...prev];
      [next[idxA], next[idxB]] = [next[idxB], next[idxA]];
      return next;
    });
  };

  const getCellDimensionsCss = () => {
    if (splitMode === 'single_only') {
      if (singleLayoutSize === 'compact') {
        return {
          width: paperSize === 'A4' ? '96mm' : '138mm',
          height: paperSize === 'A4' ? '136mm' : '96mm',
        };
      }
      return {
        width: '100%',
        height: paperSize === 'A4' ? '145mm' : '190mm',
      };
    }
    return {
      width: '100%',
      height: paperSize === 'A4' ? '136mm' : '95mm',
    };
  };

  const buildSheetHtml = () => {
    const resolvedLogo = officeLogo
      ? officeLogo.startsWith('http') || officeLogo.startsWith('data:')
        ? officeLogo
        : `${window.location.origin}${officeLogo}`
      : '';

    const isSingleMode = splitMode === 'single_only';
    const isCompactSingle = isSingleMode && singleLayoutSize === 'compact';

    const cellHeight = isSingleMode
      ? isCompactSingle
        ? paperSize === 'A4'
          ? '136mm'
          : '96mm'
        : paperSize === 'A4'
          ? '145mm'
          : '190mm'
      : paperSize === 'A4'
        ? '136mm'
        : '95mm';

    const cellWidthStyle = isCompactSingle
      ? `width:${paperSize === 'A4' ? '96mm' : '138mm'};`
      : '';

    const gridCols = isSingleMode ? '1fr' : '1fr 1fr';

    const cellsHtml = activeSlots
      .map(({ receipt }) => {
        const itemsRows = receipt
          ? receipt.rows
              .map(
                (r) => `
                  <tr>
                    <td>${escapeHtml(r.label)}</td>
                    <td style="text-align:center;">${escapeHtml(r.qty)}</td>
                    <td style="text-align:left; font-weight:600;">${escapeHtml(r.price)}</td>
                  </tr>`
              )
              .join('')
          : [0, 1, 2, 3]
              .map(
                () => `
                  <tr>
                    <td style="padding:7px 0;">&nbsp;</td>
                    <td style="padding:7px 0;">&nbsp;</td>
                    <td style="padding:7px 0;">&nbsp;</td>
                  </tr>`
              )
              .join('');

        return `
          <div class="receipt-cell" style="height:${cellHeight}; ${cellWidthStyle}">
            <div>
              <div class="receipt-head">
                <div class="brand-wrap">
                  ${
                    resolvedLogo
                      ? `<img src="${escapeHtml(resolvedLogo)}" alt="logo" class="brand-logo" />`
                      : ''
                  }
                  <div>
                    <div class="brand-name">${escapeHtml(officeName)}</div>
                    <div class="brand-addr">${escapeHtml(officeAddress)}</div>
                  </div>
                </div>
                <div class="code-box">
                  <div class="code-val">${receipt ? escapeHtml(receipt.tracking_code) : 'GO-____-_____'}</div>
                  <div class="date-val">${
                    receipt ? new Date(receipt.created_at).toLocaleDateString('ar-DZ') : '____ / __ / __'
                  }</div>
                </div>
              </div>

              <div class="cust-box">
                <div><span>العميل: </span><strong>${receipt ? escapeHtml(receipt.customer_name) : '__________________'}</strong></div>
                <div style="text-align:left;"><span>الهاتف: </span><strong>${receipt ? escapeHtml(receipt.customer_phone) : '______________'}</strong></div>
              </div>

              <table class="items-table">
                <thead>
                  <tr>
                    <th style="text-align:right;">الخدمة</th>
                    <th style="text-align:center;">الكمية</th>
                    <th style="text-align:left;">المبلغ</th>
                  </tr>
                </thead>
                <tbody>
                  ${itemsRows}
                </tbody>
              </table>
            </div>

            <div class="receipt-foot">
              <span>${receipt?.delivery_requested ? 'توصيل + استلام' : 'استلام من المكتب'}</span>
              <div class="total-val">المجموع: ${receipt ? `${receipt.total_price} د.ج` : '________ د.ج'}</div>
            </div>
          </div>
        `;
      })
      .join('');

    return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <title>طباعة الوصولات — ${escapeHtml(officeName)}</title>
  <style>
    @page {
      size: ${paperSize} portrait;
      margin: 5mm;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 0;
      font-family: Tahoma, Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .sheet-grid {
      display: grid;
      grid-template-columns: ${gridCols};
      gap: 3mm;
      width: 100%;
    }
    .receipt-cell {
      border: 1px dashed #64748b;
      padding: 3.5mm;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      overflow: hidden;
      page-break-inside: avoid;
      background: #ffffff;
    }
    .receipt-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #cbd5e1;
      padding-bottom: 4px;
      margin-bottom: 6px;
    }
    .brand-wrap {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .brand-logo {
      width: 24px;
      height: 24px;
      object-fit: contain;
    }
    .brand-name {
      font-size: 12px;
      font-weight: 800;
      color: #1e3a8a;
    }
    .brand-addr {
      font-size: 9px;
      color: #64748b;
      max-width: 145px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .code-box { text-align: left; }
    .code-val { font-size: 10px; font-weight: 700; }
    .date-val { font-size: 9px; color: #64748b; }
    .cust-box {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 4px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 4px;
      padding: 4px 6px;
      font-size: 9.5px;
      margin-bottom: 6px;
    }
    .items-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 9px;
    }
    .items-table th {
      border-bottom: 1px solid #cbd5e1;
      padding: 3px 0;
      color: #475569;
    }
    .items-table td {
      border-bottom: 1px solid #f1f5f9;
      padding: 3px 0;
    }
    .receipt-foot {
      border-top: 1px solid #cbd5e1;
      padding-top: 5px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
    }
    .total-val {
      font-weight: 800;
      color: #1e3a8a;
    }
  </style>
</head>
<body>
  <div class="sheet-grid">
    ${cellsHtml}
  </div>
</body>
</html>`;
  };

  const handlePrintSheet = () => {
    if (activeSlots.length === 0) return;
    printHtmlDocument(buildSheetHtml());
  };

  const handleDownloadSheetHtml = () => {
    if (activeSlots.length === 0) return;
    const html = buildSheetHtml();
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    triggerBlobDownload(
      blob,
      `graphicore-${splitMode === 'single_only' ? 'single-receipt' : `sheet-${paperSize}`}-${new Date()
        .toISOString()
        .slice(0, 10)}.html`
    );
    notify('تم تنزيل ملف الطباعة (HTML) بنجاح.');
  };

  const handleDownloadSheetPng = async () => {
    if (activeSlots.length === 0) return;
    const logoImg = await loadImageSafe(officeLogo);
    const canvas = document.createElement('canvas');
    const pad = 32;
    const gap = 22;

    if (splitMode === 'single_only') {
      const w = singleLayoutSize === 'compact' ? 760 : 1240;
      const h = singleLayoutSize === 'compact' ? 920 : 880;
      canvas.width = w + pad * 2;
      canvas.height = h + pad * 2;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      drawReceiptOnCanvas(
        ctx,
        { x: pad, y: pad, w, h },
        activeSlots[0]?.receipt || null,
        { officeName, officeAddress, logoImg }
      );
      canvas.toBlob((blob) => {
        if (blob) {
          const code = activeSlots[0]?.receipt?.tracking_code || 'blank';
          triggerBlobDownload(blob, `receipt-${code}-${paperSize}.png`);
        }
      }, 'image/png');
      notify('تم تنزيل الوصل المنفرد (PNG) بنجاح.');
      return;
    }

    const sheetW = paperSize === 'A4' ? 1480 : 2100;
    const sheetH = paperSize === 'A4' ? 2090 : 2970;
    const cols = 2;
    const rows = paperSize === 'A4' ? 2 : 4;
    const cellW = Math.floor((sheetW - pad * 2 - gap * (cols - 1)) / cols);
    const cellH = Math.floor((sheetH - pad * 2 - gap * (rows - 1)) / rows);

    canvas.width = sheetW;
    canvas.height = sheetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, sheetW, sheetH);

    activeSlots.forEach((slot, idx) => {
      const r = Math.floor(idx / cols);
      const c = idx % cols;
      const rtlCol = cols - 1 - c;
      const x = pad + rtlCol * (cellW + gap);
      const y = pad + r * (cellH + gap);
      drawReceiptOnCanvas(ctx, { x, y, w: cellW, h: cellH }, slot.receipt, {
        officeName,
        officeAddress,
        logoImg,
      });
    });

    canvas.toBlob((blob) => {
      if (blob) {
        triggerBlobDownload(
          blob,
          `graphicore-sheet-${paperSize}-${new Date().toISOString().slice(0, 10)}.png`
        );
      }
    }, 'image/png');
    notify(`تم تنزيل ورقة ${paperSize} (${activeSlots.length} وصولات) كصورة PNG.`);
  };

  const handleDownloadSingleReceiptPng = async (
    receipt: NormalizedReceipt | null,
    slotIndex?: number
  ) => {
    const logoImg = await loadImageSafe(officeLogo);
    const canvas = document.createElement('canvas');
    const pad = 28;
    const w = 780;
    const h = 940;
    canvas.width = w + pad * 2;
    canvas.height = h + pad * 2;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    drawReceiptOnCanvas(ctx, { x: pad, y: pad, w, h }, receipt, {
      officeName,
      officeAddress,
      logoImg,
    });

    canvas.toBlob((blob) => {
      if (blob) {
        const suffix = receipt ? receipt.tracking_code : `blank-slot-${(slotIndex ?? 0) + 1}`;
        triggerBlobDownload(blob, `receipt-${suffix}.png`);
      }
    }, 'image/png');
    notify(`تم تنزيل الوصل ${receipt ? receipt.tracking_code : 'الفارغ'} (PNG).`);
  };

  const renderReceiptCell = (
    slot: { slotIndex: number; receipt: NormalizedReceipt | null; key: SlotKey },
    idx: number,
    allowSlotControls: boolean
  ) => {
    const { receipt, slotIndex } = slot;
    const dims = getCellDimensionsCss();

    return (
      <div
        key={`${slotIndex}-${idx}`}
        className="relative group border border-dashed border-slate-400 bg-white p-3 flex flex-col justify-between text-[10px] leading-snug text-slate-900 overflow-hidden"
        style={{
          height: dims.height,
          width: splitMode === 'single_only' ? dims.width : undefined,
        }}
      >
        {allowSlotControls && (
          <div className="no-print absolute top-1.5 left-1.5 z-10 flex items-center gap-1 opacity-90 group-hover:opacity-100">
            <button
              type="button"
              onClick={() => handleDownloadSingleReceiptPng(receipt, slotIndex)}
              title="تنزيل هذا الوصل منفرداً (PNG)"
              className="inline-flex items-center gap-1 rounded-md border border-blue-200 bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-800 hover:bg-blue-100 cursor-pointer"
            >
              <Download className="h-3 w-3" />
              <span>تنزيل الوصل</span>
            </button>
          </div>
        )}

        <div className="space-y-2">
          <div className="flex items-center justify-between border-b border-slate-300 pb-1.5 gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {officeLogo && (
                <img src={officeLogo} alt={officeName} className="h-6 w-6 object-contain shrink-0" />
              )}
              <div className="min-w-0">
                <div className="font-extrabold text-xs text-blue-900 truncate">{officeName}</div>
                <div className="text-[9px] text-slate-500 truncate max-w-[140px]">{officeAddress}</div>
              </div>
            </div>
            <div className="text-end font-mono-nums shrink-0">
              <div className="font-bold text-[10px]">
                {receipt ? receipt.tracking_code : 'GO-____-_____'}
              </div>
              <div className="text-[9px] text-slate-500">
                {receipt
                  ? new Date(receipt.created_at).toLocaleDateString('ar-DZ')
                  : '____ / __ / __'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1 text-[9.5px] bg-slate-50 rounded p-1.5 border border-slate-200">
            <div>
              <span className="text-slate-500">العميل: </span>
              <span className="font-bold">{receipt ? receipt.customer_name : '__________________'}</span>
            </div>
            <div className="text-end font-mono-nums">
              <span className="text-slate-500">الهاتف: </span>
              <span className="font-bold">{receipt ? receipt.customer_phone : '______________'}</span>
            </div>
          </div>

          <table className="w-full text-[9px] border-collapse">
            <thead>
              <tr className="border-b border-slate-300 text-slate-600">
                <th className="py-1 text-start">الخدمة</th>
                <th className="py-1 text-center">الكمية</th>
                <th className="py-1 text-end">المبلغ</th>
              </tr>
            </thead>
            <tbody>
              {receipt ? (
                receipt.rows.map((r, i) => (
                  <tr key={i} className="border-b border-slate-100">
                    <td className="py-1 truncate max-w-[120px]">{r.label}</td>
                    <td className="py-1 text-center font-mono-nums">{r.qty}</td>
                    <td className="py-1 text-end font-mono-nums">{r.price}</td>
                  </tr>
                ))
              ) : (
                [0, 1, 2, 3].map((row) => (
                  <tr key={row} className="border-b border-slate-200">
                    <td className="py-2">&nbsp;</td>
                    <td className="py-2 text-center">&nbsp;</td>
                    <td className="py-2 text-end">&nbsp;</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="pt-1.5 border-t border-slate-300 flex items-center justify-between text-[10px]">
          <span className="text-slate-600">
            {receipt?.delivery_requested ? 'توصيل + استلام' : 'استلام من المكتب'}
          </span>
          <div className="font-extrabold text-blue-900 font-mono-nums">
            المجموع: {receipt ? `${receipt.total_price} د.ج` : '________ د.ج'}
          </div>
        </div>
      </div>
    );
  };

  if (!unlocked) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-8 max-w-md mx-auto text-center space-y-5">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-amber-50 text-amber-700">
          <Lock className="h-6 w-6" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-slate-900">الطباعة مقفلة بصلاحية الإدارة</h3>
          <p className="mt-1 text-xs text-slate-600">
            أدخل رمز قفل الطباعة أو كلمة مرور الإدارة لفتح المعاينة والطباعة.
          </p>
        </div>
        <form onSubmit={handleUnlock} className="space-y-3">
          <input
            type="password"
            required
            value={pinInput}
            onChange={(e) => setPinInput(e.target.value)}
            placeholder="رمز فك القفل"
            className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-center"
          />
          {pinError && <p className="text-xs font-semibold text-rose-700">{pinError}</p>}
          <button
            type="submit"
            className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-blue-700 py-2.5 text-sm font-bold text-white hover:bg-blue-800 cursor-pointer"
          >
            <Unlock className="h-4 w-4" />
            <span>فتح نظام الطباعة</span>
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Controls Bar */}
      <div className="no-print rounded-2xl border border-slate-200 bg-white p-5 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <FileSpreadsheet className="h-5 w-5 text-blue-700" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                نظام طباعة وتنزيل الوصولات (للإدارة فقط)
              </h3>
              <p className="text-xs text-slate-500">
                اختر العملاء الذين تريد إضافتهم للوصل بنفسك، ثم وزّعهم على خانات ورقة A4 أو A3 كما تشاء
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadSheetPng}
              className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-xs font-bold text-emerald-800 hover:bg-emerald-100 cursor-pointer"
            >
              <Download className="h-4 w-4" />
              <span>تنزيل الورقة (PNG)</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadSheetHtml}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <FileCode2 className="h-4 w-4" />
              <span>تنزيل للطباعة (HTML)</span>
            </button>
            <button
              type="button"
              onClick={() => setPreviewModalOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-xl border border-blue-200 bg-blue-50 px-3.5 py-2.5 text-xs font-bold text-blue-800 hover:bg-blue-100 cursor-pointer"
            >
              <Eye className="h-4 w-4" />
              <span>معاينة قبل الطباعة</span>
            </button>
            <button
              type="button"
              onClick={handlePrintSheet}
              className="inline-flex items-center gap-2 rounded-xl bg-blue-700 px-4 py-2.5 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
            >
              <Printer className="h-4 w-4" />
              <span>طباعة الآن ({paperSize})</span>
            </button>
          </div>
        </div>

        {statusMsg && (
          <div className="rounded-xl border border-blue-200 bg-blue-50 px-3.5 py-2 text-xs font-bold text-blue-900">
            {statusMsg}
          </div>
        )}

        {/* Paper size & Split Mode Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-100">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">حجم الورق</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPaperSize('A4')}
                className={`flex-1 rounded-lg py-2 text-xs font-bold cursor-pointer ${
                  paperSize === 'A4'
                    ? 'bg-blue-700 text-white'
                    : 'border border-slate-200 bg-slate-50 text-slate-700'
                }`}
              >
                ورق A4 (حتى 4 عملاء)
              </button>
              <button
                type="button"
                onClick={() => setPaperSize('A3')}
                className={`flex-1 rounded-lg py-2 text-xs font-bold cursor-pointer ${
                  paperSize === 'A3'
                    ? 'bg-blue-700 text-white'
                    : 'border border-slate-200 bg-slate-50 text-slate-700'
                }`}
              >
                ورق A3 (حتى 8 عملاء)
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">نظام التقسيم والورقة</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setSplitMode('multi_split')}
                className={`flex-1 rounded-lg py-2 px-3 text-xs font-bold cursor-pointer ${
                  splitMode === 'multi_split'
                    ? 'bg-blue-700 text-white'
                    : 'border border-slate-200 bg-slate-50 text-slate-700'
                }`}
              >
                تقسيم الورقة (اختيار وتوزيع العملاء)
              </button>
              <button
                type="button"
                onClick={() => setSplitMode('single_only')}
                className={`flex-1 rounded-lg py-2 px-3 text-xs font-bold cursor-pointer ${
                  splitMode === 'single_only'
                    ? 'bg-blue-700 text-white'
                    : 'border border-slate-200 bg-slate-50 text-slate-700'
                }`}
              >
                وصل واحد فقط في الورقة (دون الباقي)
              </button>
            </div>
          </div>
        </div>

        {/* Admin Customer Selector & Manual Walk-in Customer Creator */}
        <div className="pt-3 border-t border-slate-100 grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Pick from customers + add walk-in customer */}
          <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-slate-50/70 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                <Users className="h-4 w-4 text-blue-700" />
                <span>1. اختر العملاء لإضافتهم للوصل:</span>
              </div>
              <button
                type="button"
                onClick={() => setShowManualForm((v) => !v)}
                className="inline-flex items-center gap-1 rounded-lg border border-blue-200 bg-white px-2.5 py-1.5 text-[11px] font-bold text-blue-800 hover:bg-blue-50 cursor-pointer"
              >
                <UserPlus className="h-3.5 w-3.5" />
                <span>{showManualForm ? 'إخفاء نموذج العميل اليدوي' : '+ إضافة عميل يدوياً (حضوري)'}</span>
              </button>
            </div>

            {showManualForm && (
              <form
                onSubmit={handleAddManualCustomer}
                className="rounded-xl border border-blue-200 bg-white p-3 space-y-2.5"
              >
                <div className="text-[11px] font-bold text-blue-900">
                  إضافة بيانات عميل جديد للوصل مباشرة:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="اسم العميل *"
                    value={manualForm.customer_name}
                    onChange={(e) =>
                      setManualForm({ ...manualForm, customer_name: e.target.value })
                    }
                    className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs"
                  />
                  <input
                    type="text"
                    placeholder="رقم الهاتف"
                    value={manualForm.customer_phone}
                    onChange={(e) =>
                      setManualForm({ ...manualForm, customer_phone: e.target.value })
                    }
                    className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-mono-nums"
                  />
                  <input
                    type="text"
                    placeholder="الخدمة (مثال: طباعة A4 ألوان، سيرة ذاتية...)"
                    value={manualForm.service_description}
                    onChange={(e) =>
                      setManualForm({ ...manualForm, service_description: e.target.value })
                    }
                    className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs"
                  />
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min={1}
                      placeholder="الكمية"
                      value={manualForm.quantity}
                      onChange={(e) =>
                        setManualForm({ ...manualForm, quantity: e.target.value })
                      }
                      className="w-20 rounded-lg border border-slate-200 bg-slate-50 px-2 py-1.5 text-xs font-mono-nums"
                    />
                    <input
                      type="number"
                      min={0}
                      placeholder="المبلغ د.ج *"
                      required
                      value={manualForm.total_price}
                      onChange={(e) =>
                        setManualForm({ ...manualForm, total_price: e.target.value })
                      }
                      className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-mono-nums"
                    />
                  </div>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <label className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={manualForm.delivery_requested}
                      onChange={(e) =>
                        setManualForm({ ...manualForm, delivery_requested: e.target.checked })
                      }
                      className="h-3.5 w-3.5 rounded text-blue-700"
                    />
                    <span>توصيل للعميل</span>
                  </label>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-1 rounded-lg bg-blue-700 px-3 py-1.5 text-[11px] font-bold text-white hover:bg-blue-800 cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>إضافة العميل لقائمتي</span>
                  </button>
                </div>
              </form>
            )}

            <div className="relative">
              <Search className="h-3.5 w-3.5 text-slate-400 absolute top-2.5 right-3" />
              <input
                type="text"
                value={customerSearch}
                onChange={(e) => setCustomerSearch(e.target.value)}
                placeholder="ابحث بالاسم، رقم الهاتف، أو رمز الطلب..."
                className="w-full rounded-lg border border-slate-200 bg-white pe-8 ps-3 py-1.5 text-xs"
              />
            </div>

            {allSelectableCustomers.length === 0 ? (
              <p className="text-xs text-slate-500 py-3 text-center">
                لا يوجد عملاء مطابقون — يمكنك إضافة عميل يدوياً بالزر أعلاه أو طباعة وصل فارغ.
              </p>
            ) : (
              <div className="space-y-1.5 max-h-48 overflow-y-auto pe-1">
                {allSelectableCustomers.map((c) => {
                  const isChosen = chosenQueue.includes(c.key);
                  return (
                    <div
                      key={c.key}
                      className={`flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-xs ${
                        isChosen
                          ? 'border-blue-600 bg-blue-50/70'
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <label className="flex items-center gap-2.5 flex-1 min-w-0 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isChosen}
                          onChange={() => toggleChosenCustomer(c.key)}
                          className="h-4 w-4 rounded text-blue-700 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 truncate">
                            {c.name}{' '}
                            <span className="font-normal text-slate-500 font-mono-nums">
                              ({c.phone})
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 font-mono-nums">
                            {c.code} · {c.total} د.ج {c.isManual ? '· عميل مضاف يدوياً' : ''}
                          </div>
                        </div>
                      </label>

                      <div className="flex items-center gap-1 shrink-0">
                        {splitMode === 'multi_split' ? (
                          <button
                            type="button"
                            onClick={() => assignNextFreeSlot(c.key)}
                            className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[10px] font-bold text-slate-700 hover:bg-blue-700 hover:text-white cursor-pointer"
                          >
                            + وضع بالخانة التالية
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setSingleSlotKey(c.key);
                              notify(`تم تحديد «${c.name}» للوصل الوحيد.`);
                            }}
                            className="rounded-md border border-blue-200 bg-blue-50 px-2 py-1 text-[10px] font-bold text-blue-800 hover:bg-blue-700 hover:text-white cursor-pointer"
                          >
                            تعيين للوصل
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right: Admin's chosen customers queue & distribution controls */}
          <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-slate-50/70 p-4 flex flex-col justify-between space-y-3">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-900">
                  2. العملاء المختارون للطباعة ({chosenQueue.length}):
                </span>
                {chosenQueue.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setChosenQueue([])}
                    className="text-[11px] font-semibold text-rose-600 hover:underline cursor-pointer"
                  >
                    مسح الاختيار
                  </button>
                )}
              </div>

              {chosenQueue.length === 0 ? (
                <div className="rounded-lg border border-dashed border-slate-300 bg-white p-4 text-center text-[11px] text-slate-500">
                  لم تختر أي عميل بعد — حدد العملاء من القائمة المجاورة لترتيبهم وتوزيعهم على الورقة.
                </div>
              ) : (
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {chosenQueue.map((key, idx) => {
                    const rec = receiptLookup.get(key);
                    if (!rec) return null;
                    return (
                      <div
                        key={key}
                        className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs"
                      >
                        <div className="min-w-0 flex items-center gap-2">
                          <span className="font-mono-nums font-bold text-blue-800">
                            #{idx + 1}
                          </span>
                          <span className="font-semibold text-slate-900 truncate">
                            {rec.customer_name}
                          </span>
                          <span className="text-[10px] font-mono-nums text-slate-500 shrink-0">
                            {rec.total_price} د.ج
                          </span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => moveChosenCustomer(idx, -1)}
                            title="تقديم للأعلى"
                            className="rounded p-1 text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowUp className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={idx === chosenQueue.length - 1}
                            onClick={() => moveChosenCustomer(idx, 1)}
                            title="تأخير للأسفل"
                            className="rounded p-1 text-slate-500 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowDown className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => toggleChosenCustomer(key)}
                            title="إزالة من الاختيار"
                            className="rounded p-1 text-rose-600 hover:bg-rose-50 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {splitMode === 'multi_split' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => distributeChosenToSheet(false)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-blue-700 px-3 py-2 text-[11px] font-bold text-white hover:bg-blue-800 cursor-pointer"
                >
                  <Check className="h-3.5 w-3.5" />
                  <span>توزيع المختارين على الورقة</span>
                </button>
                <button
                  type="button"
                  onClick={() => distributeChosenToSheet(true)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-[11px] font-bold text-blue-900 hover:bg-blue-100 cursor-pointer"
                >
                  <span>توزيع مع إخفاء الخانات الزائدة</span>
                </button>
                <button
                  type="button"
                  onClick={repeatFirstChosenAcrossSheet}
                  className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  تكرار العميل الأول في كل الخانات
                </button>
                <button
                  type="button"
                  onClick={clearAllSlots}
                  className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-semibold text-rose-700 hover:bg-rose-50 cursor-pointer"
                >
                  تفريغ الورقة بالكامل
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Manual Per-Slot Placement & Swap Panel */}
        {splitMode === 'multi_split' ? (
          <div className="pt-3 border-t border-slate-100 space-y-3">
            <div className="text-xs font-bold text-slate-800">
              3. التوزيع اليدوي لخانات ورقة {paperSize} ({maxSlots} خانات — غيّر العميل أو بدّل موضع أي خانة):
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {Array.from({ length: maxSlots }, (_, idx) => {
                const key = slotAssignments[idx] ?? 'blank';
                const slotReceipt = receiptLookup.get(key) || null;
                return (
                  <div
                    key={idx}
                    className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2 text-[11px] font-bold text-slate-700">
                      <span className="font-mono-nums text-blue-900">
                        الخانة #{idx + 1} (عمود {idx % 2 === 0 ? 'يمين' : 'يسار'})
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => swapSlots(idx, idx - 1)}
                          title="تبديل مع الخانة السابقة"
                          className="rounded border border-slate-200 bg-white p-1 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                        >
                          <ArrowRight className="h-3 w-3" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === maxSlots - 1}
                          onClick={() => swapSlots(idx, idx + 1)}
                          title="تبديل مع الخانة التالية"
                          className="rounded border border-slate-200 bg-white p-1 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                        >
                          <ArrowLeft className="h-3 w-3" />
                        </button>
                        {key !== 'hidden' && (
                          <button
                            type="button"
                            onClick={() => handleDownloadSingleReceiptPng(slotReceipt, idx)}
                            className="text-blue-700 hover:underline font-semibold cursor-pointer"
                          >
                            تنزيل الوصل
                          </button>
                        )}
                      </div>
                    </div>
                    <select
                      value={key}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSlotAssignments((prev) => {
                          const next = [...prev];
                          next[idx] = val;
                          return next;
                        });
                      }}
                      className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs"
                    >
                      <option value="blank">وصل فارغ (للكتابة اليدوية)</option>
                      <option value="hidden">إخفاء هذه الخانة من الورقة</option>
                      {manualCustomers.map((m) => (
                        <option key={`manual:${m.id}`} value={`manual:${m.id}`}>
                          [يدوي] {m.customer_name} ({m.total_price} د.ج)
                        </option>
                      ))}
                      {orders.slice(0, 80).map((o) => (
                        <option key={`order:${o.id}`} value={`order:${o.id}`}>
                          {o.tracking_code} · {o.customer_name} ({o.total_price} د.ج)
                        </option>
                      ))}
                    </select>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="pt-3 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                اختر العميل للوصل الوحيد (سيطبع بدون الـ {maxSlots - 1} خانات الأخرى):
              </label>
              <select
                value={singleSlotKey}
                onChange={(e) => setSingleSlotKey(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold"
              >
                <option value="blank">وصل واحد فارغ (للكتابة اليدوية)</option>
                {manualCustomers.map((m) => (
                  <option key={`manual:${m.id}`} value={`manual:${m.id}`}>
                    [يدوي] {m.customer_name} ({m.total_price} د.ج)
                  </option>
                ))}
                {orders.slice(0, 80).map((o) => (
                  <option key={`order:${o.id}`} value={`order:${o.id}`}>
                    {o.tracking_code} · {o.customer_name} ({o.total_price} د.ج)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                حجم الوصل الواحد داخل ورقة {paperSize}:
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSingleLayoutSize('compact')}
                  className={`flex-1 rounded-lg py-2 px-2 text-xs font-bold cursor-pointer ${
                    singleLayoutSize === 'compact'
                      ? 'bg-blue-700 text-white'
                      : 'border border-slate-200 bg-slate-50 text-slate-700'
                  }`}
                >
                  مقاس وصل قياسي ({paperSize === 'A4' ? 'ربع A4' : 'ثمن A3'})
                </button>
                <button
                  type="button"
                  onClick={() => setSingleLayoutSize('full_ticket')}
                  className={`flex-1 rounded-lg py-2 px-2 text-xs font-bold cursor-pointer ${
                    singleLayoutSize === 'full_ticket'
                      ? 'bg-blue-700 text-white'
                      : 'border border-slate-200 bg-slate-50 text-slate-700'
                  }`}
                >
                  تذكرة كاملة بعرض الورقة
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Live Inline Sheet Preview */}
      <div className="overflow-x-auto pb-4">
        <div
          className="mx-auto bg-white border border-slate-300 shadow-sm p-[4mm]"
          style={{
            width: paperSize === 'A4' ? '202mm' : '288mm',
            minHeight: paperSize === 'A4' ? '285mm' : '405mm',
          }}
        >
          {activeSlots.length === 0 ? (
            <div className="p-12 text-center text-xs text-slate-500">
              جميع الخانات مخفية حالياً — أظهر خانة واحدة على الأقل أو وزّع عملاءك المختارين بالأعلى.
            </div>
          ) : (
            <div
              className={`grid gap-[3mm] ${
                splitMode === 'single_only' ? 'grid-cols-1' : 'grid-cols-2'
              }`}
            >
              {activeSlots.map((slot, idx) => renderReceiptCell(slot, idx, true))}
            </div>
          )}
        </div>
      </div>

      {/* Dedicated Print Preview Modal */}
      {previewModalOpen && (
        <div className="fixed inset-0 z-50 flex flex-col bg-slate-900/75 p-4">
          <div className="mx-auto w-full max-w-5xl rounded-2xl bg-white border border-slate-200 shadow-2xl flex flex-col max-h-full overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-6 py-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  معاينة قبل الطباعة ({paperSize} ·{' '}
                  {splitMode === 'single_only'
                    ? 'وصل واحد فقط بدون الخانات الأخرى'
                    : `${activeSlots.length} وصولات`})
                </h3>
                <p className="text-xs text-slate-500">
                  تأكد من تنسيق الوصولات وحجم الورق أو نزّل الورقة كصورة PNG قبل الطباعة.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownloadSheetPng}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-bold text-emerald-800 hover:bg-emerald-100 cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>تنزيل PNG</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintSheet}
                  className="inline-flex items-center gap-2 rounded-xl bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 cursor-pointer"
                >
                  <Printer className="h-4 w-4" />
                  <span>طباعة الآن</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewModalOpen(false)}
                  className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto bg-slate-200/80 p-6">
              <div
                className="mx-auto bg-white border border-slate-300 shadow-md p-[4mm]"
                style={{
                  width: paperSize === 'A4' ? '202mm' : '288mm',
                  minHeight: paperSize === 'A4' ? '285mm' : '405mm',
                }}
              >
                <div
                  className={`grid gap-[3mm] ${
                    splitMode === 'single_only' ? 'grid-cols-1' : 'grid-cols-2'
                  }`}
                >
                  {activeSlots.map((slot, idx) => renderReceiptCell(slot, idx, false))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
