import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import type { Language } from '../types';

export const PWAInstallButton: React.FC<{ lang: Language }> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) return null;

  const label =
    lang === 'fr' ? 'Installer l’app' : lang === 'en' ? 'Install App' : 'تثبيت التطبيق';

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="h-3.5 w-3.5" />
        <span>{label}</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Smartphone className="h-3.5 w-3.5" />
          <span>{label}</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
            <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-xl">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-slate-900">
                  {lang === 'fr'
                    ? 'Installer sur iPhone / iPad'
                    : lang === 'en'
                      ? 'Install on iPhone / iPad'
                      : 'تثبيت التطبيق على iPhone / iPad'}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">
                {lang === 'fr' ? (
                  <>
                    1. Appuyez sur le bouton <strong>Partager</strong> dans Safari.
                    <br />
                    2. Sélectionnez <strong>Sur l’écran d’accueil</strong>.
                  </>
                ) : lang === 'en' ? (
                  <>
                    1. Tap the <strong>Share</strong> icon in Safari.
                    <br />
                    2. Choose <strong>Add to Home Screen</strong>.
                  </>
                ) : (
                  <>
                    1. اضغط على زر <strong>المشاركة (Share)</strong> في متصفح Safari.
                    <br />
                    2. اختر <strong>إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.
                  </>
                )}
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full rounded-lg bg-blue-700 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors"
              >
                {lang === 'fr' ? 'Fermer' : lang === 'en' ? 'Close' : 'إغلاق'}
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
