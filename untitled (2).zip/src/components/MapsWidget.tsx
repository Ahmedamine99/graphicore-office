import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AdvancedMarker,
  APIProvider,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { ExternalLink, LocateFixed, MapPin, Navigation, Route as RouteIcon, X } from 'lucide-react';
import type { Language, Order, PublicConfig } from '../types';
import { TRANSLATIONS } from '../i18n';

interface LatLng {
  lat: number;
  lng: number;
}

function dispatchQuotaIfNeeded(err: unknown) {
  const msg = String(err || '');
  if (
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('OVER_QUERY_LIMIT') ||
    msg.includes('OverQuotaMapError') ||
    msg.includes('Quota')
  ) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
}

type AnchorMarker = React.ComponentProps<typeof InfoWindow>['anchor'];

interface MapPolyline {
  setOptions: (opts: Record<string, unknown>) => void;
  setMap: (map: unknown) => void;
}

export function useAdvancedMarkerRef() {
  const [marker, setMarker] = useState<AnchorMarker>(null);
  const refCallback = useCallback((m: unknown) => {
    setMarker((m as AnchorMarker) ?? null);
  }, []);
  return [refCallback, marker] as const;
}

const RoutePolylineOverlay: React.FC<{
  origin: LatLng | null;
  destination: LatLng | null;
  onStats?: (stats: { distanceKm: string; durationMin: number } | null) => void;
}> = ({ origin, destination, onStats }) => {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<MapPolyline[]>([]);

  useEffect(() => {
    if (!routesLib || !map || !origin || !destination) {
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
      onStats?.(null);
      return;
    }

    let cancelled = false;

    const request = {
      origin: { lat: origin.lat, lng: origin.lng },
      destination: { lat: destination.lat, lng: destination.lng },
      travelMode: 'DRIVING',
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    };

    (routesLib.Route as any)
      .computeRoutes(request)
      .then(({ routes }: { routes: any[] }) => {
        if (cancelled) return;
        polylinesRef.current.forEach((p) => p.setMap(null));
        polylinesRef.current = [];
        if (!routes || routes.length === 0) {
          onStats?.(null);
          return;
        }
        const primaryRoute = routes[0];
        const newPolylines = primaryRoute.createPolylines() as MapPolyline[];
        newPolylines.forEach((polyline) => {
          polyline.setOptions({
            strokeColor: '#1D4ED8',
            strokeWeight: 5,
            strokeOpacity: 0.9,
          });
          polyline.setMap(map);
        });
        polylinesRef.current = newPolylines;
        if (primaryRoute.viewport) {
          map.fitBounds(primaryRoute.viewport);
        }
        onStats?.({
          distanceKm: ((primaryRoute.distanceMeters || 0) / 1000).toFixed(1),
          durationMin: Math.max(1, Math.round((primaryRoute.durationMillis || 0) / 60000)),
        });
      })
      .catch((err: unknown) => {
        dispatchQuotaIfNeeded(err);
        onStats?.(null);
      });

    return () => {
      cancelled = true;
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [routesLib, map, origin?.lat, origin?.lng, destination?.lat, destination?.lng]);

  return null;
};

export const DeliveryLocationPicker: React.FC<{
  lang: Language;
  apiKey: string;
  officePos: LatLng;
  selectedPos: LatLng | null;
  onChange: (pos: LatLng, addressText?: string) => void;
}> = ({ lang, apiKey, officePos, selectedPos, onChange }) => {
  const t = TRANSLATIONS[lang];
  const [locating, setLocating] = useState(false);
  const [geoError, setGeoError] = useState<string | null>(null);
  const markerPos = selectedPos || officePos;

  const reverseGeocode = async (pos: LatLng) => {
    try {
      const resp = await fetch(`/api/maps/geocode?lat=${pos.lat}&lng=${pos.lng}`);
      if (resp.status === 429) {
        window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        return;
      }
      if (!resp.ok) return;
      const data = await resp.json();
      if (data.status === 'RESOURCE_EXHAUSTED') {
        window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        return;
      }
      if (data.formattedAddress) {
        onChange(pos, data.formattedAddress);
      }
    } catch {
      // keep coordinates even if reverse geocode fails
    }
  };

  const handleUseGps = () => {
    if (!navigator.geolocation) {
      setGeoError('Geolocation unsupported on this browser.');
      return;
    }
    setLocating(true);
    setGeoError(null);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const nextPos = {
          lat: Number(position.coords.latitude.toFixed(6)),
          lng: Number(position.coords.longitude.toFixed(6)),
        };
        onChange(nextPos);
        reverseGeocode(nextPos);
        setLocating(false);
      },
      () => {
        setGeoError(
          lang === 'fr'
            ? 'Impossible d’obtenir votre position GPS. Cliquez directement sur la carte.'
            : lang === 'en'
              ? 'Could not read GPS location. Click directly on the map.'
              : 'تعذر قراءة موقع GPS تلقائياً. يمكنك النقر مباشرة على الخريطة لتحديد موقعك.'
        );
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  if (!apiKey) {
    return (
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
        {lang === 'ar'
          ? 'خرائط Google غير متوفرة حالياً؛ يمكنك كتابة عنوانك التفصيلي أدناه.'
          : 'Google Maps unavailable; please enter your detailed address below.'}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-slate-600">{t.clickMapHint}</p>
        <button
          type="button"
          onClick={handleUseGps}
          disabled={locating}
          className="inline-flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs font-semibold text-blue-800 hover:bg-blue-100 transition-colors cursor-pointer"
        >
          <LocateFixed className="h-3.5 w-3.5" />
          <span>{locating ? '...' : t.useMyGps}</span>
        </button>
      </div>

      {geoError && <p className="text-xs text-amber-700">{geoError}</p>}

      <div className="h-[300px] w-full overflow-hidden rounded-xl border border-slate-200">
        <APIProvider apiKey={apiKey} language={lang} region="DZ">
          <GoogleMap
            mapId="DEMO_MAP_ID"
            defaultCenter={markerPos}
            center={selectedPos || undefined}
            defaultZoom={14}
            gestureHandling="greedy"
            internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            style={{ width: '100%', height: '100%' }}
            onClick={(ev) => {
              const latLng = ev.detail.latLng;
              if (!latLng) return;
              const next = { lat: Number(latLng.lat.toFixed(6)), lng: Number(latLng.lng.toFixed(6)) };
              onChange(next);
              reverseGeocode(next);
            }}
          >
            <AdvancedMarker position={officePos} title="Graphicore Office">
              <Pin background="#0F172A" borderColor="#1E293B" glyphColor="#FFFFFF" />
            </AdvancedMarker>
            {selectedPos && (
              <AdvancedMarker
                position={selectedPos}
                draggable
                onDragEnd={(ev) => {
                  const pos = ev.latLng;
                  if (!pos) return;
                  const next = { lat: Number(pos.lat().toFixed(6)), lng: Number(pos.lng().toFixed(6)) };
                  onChange(next);
                  reverseGeocode(next);
                }}
              >
                <Pin background="#1D4ED8" borderColor="#1E40AF" glyphColor="#FFFFFF" />
              </AdvancedMarker>
            )}
          </GoogleMap>
        </APIProvider>
      </div>

      {selectedPos && (
        <div className="flex items-center gap-2 text-xs text-slate-600 font-mono-nums">
          <MapPin className="h-3.5 w-3.5 text-blue-700 shrink-0" />
          <span>
            {selectedPos.lat.toFixed(5)}, {selectedPos.lng.toFixed(5)}
          </span>
        </div>
      )}
    </div>
  );
};

const OfficeMapViewportSync: React.FC<{
  officePos: LatLng;
  disabled: boolean;
}> = ({ officePos, disabled }) => {
  const map = useMap();
  useEffect(() => {
    if (!map || disabled) return;
    map.setCenter(officePos);
    map.setZoom(15);
  }, [map, officePos.lat, officePos.lng, disabled]);
  return null;
};

export const OfficeDirectionsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  config: PublicConfig;
  lang: Language;
}> = ({ isOpen, onClose, config, lang }) => {
  const [userPos, setUserPos] = useState<LatLng | null>(null);
  const [routeStats, setRouteStats] = useState<{ distanceKm: string; durationMin: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [infoOpen, setInfoOpen] = useState(true);
  const [officeMarkerRef, officeMarker] = useAdvancedMarkerRef();

  useEffect(() => {
    if (isOpen) {
      setInfoOpen(true);
    }
  }, [isOpen, config.officeLat, config.officeLng]);

  if (!isOpen) return null;

  const officePos: LatLng = { lat: Number(config.officeLat) || 36.7538, lng: Number(config.officeLng) || 3.0588 };
  const externalDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${officePos.lat},${officePos.lng}`;

  const locateCustomer = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setUserPos({ lat: p.coords.latitude, lng: p.coords.longitude });
        setLocating(false);
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
      <div className="w-full max-w-3xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div className="flex items-center gap-3">
            {config.officeLogo && (
              <img
                src={config.officeLogo}
                alt={config.officeName}
                className="h-9 w-9 rounded-lg object-contain border border-slate-200 bg-white p-0.5"
              />
            )}
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                {lang === 'fr'
                  ? `Emplacement & Itinéraire — ${config.officeName}`
                  : lang === 'en'
                    ? `Location & Directions — ${config.officeName}`
                    : `موقعنا وكيفية الوصول إلينا — ${config.officeName}`}
              </h3>
              <p className="mt-0.5 text-xs text-slate-600">{config.officeAddress}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={locateCustomer}
                disabled={locating}
                className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 transition-colors cursor-pointer"
              >
                <RouteIcon className="h-4 w-4" />
                <span>
                  {locating
                    ? '...'
                    : lang === 'fr'
                      ? 'Calculer le trajet depuis ma position'
                      : lang === 'en'
                        ? 'Show Route from My Location'
                        : 'عرض المسار من موقعي الحالي'}
                </span>
              </button>
              <a
                href={externalDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <Navigation className="h-4 w-4 text-blue-700" />
                <span>
                  {lang === 'fr'
                    ? 'Ouvrir dans Google Maps'
                    : lang === 'en'
                      ? 'Open in Google Maps'
                      : 'فتح في تطبيق خرائط Google'}
                </span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>

            {routeStats && (
              <div className="text-xs font-semibold text-blue-800 font-mono-nums">
                {routeStats.distanceKm} km · {routeStats.durationMin}{' '}
                {lang === 'fr' ? 'min' : lang === 'en' ? 'min' : 'دقيقة'}
              </div>
            )}
          </div>

          {config.googleMapsApiKey ? (
            <div className="h-[360px] w-full overflow-hidden rounded-xl border border-slate-200">
              <APIProvider apiKey={config.googleMapsApiKey} libraries={['routes', 'marker']} language={lang} region="DZ">
                <GoogleMap
                  key={`${officePos.lat}-${officePos.lng}`}
                  mapId="DEMO_MAP_ID"
                  defaultCenter={officePos}
                  defaultZoom={15}
                  gestureHandling="greedy"
                  internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                  style={{ width: '100%', height: '100%' }}
                >
                  <OfficeMapViewportSync officePos={officePos} disabled={Boolean(userPos)} />
                  <AdvancedMarker
                    ref={officeMarkerRef}
                    position={officePos}
                    title={config.officeName}
                    onClick={() => setInfoOpen((prev) => !prev)}
                  >
                    <Pin background="#1D4ED8" borderColor="#1E3A8A" glyphColor="#FFFFFF" scale={1.15} />
                  </AdvancedMarker>
                  {infoOpen && officeMarker && (
                    <InfoWindow anchor={officeMarker} onCloseClick={() => setInfoOpen(false)}>
                      <div className="min-w-[170px] space-y-1 text-xs text-slate-800">
                        <div className="font-extrabold text-blue-900">{config.officeName}</div>
                        {config.officeAddress && <div className="text-slate-600">{config.officeAddress}</div>}
                        <div className="font-mono-nums text-[10px] text-slate-400">
                          {officePos.lat.toFixed(5)}, {officePos.lng.toFixed(5)}
                        </div>
                      </div>
                    </InfoWindow>
                  )}
                  {userPos && (
                    <AdvancedMarker position={userPos} title="My Location">
                      <Pin background="#0F172A" borderColor="#334155" glyphColor="#FFFFFF" />
                    </AdvancedMarker>
                  )}
                  <RoutePolylineOverlay origin={userPos} destination={officePos} onStats={setRouteStats} />
                </GoogleMap>
              </APIProvider>
            </div>
          ) : (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-6 text-center text-sm text-slate-600 space-y-2">
              <div className="font-bold text-slate-900">{config.officeName}</div>
              <div>{config.officeAddress}</div>
              <div className="font-mono-nums text-xs text-slate-500">
                {officePos.lat.toFixed(5)}, {officePos.lng.toFixed(5)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const DeliveryPinWithInfo: React.FC<{
  order: Order;
  isSelected: boolean;
  onSelect: () => void;
}> = ({ order, isSelected, onSelect }) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  if (!order.delivery_lat || !order.delivery_lng) return null;

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: order.delivery_lat, lng: order.delivery_lng }}
        onClick={onSelect}
        title={order.customer_name}
      >
        <Pin
          background={isSelected ? '#DC2626' : '#0284C7'}
          borderColor={isSelected ? '#991B1B' : '#0369A1'}
          glyphColor="#FFFFFF"
        />
      </AdvancedMarker>
      {isSelected && marker && (
        <InfoWindow anchor={marker} onCloseClick={onSelect}>
          <div className="min-w-[180px] text-xs text-slate-800 space-y-1">
            <div className="font-bold">{order.customer_name}</div>
            <div className="font-mono-nums text-slate-600">{order.tracking_code}</div>
            <div className="font-mono-nums text-blue-700">{order.customer_phone}</div>
            {order.delivery_address && <div className="text-slate-600">{order.delivery_address}</div>}
          </div>
        </InfoWindow>
      )}
    </>
  );
};

export const AdminDeliveryMap: React.FC<{
  apiKey: string;
  officePos: LatLng;
  deliveryOrders: Order[];
  selectedOrder: Order | null;
  onSelectOrder: (o: Order) => void;
}> = ({ apiKey, officePos, deliveryOrders, selectedOrder, onSelectOrder }) => {
  const [routeStats, setRouteStats] = useState<{ distanceKm: string; durationMin: number } | null>(null);

  if (!apiKey) {
    return (
      <div className="rounded-xl border border-slate-200 bg-slate-50 p-6 text-sm text-slate-600">
        مفتاح خرائط Google غير مهيأ للعرض.
      </div>
    );
  }

  const dest =
    selectedOrder && selectedOrder.delivery_lat && selectedOrder.delivery_lng
      ? { lat: selectedOrder.delivery_lat, lng: selectedOrder.delivery_lng }
      : null;

  return (
    <div className="space-y-3">
      {routeStats && selectedOrder && (
        <div className="flex items-center justify-between rounded-lg border border-blue-200 bg-blue-50 px-4 py-2 text-xs font-semibold text-blue-900">
          <span>مسار التوصيل إلى {selectedOrder.customer_name}</span>
          <span className="font-mono-nums">
            {routeStats.distanceKm} كم · {routeStats.durationMin} دقيقة
          </span>
        </div>
      )}
      <div className="h-[400px] w-full overflow-hidden rounded-xl border border-slate-200">
        <APIProvider apiKey={apiKey} libraries={['routes', 'marker']} language="ar" region="DZ">
          <GoogleMap
            mapId="DEMO_MAP_ID"
            defaultCenter={officePos}
            defaultZoom={13}
            gestureHandling="greedy"
            internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            style={{ width: '100%', height: '100%' }}
          >
            <AdvancedMarker position={officePos} title="Graphicore Office">
              <Pin background="#0F172A" borderColor="#1E293B" glyphColor="#FFFFFF" scale={1.15} />
            </AdvancedMarker>
            {deliveryOrders.map((order) => (
              <DeliveryPinWithInfo
                key={order.id}
                order={order}
                isSelected={selectedOrder?.id === order.id}
                onSelect={() => onSelectOrder(order)}
              />
            ))}
            <RoutePolylineOverlay origin={officePos} destination={dest} onStats={setRouteStats} />
          </GoogleMap>
        </APIProvider>
      </div>
    </div>
  );
};

export const AdminOfficeLocationPicker: React.FC<{
  apiKey: string;
  position: LatLng;
  onChange: (pos: LatLng, address?: string) => void;
}> = ({ apiKey, position, onChange }) => {
  if (!apiKey) return null;

  const reverseGeocode = async (pos: LatLng) => {
    try {
      const resp = await fetch(`/api/maps/geocode?lat=${pos.lat}&lng=${pos.lng}`);
      if (!resp.ok) return;
      const data = await resp.json();
      if (data.formattedAddress) onChange(pos, data.formattedAddress);
    } catch {
      // ignore
    }
  };

  return (
    <div className="h-[300px] w-full overflow-hidden rounded-xl border border-slate-200">
      <APIProvider apiKey={apiKey} libraries={['marker']} language="ar" region="DZ">
        <GoogleMap
          mapId="DEMO_MAP_ID"
          defaultCenter={position}
          center={position}
          defaultZoom={15}
          gestureHandling="greedy"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          style={{ width: '100%', height: '100%' }}
          onClick={(ev) => {
            const ll = ev.detail.latLng;
            if (!ll) return;
            const next = { lat: Number(ll.lat.toFixed(6)), lng: Number(ll.lng.toFixed(6)) };
            onChange(next);
            reverseGeocode(next);
          }}
        >
          <AdvancedMarker
            position={position}
            draggable
            onDragEnd={(ev) => {
              const p = ev.latLng;
              if (!p) return;
              const next = { lat: Number(p.lat().toFixed(6)), lng: Number(p.lng().toFixed(6)) };
              onChange(next);
              reverseGeocode(next);
            }}
          >
            <Pin background="#1D4ED8" borderColor="#1E3A8A" glyphColor="#FFFFFF" />
          </AdvancedMarker>
        </GoogleMap>
      </APIProvider>
    </div>
  );
};
