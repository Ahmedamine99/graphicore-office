import React, { useEffect, useState } from 'react';
import { WifiOff } from 'lucide-react';
import type { Language } from '../types';

export const OfflineIndicator: React.FC<{ lang: Language }> = ({ lang }) => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const on = () => setIsOnline(true);
    const off = () => setIsOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 start-4 z-50 flex items-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-900 shadow-lg">
      <WifiOff className="h-4 w-4 text-amber-700 shrink-0" />
      <span>
        {lang === 'fr'
          ? 'Mode hors ligne — Données en cache utilisées.'
          : lang === 'en'
            ? 'Offline Mode — Using cached view.'
            : 'وضع عدم الاتصال — يتم عرض البيانات المخزنة مؤقتاً.'}
      </span>
    </div>
  );
};
