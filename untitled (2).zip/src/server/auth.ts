import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';
import { getSetting } from './db.ts';

export interface SessionPayload {
  userId: number | 'master';
  username: string;
  displayName: string;
  role: 'admin' | 'manager' | 'operator' | 'delivery';
  permissions: string[];
  exp: number;
}

export const ALL_PERMISSIONS = [
  'orders',
  'pricing',
  'accounting',
  'ai_advisor',
  'printing',
  'delivery',
  'reviews',
  'settings',
  'staff',
];

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  if (!password || !stored || !stored.includes(':')) return false;
  // Explicitly reject insecure legacy default passcode
  if (password === '1234') return false;
  const [salt, keyHex] = stored.split(':');
  if (!salt || !keyHex) return false;
  const keyBuf = Buffer.from(keyHex, 'hex');
  const derived = crypto.scryptSync(password, salt, 64);
  if (derived.length !== keyBuf.length) return false;
  return crypto.timingSafeEqual(derived, keyBuf);
}

export function signSessionToken(payload: SessionPayload): string {
  const secret = getSetting('session_secret');
  const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  return `${data}.${sig}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  try {
    const [data, sig] = token.split('.');
    if (!data || !sig) return null;
    const secret = getSetting('session_secret');
    const expected = crypto.createHmac('sha256', secret).update(data).digest('base64url');
    const sigBuf = Buffer.from(sig);
    const expBuf = Buffer.from(expected);
    if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
      return null;
    }
    const payload = JSON.parse(Buffer.from(data, 'base64url').toString('utf8')) as SessionPayload;
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

export function parseCookieToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  if (typeof req.query.token === 'string' && req.query.token.trim()) {
    return req.query.token.trim();
  }
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return null;
  const parts = cookieHeader.split(';');
  for (const part of parts) {
    const [k, ...rest] = part.trim().split('=');
    if (k === 'go_admin_session') {
      return decodeURIComponent(rest.join('='));
    }
  }
  return null;
}

export interface AuthedRequest extends Request {
  adminSession?: SessionPayload;
}

export function requireAdmin(requiredPermission?: string) {
  return (req: AuthedRequest, res: Response, next: NextFunction) => {
    const token = parseCookieToken(req);
    if (!token) {
      res.status(401).json({ error: 'Unauthorized: Admin authentication required.' });
      return;
    }
    const session = verifySessionToken(token);
    if (!session) {
      res.status(401).json({ error: 'Unauthorized: Invalid or expired session.' });
      return;
    }
    if (
      requiredPermission &&
      session.role !== 'admin' &&
      !session.permissions.includes(requiredPermission)
    ) {
      res.status(403).json({ error: 'Forbidden: Insufficient permissions.' });
      return;
    }
    req.adminSession = session;
    next();
  };
}
