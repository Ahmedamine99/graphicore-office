import Database from 'better-sqlite3';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
export const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
const DB_PATH = path.join(DATA_DIR, 'graphicore.db');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Pre-computed salted scrypt hash for initial master admin access.
// Plaintext credential is never stored or logged anywhere in source code.
const INITIAL_ADMIN_HASH =
  '3a755256bf1a1f61b9aee23057719154:47be726c513a4d4fdbcf7f232e27e7c7f7e2df155d16245bfabdbabe18e8ea3ee5c254d8407841e10be63c8764caf0eb5778e40157b8c5c00af5d203a02124ed';

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category TEXT NOT NULL CHECK(category IN ('printing', 'admin', 'design')),
      name_ar TEXT NOT NULL,
      name_fr TEXT NOT NULL,
      name_en TEXT NOT NULL,
      price REAL NOT NULL DEFAULT 0,
      price_max REAL,
      unit_label_ar TEXT NOT NULL DEFAULT 'وحدة',
      unit_label_fr TEXT NOT NULL DEFAULT 'unité',
      unit_label_en TEXT NOT NULL DEFAULT 'unit',
      min_qty INTEGER NOT NULL DEFAULT 1,
      setup_design_fee REAL NOT NULL DEFAULT 0,
      print_unit_price REAL,
      pricing_note_ar TEXT NOT NULL DEFAULT '',
      pricing_note_fr TEXT NOT NULL DEFAULT '',
      pricing_note_en TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tracking_code TEXT NOT NULL UNIQUE,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      items_json TEXT NOT NULL DEFAULT '[]',
      custom_requests_json TEXT NOT NULL DEFAULT '[]',
      total_price REAL NOT NULL DEFAULT 0,
      custom_price_status TEXT NOT NULL DEFAULT 'fixed' CHECK(custom_price_status IN ('fixed', 'pending_quote', 'quoted')),
      notes TEXT NOT NULL DEFAULT '',
      pickup_type TEXT NOT NULL DEFAULT 'tomorrow_morning' CHECK(pickup_type IN ('tomorrow_morning', 'scheduled', 'asap')),
      pickup_datetime TEXT,
      delivery_requested INTEGER NOT NULL DEFAULT 0,
      delivery_lat REAL,
      delivery_lng REAL,
      delivery_address TEXT NOT NULL DEFAULT '',
      delivery_fee REAL NOT NULL DEFAULT 0,
      terms_accepted INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'sent' CHECK(status IN ('sent', 'seen', 'in_progress', 'completed', 'delivered_picked_up')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS order_files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      original_name TEXT NOT NULL,
      stored_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      uploaded_by TEXT NOT NULL DEFAULT 'customer' CHECK(uploaded_by IN ('customer', 'admin')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS order_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      sender TEXT NOT NULL CHECK(sender IN ('customer', 'admin')),
      message_text TEXT NOT NULL DEFAULT '',
      attachment_file_id INTEGER,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (attachment_file_id) REFERENCES order_files(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL UNIQUE,
      tracking_code TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
      category TEXT NOT NULL DEFAULT 'rating' CHECK(category IN ('rating', 'suggestion', 'complaint')),
      comment TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS accounting_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entry_type TEXT NOT NULL CHECK(entry_type IN ('income', 'expense')),
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      amount REAL NOT NULL,
      order_id INTEGER,
      entry_date TEXT NOT NULL DEFAULT (date('now')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS inventory_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT NOT NULL CHECK(category IN ('paper', 'ink', 'cards', 'supplies')),
      quantity REAL NOT NULL DEFAULT 0,
      unit TEXT NOT NULL DEFAULT 'وحدة',
      unit_cost REAL NOT NULL DEFAULT 0,
      min_threshold REAL NOT NULL DEFAULT 5,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS staff_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin', 'manager', 'operator', 'delivery')),
      permissions_json TEXT NOT NULL DEFAULT '[]',
      password_hash TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS admin_notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      order_id INTEGER,
      email_sent_to TEXT,
      email_status TEXT NOT NULL DEFAULT 'logged',
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_vault_files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      original_name TEXT NOT NULL,
      stored_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      category TEXT NOT NULL DEFAULT 'general',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Safely migrate legacy orders table CHECK constraint ('under_review', ...) to 5-stage workflow
  const ordersTableRow = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'orders'")
    .get() as { sql?: string } | undefined;
  if (ordersTableRow?.sql && ordersTableRow.sql.includes("'under_review'")) {
    db.pragma('foreign_keys = OFF');
    const migrateTx = db.transaction(() => {
      db.exec(`
        CREATE TABLE orders_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tracking_code TEXT NOT NULL UNIQUE,
          customer_name TEXT NOT NULL,
          customer_phone TEXT NOT NULL,
          items_json TEXT NOT NULL DEFAULT '[]',
          custom_requests_json TEXT NOT NULL DEFAULT '[]',
          total_price REAL NOT NULL DEFAULT 0,
          custom_price_status TEXT NOT NULL DEFAULT 'fixed' CHECK(custom_price_status IN ('fixed', 'pending_quote', 'quoted')),
          notes TEXT NOT NULL DEFAULT '',
          pickup_type TEXT NOT NULL DEFAULT 'tomorrow_morning' CHECK(pickup_type IN ('tomorrow_morning', 'scheduled', 'asap')),
          pickup_datetime TEXT,
          delivery_requested INTEGER NOT NULL DEFAULT 0,
          delivery_lat REAL,
          delivery_lng REAL,
          delivery_address TEXT NOT NULL DEFAULT '',
          delivery_fee REAL NOT NULL DEFAULT 0,
          terms_accepted INTEGER NOT NULL DEFAULT 1,
          status TEXT NOT NULL DEFAULT 'sent' CHECK(status IN ('sent', 'seen', 'in_progress', 'completed', 'delivered_picked_up')),
          created_at TEXT NOT NULL DEFAULT (datetime('now')),
          updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        INSERT INTO orders_new (
          id, tracking_code, customer_name, customer_phone, items_json, custom_requests_json,
          total_price, custom_price_status, notes, pickup_type, pickup_datetime,
          delivery_requested, delivery_lat, delivery_lng, delivery_address, delivery_fee,
          terms_accepted, status, created_at, updated_at
        )
        SELECT
          id, tracking_code, customer_name, customer_phone, items_json, custom_requests_json,
          total_price, custom_price_status, notes, pickup_type, pickup_datetime,
          delivery_requested, delivery_lat, delivery_lng, delivery_address, delivery_fee,
          terms_accepted,
          CASE status
            WHEN 'under_review' THEN 'sent'
            WHEN 'reviewed' THEN 'seen'
            WHEN 'ready' THEN 'completed'
            WHEN 'in_progress' THEN 'in_progress'
            ELSE 'sent'
          END,
          created_at, updated_at
        FROM orders;

        DROP TABLE orders;
        ALTER TABLE orders_new RENAME TO orders;
      `);
    });
    migrateTx();
    db.pragma('foreign_keys = ON');
  }

  const defaultSettings: Record<string, string> = {
    admin_password_hash: INITIAL_ADMIN_HASH,
    session_secret: crypto.randomBytes(32).toString('hex'),
    office_name: 'Graphicore Office',
    office_logo: '',
    office_logo_file: '',
    office_address: 'حي أول نوفمبر، مركز الأعمال، الجزائر',
    office_lat: '36.7538',
    office_lng: '3.0588',
    admin_email: 'ahm.amine47@gmail.com',
    working_hours_morning: '08:00 – 13:30',
    working_hours_evening: '18:30 – 21:30',
    delivery_base_fee: '200',
    delivery_enabled: '1',
    show_satisfaction_summary: '1',
    custom_printing_enabled: '1',
    custom_printing_label: 'طلب خدمة طباعة أخرى حسب الطلب (تحدد الإدارة السعر وترسله لك)',
    custom_admin_enabled: '1',
    custom_admin_label: 'طلب خدمة إدارية أخرى حسب الطلب (تحدد الإدارة السعر وترسله لك)',
    custom_design_enabled: '1',
    custom_design_label: 'طلب خدمة تصميم أو إشهار أخرى حسب الطلب (تحدد الإدارة السعر وترسله لك)',
    print_lock_enabled: '0',
    print_lock_pin_hash: '',
  };

  const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  for (const [k, v] of Object.entries(defaultSettings)) {
    insertSetting.run(k, v);
  }

  const servicesCount = (db.prepare('SELECT COUNT(*) as c FROM services').get() as { c: number }).c;
  if (servicesCount === 0) {
    const insertService = db.prepare(`
      INSERT INTO services (
        category, name_ar, name_fr, name_en, price, price_max,
        unit_label_ar, unit_label_fr, unit_label_en,
        min_qty, setup_design_fee, print_unit_price,
        pricing_note_ar, pricing_note_fr, pricing_note_en, active, sort_order
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);

    const seedServices = [
      // Printing Services
      ['printing', 'طباعة/نسخ A4 أسود - جهة واحدة', 'Impression/Copie A4 Noir - Recto', 'A4 B&W Print/Copy - Single Sided', 10, null, 'صفحة', 'page', 'page', 1, 0, null, '', '', '', 1],
      ['printing', 'طباعة/نسخ A4 أسود - جهتين', 'Impression/Copie A4 Noir - Recto/Verso', 'A4 B&W Print/Copy - Double Sided', 15, null, 'ورقة', 'feuille', 'sheet', 1, 0, null, '', '', '', 2],
      ['printing', 'طباعة A4 ألوان - جهة واحدة', 'Impression A4 Couleur - Recto', 'A4 Color Print - Single Sided', 15, null, 'صفحة', 'page', 'page', 1, 0, null, '', '', '', 3],
      ['printing', 'طباعة A4 ألوان - جهتين', 'Impression A4 Couleur - Recto/Verso', 'A4 Color Print - Double Sided', 20, null, 'ورقة', 'feuille', 'sheet', 1, 0, null, '', '', '', 4],
      ['printing', 'طباعة A3 أسود - جهة واحدة', 'Impression A3 Noir - Recto', 'A3 B&W Print - Single Sided', 20, null, 'صفحة', 'page', 'page', 1, 0, null, '', '', '', 5],
      ['printing', 'طباعة A3 ألوان - جهة واحدة', 'Impression A3 Couleur - Recto', 'A3 Color Print - Single Sided', 25, null, 'صفحة', 'page', 'page', 1, 0, null, '', '', '', 6],
      ['printing', 'طباعة A3 ألوان - جهتين', 'Impression A3 Couleur - Recto/Verso', 'A3 Color Print - Double Sided', 30, null, 'ورقة', 'feuille', 'sheet', 1, 0, null, '', '', '', 7],
      ['printing', 'طباعة صور A4 ألوان (نصف صفحة)', 'Impression Photo A4 Couleur (Demi-page)', 'A4 Color Photo Print (Half Page)', 25, null, 'صورة', 'photo', 'photo', 1, 0, null, '', '', '', 8],
      ['printing', 'طباعة صور A4 ألوان (صفحة كاملة)', 'Impression Photo A4 Couleur (Pleine page)', 'A4 Color Photo Print (Full Page)', 35, null, 'صورة', 'photo', 'photo', 1, 0, null, '', '', '', 9],

      // Administrative & Office Services
      ['admin', 'كتابة نصوص (صفحة واحدة - جهة واحدة)', 'Saisie de texte (1 page - Recto)', 'Text Typing (1 Page - Single Sided)', 100, null, 'صفحة', 'page', 'page', 1, 0, null, '', '', '', 10],
      ['admin', 'كتابة نصوص (صفحة واحدة - جهتان)', 'Saisie de texte (1 page - Recto/Verso)', 'Text Typing (1 Page - Double Sided)', 140, null, 'ورقة', 'feuille', 'sheet', 1, 0, null, '', '', '', 11],
      ['admin', 'إنشاء وكتابة جداول Excel', 'Création de tableaux Excel', 'Excel Spreadsheet Creation', 150, null, 'جدول', 'tableau', 'sheet', 1, 0, null, '', '', '', 12],
      ['admin', 'تحرير طلب خطي', 'Rédaction de demande manuscrite', 'Formal Letter / Request Drafting', 150, null, 'طلب', 'demande', 'letter', 1, 0, null, '', '', '', 13],
      ['admin', 'مسح ضوئي Scanner', 'Numérisation Scanner', 'Document Scanning', 20, null, 'صفحة', 'page', 'page', 1, 0, null, '', '', '', 14],
      ['admin', 'سيرة ذاتية عادية', 'CV Classique', 'Standard Resume / CV', 200, null, 'سيرة', 'CV', 'CV', 1, 0, null, '', '', '', 15],
      ['admin', 'سيرة ذاتية بتنسيق كندي', 'CV Format Canadien', 'Canadian Format CV', 400, null, 'سيرة', 'CV', 'CV', 1, 0, null, '', '', '', 16],
      ['admin', 'سيرة ذاتية بتنسيق أوروبي', 'CV Format Européen', 'European Format CV', 500, null, 'سيرة', 'CV', 'CV', 1, 0, null, '', '', '', 17],
      ['admin', 'صياغة عقود (ملكية / بيع / إيجار)', 'Rédaction de contrats (Propriété / Vente / Location)', 'Contract Drafting (Property / Sale / Lease)', 200, null, 'عقد', 'contrat', 'contract', 1, 0, null, '', '', '', 18],
      ['admin', 'صياغة عقد عرفي', 'Rédaction de contrat sous seing privé', 'Private Customary Contract Drafting', 300, null, 'عقد', 'contrat', 'contract', 1, 0, null, '', '', '', 19],
      ['admin', 'تنزيل برامج من الإنترنت', 'Téléchargement de logiciels', 'Software Download & Preparation', 100, null, 'برنامج', 'logiciel', 'software', 1, 0, null, '', '', '', 20],

      // Advertising & Design Services
      [
        'design',
        'تصميم بطاقة عمل Carte De Visite',
        'Design Carte de Visite',
        'Business Card Design (Carte De Visite)',
        800,
        null,
        'بطاقة',
        'carte',
        'card',
        100,
        800,
        10,
        '800 د.ج للتصميم + طباعة ابتداءً من 100 بطاقة بسعر 10 د.ج/بطاقة',
        '800 DA design + impression dès 100 cartes à 10 DA/carte',
        '800 DZD design + printing from 100 cards at 10 DZD/card',
        21,
      ],
      [
        'design',
        'تصميم منشورات السوشل ميديا',
        'Design Publications Réseaux Sociaux',
        'Social Media Post Design',
        500,
        1000,
        'منشور',
        'visuel',
        'post',
        1,
        0,
        null,
        'يتراوح السعر بين 500 و 1000 د.ج حسب التفاصيل',
        'Tarif entre 500 et 1000 DA selon la complexité',
        'Priced between 500 and 1000 DZD depending on scope',
        22,
      ],
      [
        'design',
        'تصميم مطويات Dépliant',
        'Design Dépliant / Brochure',
        'Brochure / Flyer Design (Dépliant)',
        800,
        null,
        'مطوية',
        'dépliant',
        'brochure',
        1,
        0,
        null,
        '',
        '',
        '',
        23,
      ],
      [
        'design',
        'تصميم شعار Logo احترافي',
        'Création de Logo Professionnel',
        'Professional Logo Design',
        2500,
        null,
        'شعار',
        'logo',
        'logo',
        1,
        0,
        null,
        'تصميم هوية احترافية كاملة مع ملفات عالية الدقة',
        'Création professionnelle haute résolution',
        'Professional high-resolution brand logo',
        24,
      ],
      [
        'design',
        'دعوة زفاف رجال (تصميم + طباعة)',
        'Faire-part Mariage Hommes',
        'Men Wedding Invitation',
        10,
        null,
        'دعوة',
        'invitation',
        'card',
        1,
        100,
        null,
        '10 د.ج للدعوة + 100 د.ج لتصميم دعوات الرجال',
        '10 DA / invitation + 100 DA frais de design',
        '10 DZD / card + 100 DZD design setup fee',
        25,
      ],
      [
        'design',
        'دعوة زفاف نساء (تصميم + طباعة)',
        'Faire-part Mariage Femmes',
        'Women Wedding Invitation',
        5,
        null,
        'دعوة',
        'invitation',
        'card',
        1,
        100,
        null,
        '5 د.ج للدعوة + 100 د.ج لتصميم دعوات النساء',
        '5 DA / invitation + 100 DA frais de design',
        '5 DZD / card + 100 DZD design setup fee',
        26,
      ],
    ];

    const tx = db.transaction(() => {
      for (const s of seedServices) {
        insertService.run(...s);
      }
    });
    tx();
  }

  const invCount = (db.prepare('SELECT COUNT(*) as c FROM inventory_items').get() as { c: number }).c;
  if (invCount === 0) {
    const insertInv = db.prepare(`
      INSERT INTO inventory_items (name, category, quantity, unit, unit_cost, min_threshold)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    insertInv.run('رزمة ورق A4 80g', 'paper', 20, 'رزمة', 950, 5);
    insertInv.run('رزمة ورق A3 80g', 'paper', 8, 'رزمة', 1800, 3);
    insertInv.run('ورق صور لامع A4', 'paper', 6, 'رزمة', 1200, 2);
    insertInv.run('حبر طابعة ألوان (CMYK)', 'ink', 4, 'طقم', 6500, 2);
    insertInv.run('بطاقات عمل فارغة 350g', 'cards', 1000, 'بطاقة', 4, 200);
  }
}

export function getSetting(key: string): string {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
  return row?.value ?? '';
}

export function setSetting(key: string, value: string): void {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, value);
}
