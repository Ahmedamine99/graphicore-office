import { GoogleGenAI, Type } from '@google/genai';
import { db } from './db.ts';
import type { AiAdvisorReport, OrderLineItem } from '../types.ts';

interface RawOrderRow {
  id: number;
  customer_phone: string;
  items_json: string;
  total_price: number;
  status: string;
  created_at: string;
}

interface RawAccountingRow {
  entry_type: 'income' | 'expense';
  category: string;
  amount: number;
  entry_date: string;
}

interface RawReviewRow {
  rating: number;
  category: string;
  comment: string;
  created_at: string;
}

interface ActiveServiceRow {
  id: number;
  category: string;
  name_ar: string;
  price: number;
}

export async function generateAiBusinessReport(language: 'ar' | 'fr' | 'en' = 'ar'): Promise<AiAdvisorReport> {
  const orders = db
    .prepare('SELECT id, customer_phone, items_json, total_price, status, created_at FROM orders ORDER BY created_at ASC')
    .all() as RawOrderRow[];
  const accounting = db
    .prepare('SELECT entry_type, category, amount, entry_date FROM accounting_entries ORDER BY entry_date ASC')
    .all() as RawAccountingRow[];
  const reviews = db
    .prepare('SELECT rating, category, comment, created_at FROM reviews ORDER BY created_at DESC')
    .all() as RawReviewRow[];
  const lowStock = db
    .prepare('SELECT name, quantity, unit, min_threshold FROM inventory_items WHERE quantity <= min_threshold')
    .all() as { name: string; quantity: number; unit: string; min_threshold: number }[];
  const activeServices = db
    .prepare('SELECT id, category, name_ar, price FROM services WHERE active = 1 ORDER BY sort_order ASC')
    .all() as ActiveServiceRow[];

  // Compute exact factual aggregates from database
  const ordersRevenue = orders.reduce((acc, o) => acc + (Number(o.total_price) || 0), 0);
  const manualIncome = accounting
    .filter((a) => a.entry_type === 'income')
    .reduce((acc, a) => acc + Number(a.amount || 0), 0);
  const totalExpenses = accounting
    .filter((a) => a.entry_type === 'expense')
    .reduce((acc, a) => acc + Number(a.amount || 0), 0);

  const syncedOrderIncome = accounting
    .filter((a) => a.entry_type === 'income' && a.category === 'orders')
    .reduce((acc, a) => acc + Number(a.amount || 0), 0);
  const extraIncome = manualIncome - syncedOrderIncome;
  const totalRevenue = ordersRevenue + Math.max(0, extraIncome);
  const netProfit = totalRevenue - totalExpenses;

  const avgOrderValue = orders.length > 0 ? Math.round((ordersRevenue / orders.length) * 100) / 100 : 0;

  const phoneCounts: Record<string, number> = {};
  for (const o of orders) {
    const p = o.customer_phone.trim();
    phoneCounts[p] = (phoneCounts[p] || 0) + 1;
  }
  const uniqueCustomers = Object.keys(phoneCounts).length;
  const repeatCustomers = Object.values(phoneCounts).filter((c) => c > 1).length;
  const repeatCustomerRate =
    uniqueCustomers > 0 ? Math.round((repeatCustomers / uniqueCustomers) * 1000) / 10 : 0;

  const serviceStats: Record<string, { name: string; count: number; revenue: number }> = {};
  for (const o of orders) {
    try {
      const items = JSON.parse(o.items_json) as OrderLineItem[];
      for (const item of items) {
        const key = item.name_ar || String(item.serviceId);
        if (!serviceStats[key]) {
          serviceStats[key] = { name: key, count: 0, revenue: 0 };
        }
        serviceStats[key].count += Number(item.quantity) || 1;
        serviceStats[key].revenue += Number(item.subtotal) || 0;
      }
    } catch {
      // ignore malformed item JSON
    }
  }
  const topServices = Object.values(serviceStats)
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 6);

  const dayMap: Record<string, { date: string; revenue: number; expenses: number; orders: number }> = {};
  for (const o of orders) {
    const day = (o.created_at || '').slice(0, 10);
    if (!day) continue;
    if (!dayMap[day]) dayMap[day] = { date: day, revenue: 0, expenses: 0, orders: 0 };
    dayMap[day].revenue += Number(o.total_price) || 0;
    dayMap[day].orders += 1;
  }
  for (const a of accounting) {
    const day = (a.entry_date || '').slice(0, 10);
    if (!day) continue;
    if (!dayMap[day]) dayMap[day] = { date: day, revenue: 0, expenses: 0, orders: 0 };
    if (a.entry_type === 'expense') {
      dayMap[day].expenses += Number(a.amount) || 0;
    } else if (a.category !== 'orders') {
      dayMap[day].revenue += Number(a.amount) || 0;
    }
  }
  const dailyTrend = Object.values(dayMap).sort((a, b) => a.date.localeCompare(b.date));

  const avgRating =
    reviews.length > 0
      ? Math.round((reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) * 100) / 100
      : null;

  const daysCovered = Math.max(1, dailyTrend.length);

  // Confidence level based on real volume
  const confidenceLevel: 'low' | 'medium' | 'high' =
    orders.length >= 15 && daysCovered >= 7 ? 'high' : orders.length >= 3 ? 'medium' : 'low';

  const profitMargin = totalRevenue > 0 ? Math.max(0, Math.min(1, netProfit / totalRevenue)) : 0;
  const ratingScore = avgRating !== null ? (avgRating / 5) * 30 : 18;
  const repeatScore = Math.min(25, (repeatCustomerRate / 100) * 25);
  const volumeScore = Math.min(20, orders.length * 1.5);
  const marginScore = profitMargin * 25;
  const computedSuccessScore =
    orders.length === 0
      ? 55
      : Math.round(Math.min(100, Math.max(15, ratingScore + repeatScore + volumeScore + marginScore)));

  // Proactive customer arrival prediction (even before first customer or with 1+ orders)
  const avgDailyOrders = orders.length > 0 ? orders.length / daysCovered : 0.25;
  const avgDailyRevenue = orders.length > 0 ? totalRevenue / daysCovered : 150;
  const expectedOrdersNextWeek = Math.max(1, Math.round(avgDailyOrders * 7));
  const expectedRevenueNextWeek =
    orders.length > 0 ? Math.max(avgOrderValue || 200, Math.round(avgDailyRevenue * 7)) : 250;
  const expectedCustomersNextMonth = Math.max(1, Math.round(((uniqueCustomers || 1) / daysCovered) * 30));
  const expectedNextCustomers = orders.length === 0 ? 1 : Math.max(1, Math.ceil(avgDailyOrders));

  const defaultLikelyService =
    topServices[0]?.name ||
    activeServices.find((s) => s.category === 'printing')?.name_ar ||
    'طباعة/نسخ A4 أو خدمات إدارية';

  const defaultArrivalNote =
    orders.length === 0
      ? 'تنبيه استباقي: يُتوقع قدوم عميل واحد قريباً لطلب أول خدمة — تأكد من جاهزية الطابعات والورق واستقبال الطلبات.'
      : `تنبؤ استباقي: يُتوقع قدوم ${expectedNextCustomers} عميل/عملاء في الفترة القادمة استناداً إلى معدل الطلب الحالي (${orders.length} طلب فعلي).`;

  const defaultReadinessChecklist = [
    'التأكد من توفر ورق A4/A3 والأحبار قبل بدء الدوام.',
    'متابعة إشعارات الطلبات الجديدة والرد الفوري في مساحة المراسلة.',
    ...(lowStock.length > 0
      ? lowStock.map((i) => `تنبيه مخزون منخفض: ${i.name} (${i.quantity} ${i.unit}).`)
      : ['تجهيز قوالب السيرة الذاتية والعقود لسرعة التنفيذ عند وصول العميل.']),
  ];

  const defaultConfidenceReason =
    orders.length === 0
      ? 'تنبؤ استباقي أولي (لا توجد طلبات مسجلة بعد — يُتوقع وصول عميل قريباً مع جاهزية الخدمات النشطة).'
      : `تحليل وتنبؤ استباقي مبني على ${orders.length} طلب فعلي خلال ${dailyTrend.length || 1} يوم (${
          confidenceLevel === 'high' ? 'ثقة عالية' : confidenceLevel === 'medium' ? 'ثقة متوسطة' : 'بيانات أولية'
        }).`;

  const factsPayload = {
    language,
    ordersCount: orders.length,
    daysCovered: dailyTrend.length,
    uniqueCustomers,
    repeatCustomers,
    repeatCustomerRate,
    totalRevenue,
    totalExpenses,
    netProfit,
    avgOrderValue,
    avgRating,
    activeServicesCount: activeServices.length,
    sampleActiveServices: activeServices.slice(0, 12).map((s) => ({ name: s.name_ar, price: s.price })),
    reviewsSample: reviews.slice(0, 15),
    topServices,
    dailyTrend: dailyTrend.slice(-14),
    lowStock,
    deterministicEstimates: {
      expectedNextCustomers,
      expectedOrdersNextWeek,
      expectedRevenueNextWeek,
      expectedCustomersNextMonth,
      computedSuccessScore,
      confidenceLevel,
    },
  };

  const buildFallbackReport = (aiWarning?: string): AiAdvisorReport => ({
    sufficientData: true,
    confidenceLevel,
    confidenceReason: defaultConfidenceReason,
    dataPointsUsed: {
      ordersCount: orders.length,
      daysCovered: dailyTrend.length,
      accountingEntriesCount: accounting.length,
      reviewsCount: reviews.length,
    },
    businessSuccessScore: computedSuccessScore,
    metricsSummary: {
      totalRevenue,
      totalExpenses,
      netProfit,
      breakEvenRevenue: totalExpenses > 0 ? totalExpenses : null,
      avgOrderValue,
      repeatCustomerRate,
      avgRating,
    },
    topServices,
    dailyTrend,
    forecasts: {
      expectedOrdersNextWeek,
      expectedRevenueNextWeek,
      expectedCustomersNextMonth,
      profitTrendNote:
        orders.length === 0
          ? 'توقع استباقي مبدئي قبل وصول أول عميل؛ يُنصح بمراقبة المصاريف الثابتة وتنشيط الطلبات السريعة.'
          : `متوسط الدخل اليومي الفعلي ${Math.round(avgDailyRevenue)} د.ج مقابل مصاريف إجمالية ${totalExpenses} د.ج.`,
    },
    incomingCustomerPrediction: {
      expectedNextCustomers,
      expectedArrivalNote: defaultArrivalNote,
      likelyServiceNote: `الخدمة المرجح طلبها عند قدوم العميل: ${defaultLikelyService}.`,
      readinessChecklist: defaultReadinessChecklist,
    },
    aiWarning,
    satisfactionAnalysis:
      reviews.length > 0
        ? `متوسط الرضا ${avgRating}/5 عبر ${reviews.length} تقييم فعلي.`
        : 'لا توجد تقييمات مسجلة بعد؛ التقييم متاح للعملاء فور إتمام أول طلب.',
    advice: {
      daily:
        orders.length === 0
          ? [
              'استعد لوصول العميل الأول: راجع أسعار الطباعة والخدمات الإدارية وشارك رابط المنصة.',
              ...defaultReadinessChecklist.slice(0, 1),
            ]
          : ['مراجعة الطلبات الجديدة وتأكيد أسعار الخدمات المخصصة بسرعة.'],
      weekly: ['مراقبة الخدمات الأكثر طلباً وتجهيز المخزون المناسب من الورق والأحبار.'],
      monthly: ['مقارنة صافي الربح بتكاليف المواد الشهرية لتعزيز الهامش الربحي.'],
    },
    alerts: [
      {
        severity: 'opportunity',
        title: `تنبؤ بقدوم ${expectedNextCustomers} عميل قريباً`,
        detail: defaultArrivalNote,
      },
      ...lowStock.map((i) => ({
        severity: 'warning' as const,
        title: `نقص مخزون: ${i.name}`,
        detail: `الكمية المتبقية ${i.quantity} ${i.unit} (الحد الأدنى ${i.min_threshold}).`,
      })),
    ],
    generatedAt: new Date().toISOString(),
  });

  if (!process.env.GEMINI_API_KEY) {
    return buildFallbackReport();
  }

  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const targetLangLabel =
    language === 'fr' ? 'French' : language === 'en' ? 'English' : 'Arabic';

  let parsed: {
    confidenceReason?: string;
    profitTrendNote?: string;
    expectedArrivalNote?: string;
    likelyServiceNote?: string;
    readinessChecklist?: string[];
    satisfactionAnalysis?: string;
    dailyAdvice?: string[];
    weeklyAdvice?: string[];
    monthlyAdvice?: string[];
    alerts?: { severity: 'warning' | 'opportunity' | 'info'; title: string; detail: string }[];
  } | null = null;

  let lastErrorMsg = '';
  try {
    const apiPromise = ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Analyze ONLY the following real operational metrics for this printing & administrative office and respond in ${targetLangLabel}. Never invent past orders or fake numbers. Even if ordersCount is 0, 1, or 2, provide a proactive pre-arrival forecast alerting management that at least 1 customer is expected soon and how to prepare.\n\nFACTS_JSON:\n${JSON.stringify(factsPayload)}`,
      config: {
        systemInstruction:
          'You are the confidential internal Business Advisor for Graphicore Office management. Strictly base every factual number on FACTS_JSON. Never fabricate historical metrics. Always include proactive pre-arrival customer readiness advice (predicting at least 1 incoming customer when orders are low/zero).',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            confidenceReason: { type: Type.STRING },
            profitTrendNote: { type: Type.STRING },
            expectedArrivalNote: { type: Type.STRING },
            likelyServiceNote: { type: Type.STRING },
            readinessChecklist: { type: Type.ARRAY, items: { type: Type.STRING } },
            satisfactionAnalysis: { type: Type.STRING },
            dailyAdvice: { type: Type.ARRAY, items: { type: Type.STRING } },
            weeklyAdvice: { type: Type.ARRAY, items: { type: Type.STRING } },
            monthlyAdvice: { type: Type.ARRAY, items: { type: Type.STRING } },
            alerts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  severity: { type: Type.STRING },
                  title: { type: Type.STRING },
                  detail: { type: Type.STRING },
                },
              },
            },
          },
        },
      },
    });
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('انتهت مهلة الاتصال بالنموذج — تم تفعيل التحليل الاستباقي المباشر')), 7000)
    );
    const response = await Promise.race([apiPromise, timeoutPromise]);
    parsed = JSON.parse((response.text ?? '{}').trim());
  } catch (err: any) {
    lastErrorMsg = err?.message || 'Gemini API request failed';
  }

  if (!parsed) {
    return buildFallbackReport(
      language === 'ar'
        ? `تم عرض التحليل الإحصائي والتنبؤ الاستباقي (ملاحظة من نموذج الذكاء الاصطناعي: ${lastErrorMsg})`
        : lastErrorMsg
    );
  }

  return {
    sufficientData: true,
    confidenceLevel,
    confidenceReason: parsed.confidenceReason || defaultConfidenceReason,
    dataPointsUsed: {
      ordersCount: orders.length,
      daysCovered: dailyTrend.length,
      accountingEntriesCount: accounting.length,
      reviewsCount: reviews.length,
    },
    businessSuccessScore: computedSuccessScore,
    metricsSummary: {
      totalRevenue,
      totalExpenses,
      netProfit,
      breakEvenRevenue: totalExpenses > 0 ? totalExpenses : null,
      avgOrderValue,
      repeatCustomerRate,
      avgRating,
    },
    topServices,
    dailyTrend,
    forecasts: {
      expectedOrdersNextWeek,
      expectedRevenueNextWeek,
      expectedCustomersNextMonth,
      profitTrendNote: parsed.profitTrendNote || '',
    },
    incomingCustomerPrediction: {
      expectedNextCustomers,
      expectedArrivalNote: parsed.expectedArrivalNote || defaultArrivalNote,
      likelyServiceNote:
        parsed.likelyServiceNote || `الخدمة المرجح طلبها عند قدوم العميل: ${defaultLikelyService}.`,
      readinessChecklist: parsed.readinessChecklist?.length
        ? parsed.readinessChecklist
        : defaultReadinessChecklist,
    },
    satisfactionAnalysis:
      parsed.satisfactionAnalysis ||
      (reviews.length > 0 ? `متوسط الرضا ${avgRating}/5 من ${reviews.length} تقييم.` : 'لا توجد تقييمات بعد.'),
    advice: {
      daily: parsed.dailyAdvice?.length ? parsed.dailyAdvice : ['متابعة الطلبات الجديدة وسرعة الرد في المراسلات.'],
      weekly: parsed.weeklyAdvice?.length ? parsed.weeklyAdvice : ['مراجعة أداء الخدمات الأكثر طلباً وتعديل التجهيزات.'],
      monthly: parsed.monthlyAdvice?.length ? parsed.monthlyAdvice : ['مراقبة المصاريف ونقطة التعادل الشهرية.'],
    },
    alerts: [
      ...(parsed.alerts || []).map((a) => ({
        severity: (a.severity === 'warning' || a.severity === 'opportunity' ? a.severity : 'info') as
          | 'warning'
          | 'opportunity'
          | 'info',
        title: a.title,
        detail: a.detail,
      })),
      ...lowStock.map((i) => ({
        severity: 'warning' as const,
        title: `مخزون منخفض: ${i.name}`,
        detail: `المتبقي ${i.quantity} ${i.unit} (الحد الأدنى ${i.min_threshold}).`,
      })),
    ],
    generatedAt: new Date().toISOString(),
  };
}
