export type Language = 'ar' | 'fr' | 'en';

export type ServiceCategory = 'printing' | 'admin' | 'design';

export type OrderStatus = 'sent' | 'seen' | 'in_progress' | 'completed' | 'delivered_picked_up';

export interface ServiceItem {
  id: number;
  category: ServiceCategory;
  name_ar: string;
  name_fr: string;
  name_en: string;
  price: number;
  price_max: number | null;
  unit_label_ar: string;
  unit_label_fr: string;
  unit_label_en: string;
  min_qty: number;
  setup_design_fee: number;
  print_unit_price: number | null;
  pricing_note_ar: string;
  pricing_note_fr: string;
  pricing_note_en: string;
  active: number;
  sort_order: number;
}

export interface OrderLineItem {
  serviceId: number;
  category: ServiceCategory;
  name_ar: string;
  name_fr: string;
  name_en: string;
  quantity: number;
  includeDesignPrint?: boolean;
  includeDesignSetup?: boolean;
  unitPrice: number;
  setupFee: number;
  subtotal: number;
}

export interface CustomServiceRequest {
  category: ServiceCategory;
  description: string;
  quantity: number;
  quotedPrice?: number | null;
}

export interface OrderFile {
  id: number;
  order_id: number;
  original_name: string;
  stored_name: string;
  mime_type: string;
  size_bytes: number;
  uploaded_by: 'customer' | 'admin';
  created_at: string;
}

export interface OrderMessage {
  id: number;
  order_id: number;
  sender: 'customer' | 'admin';
  message_text: string;
  attachment_file_id: number | null;
  attachment_name?: string | null;
  attachment_mime?: string | null;
  created_at: string;
}

export interface Order {
  id: number;
  tracking_code: string;
  customer_name: string;
  customer_phone: string;
  items: OrderLineItem[];
  custom_requests: CustomServiceRequest[];
  total_price: number;
  custom_price_status: 'fixed' | 'pending_quote' | 'quoted';
  notes: string;
  pickup_type: 'tomorrow_morning' | 'scheduled' | 'asap';
  pickup_datetime: string | null;
  delivery_requested: number;
  delivery_lat: number | null;
  delivery_lng: number | null;
  delivery_address: string;
  delivery_fee: number;
  terms_accepted: number;
  status: OrderStatus;
  created_at: string;
  updated_at: string;
  files?: OrderFile[];
  messages?: OrderMessage[];
  has_review?: boolean;
}

export interface Review {
  id: number;
  order_id: number;
  tracking_code: string;
  customer_name: string;
  rating: number;
  category: 'rating' | 'suggestion' | 'complaint';
  comment: string;
  created_at: string;
}

export interface AccountingEntry {
  id: number;
  entry_type: 'income' | 'expense';
  category: string;
  description: string;
  amount: number;
  order_id: number | null;
  entry_date: string;
  created_at: string;
}

export interface InventoryItem {
  id: number;
  name: string;
  category: 'paper' | 'ink' | 'cards' | 'supplies';
  quantity: number;
  unit: string;
  unit_cost: number;
  min_threshold: number;
  updated_at: string;
}

export interface StaffUser {
  id: number;
  username: string;
  display_name: string;
  role: 'admin' | 'manager' | 'operator' | 'delivery';
  permissions: string[];
  active: number;
  created_at: string;
}

export interface AdminNotification {
  id: number;
  type: string;
  title: string;
  body: string;
  order_id: number | null;
  email_sent_to: string | null;
  email_status: string;
  is_read: number;
  created_at: string;
}

export interface CustomCategoryConfig {
  enabled: boolean;
  label_ar: string;
}

export interface AdminVaultFile {
  id: number;
  original_name: string;
  stored_name: string;
  mime_type: string;
  size_bytes: number;
  category: string;
  notes: string;
  created_at: string;
}

export interface PublicConfig {
  googleMapsApiKey: string;
  officeName: string;
  officeLogo: string;
  officeAddress: string;
  officeLat: number;
  officeLng: number;
  workingHoursMorning: string;
  workingHoursEvening: string;
  deliveryBaseFee: number;
  deliveryEnabled: boolean;
  showSatisfactionSummary: boolean;
  customCategories?: Record<ServiceCategory, CustomCategoryConfig>;
}

export interface AiAdvisorReport {
  sufficientData: boolean;
  insufficientMessage?: string;
  confidenceLevel: 'low' | 'medium' | 'high';
  confidenceReason: string;
  dataPointsUsed: {
    ordersCount: number;
    daysCovered: number;
    accountingEntriesCount: number;
    reviewsCount: number;
  };
  businessSuccessScore: number | null;
  metricsSummary: {
    totalRevenue: number;
    totalExpenses: number;
    netProfit: number;
    breakEvenRevenue: number | null;
    avgOrderValue: number;
    repeatCustomerRate: number;
    avgRating: number | null;
  };
  topServices: { name: string; count: number; revenue: number }[];
  dailyTrend: { date: string; revenue: number; expenses: number; orders: number }[];
  forecasts: {
    expectedOrdersNextWeek: number | null;
    expectedRevenueNextWeek: number | null;
    expectedCustomersNextMonth: number | null;
    profitTrendNote: string;
  };
  incomingCustomerPrediction?: {
    expectedNextCustomers: number;
    expectedArrivalNote: string;
    likelyServiceNote: string;
    readinessChecklist: string[];
  };
  aiWarning?: string;
  satisfactionAnalysis: string;
  advice: {
    daily: string[];
    weekly: string[];
    monthly: string[];
  };
  alerts: {
    severity: 'warning' | 'opportunity' | 'info';
    title: string;
    detail: string;
  }[];
  generatedAt: string;
}
