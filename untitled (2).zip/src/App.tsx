import React, { useEffect, useState } from 'react';
import { Clock, Globe, Lock, MapPin, Star } from 'lucide-react';
import type { Language, PublicConfig, ServiceItem } from './types';
import { TRANSLATIONS } from './i18n';
import { OrderFormSection } from './components/OrderFormSection';
import { OrderTrackerSection } from './components/OrderTrackerSection';
import { OfficeDirectionsModal } from './components/MapsWidget';
import { AdminDashboard } from './components/AdminDashboard';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [isAdminView, setIsAdminView] = useState(false);
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);
  const [directionsOpen, setDirectionsOpen] = useState(false);
  const [trackQuery, setTrackQuery] = useState('');

  const [services, setServices] = useState<ServiceItem[]>([]);
  const [config, setConfig] = useState<PublicConfig>({
    googleMapsApiKey: '',
    officeName: 'Graphicore Office',
    officeLogo: '',
    officeAddress: 'حي أول نوفمبر، مركز الأعمال، الجزائر',
    officeLat: 36.7538,
    officeLng: 3.0588,
    workingHoursMorning: '08:00 – 13:30',
    workingHoursEvening: '18:30 – 21:30',
    deliveryBaseFee: 200,
    deliveryEnabled: true,
    showSatisfactionSummary: true,
  });
  const [reviewSummary, setReviewSummary] = useState<{
    totalReviews: number;
    averageRating: number | null;
  }>({ totalReviews: 0, averageRating: null });

  const loadPublicData = async () => {
    try {
      const [cfgRes, srvRes, revRes] = await Promise.all([
        fetch('/api/public/config'),
        fetch('/api/services'),
        fetch('/api/reviews/summary'),
      ]);
      if (cfgRes.ok) setConfig(await cfgRes.json());
      if (srvRes.ok) setServices(await srvRes.json());
      if (revRes.ok) setReviewSummary(await revRes.json());
    } catch {
      // keep cached/default values offline
    }
  };

  useEffect(() => {
    loadPublicData();
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  useEffect(() => {
    if (config.officeName) {
      document.title = config.officeName;
    }
  }, [config.officeName]);

  useEffect(() => {
    const onQuota = () => setMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuota);
  }, []);

  const t = TRANSLATIONS[lang];

  if (isAdminView) {
    return (
      <>
        {mapsQuotaExceeded && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
            <span>
              Google Maps Platform quota reached. If you are the app owner, visit{' '}
              <a
                href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-semibold text-amber-950 hover:text-amber-800"
              >
                maps developer site
              </a>{' '}
              for instructions to update your account.
            </span>
          </div>
        )}
        <AdminDashboard
          lang={lang}
          config={config}
          onExit={() => setIsAdminView(false)}
          onDataUpdated={loadPublicData}
        />
        <OfflineIndicator lang={lang} />
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {mapsQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Strict 3-Zone Top Bar Contract (No Admin Entry Here) */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-4 flex items-center justify-between gap-8">
          <a
            href="#top"
            className="inline-flex items-center gap-2.5 text-lg font-extrabold tracking-tight text-blue-900 whitespace-nowrap shrink-0"
          >
            {config.officeLogo && (
              <img
                src={config.officeLogo}
                alt={config.officeName}
                className="h-8 w-8 rounded-lg object-contain border border-slate-200 bg-white p-0.5 shrink-0"
              />
            )}
            <span>{config.officeName || t.brand}</span>
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
            <a
              href="#order-form"
              className="hover:text-blue-700 hover:underline transition-colors whitespace-nowrap shrink-0"
            >
              {t.navOrder}
            </a>
            <a
              href="#track-section"
              className="hover:text-blue-700 hover:underline transition-colors whitespace-nowrap shrink-0"
            >
              {t.navTrack}
            </a>
            <button
              type="button"
              onClick={() => setDirectionsOpen(true)}
              className="hover:text-blue-700 hover:underline transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.navLocation}
            </button>
            {config.showSatisfactionSummary && (
              <a
                href="#feedback-overview"
                className="hover:text-blue-700 hover:underline transition-colors whitespace-nowrap shrink-0"
              >
                {t.navReviews}
              </a>
            )}
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <a
              href="#order-form"
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-bold text-white hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0"
            >
              {t.startOrderCta}
            </a>
          </div>
        </div>
      </header>

      {/* Sub-header Utility Strip: Language Switcher, Working Hours & PWA Install */}
      <div className="border-b border-slate-200 bg-slate-100/70">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <Clock className="h-3.5 w-3.5 text-blue-700 shrink-0" />
            <span>
              {t.workingHoursTitle}: {t.morningHours} {config.workingHoursMorning} · {t.eveningHours}{' '}
              {config.workingHoursEvening}
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <PWAInstallButton lang={lang} />
            <div className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-0.5 text-xs font-semibold">
              <Globe className="h-3.5 w-3.5 text-slate-400 ms-1.5" />
              {(['ar', 'fr', 'en'] as Language[]).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setLang(l)}
                  className={`rounded-md px-2 py-1 uppercase transition-colors cursor-pointer ${
                    lang === l ? 'bg-blue-700 text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Customer Workspace */}
      <main id="top" className="flex-1 mx-auto w-full max-w-6xl px-4 sm:px-6 py-8 sm:py-10 space-y-12">
        <OrderFormSection
          lang={lang}
          services={services}
          config={config}
          onOrderCreated={() => loadPublicData()}
          onOpenDirections={() => setDirectionsOpen(true)}
          onJumpToTrack={(code) => {
            setTrackQuery(code);
            setTimeout(() => {
              document.getElementById('track-section')?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          }}
        />

        <OrderTrackerSection lang={lang} initialQuery={trackQuery} />

        {/* Customer Experience & Verified Reviews Callout (Admin-togglable; individual reviews remain Admin-only) */}
        {config.showSatisfactionSummary && (
          <section
            id="feedback-overview"
            className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
          >
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2 text-blue-800 font-bold text-sm">
                <Star className="h-4 w-4 fill-amber-400 text-amber-500" />
                <span>{t.reviewSectionTitle}</span>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed">
                {lang === 'fr'
                  ? 'Après réception de votre commande, notez votre expérience (1 à 5 étoiles) directement depuis la section de suivi. Tous les avis sont consultés exclusivement par l’administration pour améliorer la qualité.'
                  : lang === 'en'
                    ? 'Once your order is ready, rate your experience (1–5 stars) directly in the tracking section. All feedback is reviewed confidentially by management.'
                    : 'بعد إتمام طلبك، يمكنك تقييم تجربتك من نجمة إلى 5 نجوم وإرسال اقتراحاتك أو ملاحظاتك عبر قسم التتبع أعلاه. جميع التقييمات تصل للإدارة بسرية تامة للارتقاء بجودة خدماتنا.'}
              </p>
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 px-6 py-4 text-center shrink-0">
              <div className="text-xs text-slate-500">
                {lang === 'fr' ? 'Satisfaction moyenne' : lang === 'en' ? 'Average Rating' : 'متوسط رضا العملاء'}
              </div>
              <div className="mt-1 text-2xl font-extrabold text-blue-800 font-mono-nums">
                {reviewSummary.averageRating !== null ? `${reviewSummary.averageRating} / 5` : '—'}
              </div>
              <div className="text-[11px] text-slate-500 font-mono-nums">
                {reviewSummary.totalReviews}{' '}
                {lang === 'fr' ? 'avis vérifiés' : lang === 'en' ? 'verified reviews' : 'تقييم موثّق'}
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Quiet Footer with Exclusive Admin Entry Link at Bottom */}
      <footer className="border-t border-slate-200 bg-white mt-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
            {config.officeLogo && (
              <img
                src={config.officeLogo}
                alt={config.officeName}
                className="h-5 w-5 rounded object-contain"
              />
            )}
            <span className="font-bold text-slate-800">{config.officeName}</span>
            <span aria-hidden="true">·</span>
            <span>{config.officeAddress}</span>
            <span aria-hidden="true">·</span>
            <span>
              {t.morningHours}: {config.workingHoursMorning} / {t.eveningHours}: {config.workingHoursEvening}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setDirectionsOpen(true)}
              className="inline-flex items-center gap-1 hover:text-blue-700 cursor-pointer"
            >
              <MapPin className="h-3.5 w-3.5" />
              <span>{t.ourLocationBtn}</span>
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => setIsAdminView(true)}
              className="inline-flex items-center gap-1 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
            >
              <Lock className="h-3 w-3" />
              <span>{t.footerAdminLink}</span>
            </button>
          </div>
        </div>
      </footer>

      <OfficeDirectionsModal
        isOpen={directionsOpen}
        onClose={() => setDirectionsOpen(false)}
        config={config}
        lang={lang}
      />

      <OfflineIndicator lang={lang} />
    </div>
  );
}
